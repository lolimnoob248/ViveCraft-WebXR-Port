package dev.vivewebxr.server;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import dev.vivewebxr.WebXRMod;
import dev.vivewebxr.XRInput;
import dev.vivewebxr.XRState;

import java.io.ByteArrayOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayDeque;

/** One connected browser (WebSocket, RFC 6455). */
final class WsClient {
    private static final int MAX_MESSAGE = 1 << 20;

    final int id;
    private final Socket socket;
    private final InputStream in;
    private final OutputStream out;

    private final Object lock = new Object();
    private byte[] pendingFrame;
    private long newestFrameSeq;
    /** Audio must not be replaced like video (that would click), but it is bounded so delay can never build up. */
    private static final int MAX_AUDIO_CHUNKS = 15; // ~150 ms of 10 ms chunks
    private final ArrayDeque<byte[]> pendingAudio = new ArrayDeque<>();
    private boolean lastWasAudio;
    private final ArrayDeque<String> pendingText = new ArrayDeque<>();
    private volatile boolean closed;
    /** Version of the web page (client.js) that matches this server; a page with another version reloads itself. */
    static final int PAGE_VERSION = 4;
    volatile boolean inVr;
    /** Largest texture the browser's GPU accepts; the server never streams a bigger picture (it would show BLACK). */
    volatile int maxTex = 4096;

    WsClient(int id, Socket socket, InputStream in, OutputStream out) {
        this.id = id;
        this.socket = socket;
        this.in = in;
        this.out = out;
    }

    void run() throws IOException {
        Thread sender = new Thread(this::senderLoop, "WebXR-send-" + id);
        sender.setDaemon(true);
        sender.start();
        sendText("{\"t\":\"hello\",\"v\":1,\"page\":" + PAGE_VERSION + "}");
        try {
            readLoop();
        } catch (SocketTimeoutException e) {
            WebXRMod.LOGGER.info("WebXR client {} timed out", id);
        } catch (EOFException ignored) {
        }
    }

    // ---------------------------------------------------------------- sending

    /** Newest frame wins: an older unsent frame is replaced, and a frame older than the newest one seen is ignored. */
    void sendFrame(byte[] jpeg, long seq) {
        synchronized (lock) {
            if (seq <= newestFrameSeq) return; // a parallel encoder finished a newer frame first
            newestFrameSeq = seq;
            pendingFrame = jpeg;
            lock.notifyAll();
        }
    }

    void sendAudio(byte[] taggedChunk) {
        synchronized (lock) {
            while (pendingAudio.size() >= MAX_AUDIO_CHUNKS) pendingAudio.poll(); // network behind: drop the OLDEST sound
            pendingAudio.add(taggedChunk);
            lock.notifyAll();
        }
    }

    void sendText(String s) {
        synchronized (lock) {
            if (pendingText.size() < 256) pendingText.add(s);
            lock.notifyAll();
        }
    }

    private void senderLoop() {
        try {
            while (!closed) {
                String text;
                byte[] frame = null;
                byte[] audio = null;
                synchronized (lock) {
                    while (!closed && pendingFrame == null && pendingText.isEmpty() && pendingAudio.isEmpty()) lock.wait(1000);
                    if (closed) return;
                    text = pendingText.poll();
                    if (text == null) {
                        // sound first (it must never starve), but after each sound chunk a waiting picture gets its turn
                        if (!(lastWasAudio && pendingFrame != null)) audio = pendingAudio.poll();
                        if (audio == null) {
                            frame = pendingFrame;
                            pendingFrame = null;
                            if (frame == null) audio = pendingAudio.poll();
                        }
                    }
                    lastWasAudio = audio != null;
                }
                if (text != null) write(0x1, text.getBytes(StandardCharsets.UTF_8));
                else if (audio != null) write(0x2, audio);
                else if (frame != null) write(0x2, frame);
            }
        } catch (Exception e) {
            close();
        }
    }

    private void write(int opcode, byte[] payload) throws IOException {
        int n = payload.length;
        int hl = n < 126 ? 2 : n < 65536 ? 4 : 10;
        // header + payload in ONE write -> one TCP segment train / one TLS record instead of two
        byte[] buf = new byte[hl + n];
        buf[0] = (byte) (0x80 | opcode);
        if (n < 126) {
            buf[1] = (byte) n;
        } else if (n < 65536) {
            buf[1] = 126;
            buf[2] = (byte) (n >> 8);
            buf[3] = (byte) n;
        } else {
            buf[1] = 127;
            for (int i = 0; i < 8; i++) buf[2 + i] = (byte) (((long) n >> (8 * (7 - i))) & 0xFF);
        }
        System.arraycopy(payload, 0, buf, hl, n);
        synchronized (out) {
            out.write(buf);
            out.flush();
        }
    }

    // ---------------------------------------------------------------- receiving

    private void readLoop() throws IOException {
        ByteArrayOutputStream message = new ByteArrayOutputStream();
        int messageOpcode = 0;
        while (!closed) {
            int b0 = in.read();
            if (b0 < 0) return;
            int b1 = readByte();
            boolean fin = (b0 & 0x80) != 0;
            int opcode = b0 & 0x0F;
            boolean masked = (b1 & 0x80) != 0;
            long len = b1 & 0x7F;
            if (len == 126) {
                len = ((long) readByte() << 8) | readByte();
            } else if (len == 127) {
                len = 0;
                for (int i = 0; i < 8; i++) len = (len << 8) | readByte();
            }
            if (len < 0 || len > MAX_MESSAGE) throw new IOException("message too large");
            byte[] mask = new byte[4];
            if (masked) readFully(mask);
            byte[] payload = new byte[(int) len];
            readFully(payload);
            if (masked) for (int i = 0; i < payload.length; i++) payload[i] ^= mask[i & 3];

            switch (opcode) {
                case 0x8 -> { // close
                    try {
                        write(0x8, new byte[0]);
                    } catch (IOException ignored) {
                    }
                    return;
                }
                case 0x9 -> write(0xA, payload); // ping -> pong
                case 0xA -> { }                   // pong
                default -> {                      // 0x0 continuation, 0x1 text, 0x2 binary
                    if (opcode != 0x0) {
                        message.reset();
                        messageOpcode = opcode;
                    }
                    message.write(payload);
                    if (message.size() > MAX_MESSAGE) throw new IOException("message too large");
                    if (fin) {
                        if (messageOpcode == 0x1) onText(message.toString(StandardCharsets.UTF_8));
                        message.reset();
                    }
                }
            }
        }
    }

    private int readByte() throws IOException {
        int b = in.read();
        if (b < 0) throw new EOFException();
        return b;
    }

    private void readFully(byte[] buf) throws IOException {
        int off = 0;
        while (off < buf.length) {
            int n = in.read(buf, off, buf.length - off);
            if (n < 0) throw new EOFException();
            off += n;
        }
    }

    private void onText(String text) {
        try {
            JsonObject o = JsonParser.parseString(text).getAsJsonObject();
            String t = o.has("t") ? o.get("t").getAsString() : "";
            switch (t) {
                case "p" -> {
                    if (inVr) XRState.onInput(id, XRInput.parse(o));
                }
                case "s" -> { // session start / end
                    if (o.has("maxTex")) {
                        int mt = o.get("maxTex").getAsInt();
                        maxTex = Math.max(1024, Math.min(16384, mt));
                    }
                    boolean on = o.get("vr").getAsBoolean();
                    if (on) {
                        int page = o.has("page") ? o.get("page").getAsInt() : 0;
                        WebXRMod.LOGGER.info("WebXR: browser (client {}) enters VR, picture limit {} px, page version {}{}", id, maxTex, page,
                                page == PAGE_VERSION ? "" : "  <-- OLD PAGE: reload the page in the headset browser!");
                        if (page != PAGE_VERSION) sendText("{\"t\":\"reload\"}");
                        boolean ok = XRState.sessionChanged(id, true);
                        inVr = ok;
                        sendText("{\"t\":\"session\",\"ok\":" + ok + "}");
                    } else {
                        inVr = false;
                        XRState.sessionChanged(id, false);
                    }
                }
                case "log" -> WebXRMod.LOGGER.info("WebXR browser: {}", o.has("m") ? o.get("m").getAsString() : "");
                default -> { } // "k" keep-alive etc.
            }
        } catch (Exception e) {
            WebXRMod.LOGGER.debug("bad message from client {}: {}", id, e.toString());
        }
    }

    void close() {
        if (closed) return;
        closed = true;
        inVr = false;
        synchronized (lock) {
            lock.notifyAll();
        }
        try {
            socket.close();
        } catch (IOException ignored) {
        }
    }
}
