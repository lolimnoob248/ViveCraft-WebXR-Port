package dev.webxrcraft.vr;

import dev.webxrcraft.WebXRConfig;
import dev.webxrcraft.net.XRState;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL15;
import org.lwjgl.opengl.GL30;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.ByteArrayOutputStream;
import java.nio.ByteBuffer;

/**
 * Reads the finished left-eye texture back from the GPU (asynchronously through two pixel-pack
 * buffers, so the render thread never stalls), then JPEG-encodes it on a worker thread and hands
 * the bytes to the WebSocket layer.
 */
public final class FrameCapture {
    private static final Logger LOG = LoggerFactory.getLogger("vivecraft-webxr");
    private static final int GL_READ_FRAMEBUFFER = 36008;
    private static final int GL_READ_FRAMEBUFFER_BINDING = 36010;
    private static final int GL_COLOR_ATTACHMENT0 = 36064;
    private static final int GL_FRAMEBUFFER_COMPLETE = 36053;
    private static final int GL_PIXEL_PACK_BUFFER = 35051;
    private static final int GL_STREAM_READ = 35041;
    private static final int GL_MAP_READ_BIT = 1;

    private final XRState state;
    private final WebXRConfig cfg;
    private final long minIntervalNanos;

    // render-thread state
    private final int[] pbo = {0, 0};
    private int pboW, pboH, cur;
    private boolean primed;
    private long lastCapture;
    private int readFbo;
    private boolean warnedIncomplete, warnedMap, loggedContent;

    // hand-off to the encoder thread (single slot, newest frame wins)
    private final Object lock = new Object();
    private byte[] pending;
    private int pendingW, pendingH;
    private byte[] spare;
    private volatile boolean running = true;
    private final Thread worker;

    public FrameCapture(XRState state, WebXRConfig cfg) {
        this.state = state;
        this.cfg = cfg;
        this.minIntervalNanos = 1_000_000_000L / Math.max(1, cfg.streamFps);
        this.worker = new Thread(this::encodeLoop, "webxr-encoder");
        this.worker.setDaemon(true);
        this.worker.start();
    }

    /** Call on the render thread after both eyes are rendered. */
    public void capture(int textureId, int w, int h) {
        if (textureId <= 0 || w <= 0 || h <= 0) return;
        long now = System.nanoTime();
        if (now - lastCapture < minIntervalNanos) return;
        lastCapture = now;
        int prevRead = 0;
        boolean boundRead = false;
        try {
            if (w != pboW || h != pboH) allocate(w, h);
            int size = w * h * 4;

            // glGetTexImage does not exist on OpenGL ES (iOS/Android), so attach the eye texture
            // to a private framebuffer and use glReadPixels, which works everywhere.
            prevRead = GL11.glGetInteger(GL_READ_FRAMEBUFFER_BINDING);
            if (readFbo == 0) readFbo = GL30.glGenFramebuffers();
            GL30.glBindFramebuffer(GL_READ_FRAMEBUFFER, readFbo);
            boundRead = true;
            GL30.glFramebufferTexture2D(GL_READ_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL11.GL_TEXTURE_2D, textureId, 0);
            int status = GL30.glCheckFramebufferStatus(GL_READ_FRAMEBUFFER);
            if (status != GL_FRAMEBUFFER_COMPLETE) {
                if (!warnedIncomplete) {
                    warnedIncomplete = true;
                    LOG.warn("WebXR capture: eye framebuffer incomplete (0x{})", Integer.toHexString(status));
                }
                return;
            }

            GL15.glBindBuffer(GL_PIXEL_PACK_BUFFER, pbo[cur]);
            GL11.glReadPixels(0, 0, w, h, GL11.GL_RGBA, GL11.GL_UNSIGNED_BYTE, 0L); // async into the PBO

            if (primed) {
                int other = cur ^ 1;
                GL15.glBindBuffer(GL_PIXEL_PACK_BUFFER, pbo[other]);
                ByteBuffer mapped = GL30.glMapBufferRange(GL_PIXEL_PACK_BUFFER, 0, size, GL_MAP_READ_BIT);
                if (mapped != null) {
                    publish(mapped, w, h, size);
                    GL15.glUnmapBuffer(GL_PIXEL_PACK_BUFFER);
                } else if (!warnedMap) {
                    warnedMap = true;
                    LOG.warn("WebXR capture: could not map the pixel buffer");
                }
            }
            GL15.glBindBuffer(GL_PIXEL_PACK_BUFFER, 0);
            cur ^= 1;
            primed = true;
        } catch (Throwable t) {
            GL15.glBindBuffer(GL_PIXEL_PACK_BUFFER, 0);
            LOG.warn("Frame capture failed: {}", t.toString());
        } finally {
            if (boundRead) GL30.glBindFramebuffer(GL_READ_FRAMEBUFFER, prevRead);
        }
    }

    private void allocate(int w, int h) {
        for (int i = 0; i < 2; i++) {
            if (pbo[i] != 0) GL15.glDeleteBuffers(pbo[i]);
            pbo[i] = GL15.glGenBuffers();
            GL15.glBindBuffer(GL_PIXEL_PACK_BUFFER, pbo[i]);
            GL15.glBufferData(GL_PIXEL_PACK_BUFFER, (long) w * h * 4, GL_STREAM_READ);
        }
        GL15.glBindBuffer(GL_PIXEL_PACK_BUFFER, 0);
        pboW = w;
        pboH = h;
        primed = false;
        cur = 0;
    }

    private void publish(ByteBuffer mapped, int w, int h, int size) {
        synchronized (lock) {
            byte[] dst = spare != null && spare.length == size ? spare : new byte[size];
            spare = null;
            mapped.get(dst, 0, size);
            if (!loggedContent) {
                loggedContent = true;
                int nz = 0, n = 0;
                for (int i = 0; i < size; i += 4 * 97) { n++; if ((dst[i] | dst[i + 1] | dst[i + 2]) != 0) nz++; }
                LOG.info("WebXR first captured frame {}x{}: {}/{} sampled pixels non-black", w, h, nz, n);
            }
            if (pending != null) spare = pending; // recycle the frame the encoder never got to
            pending = dst;
            pendingW = w;
            pendingH = h;
            lock.notify();
        }
    }

    public void destroy() {
        running = false;
        synchronized (lock) { lock.notifyAll(); }
        // GL buffers are released when the context is destroyed
    }

    // ---- encoder thread ----------------------------------------------------------------------

    private void encodeLoop() {
        ByteBuffer direct = null;
        JpegEncoder enc = new JpegEncoder();
        while (running) {
            byte[] frame;
            int w, h;
            synchronized (lock) {
                while (pending == null && running) {
                    try { lock.wait(); } catch (InterruptedException e) { return; }
                }
                if (!running) return;
                frame = pending;
                w = pendingW;
                h = pendingH;
                pending = null;
            }
            try {
                if (state.clientCount() > 0) {
                    if (direct == null || direct.capacity() != w * h * 4) direct = ByteBuffer.allocateDirect(w * h * 4);
                    // GL rows are bottom-up; flip while copying into the direct buffer
                    direct.clear();
                    int stride = w * 4;
                    for (int y = h - 1; y >= 0; y--) direct.put(frame, y * stride, stride);
                    direct.flip();
                    byte[] jpg = enc.encode(direct, w, h, cfg.jpegQuality);
                    if (jpg != null) state.broadcastFrame(jpg, jpg.length);
                }
            } catch (Throwable t) {
                LOG.warn("JPEG encode failed: {}", t.toString());
            }
            synchronized (lock) {
                if (spare == null) spare = frame;
            }
        }
    }

    /** STB (bundled with Minecraft's LWJGL) first, ImageIO if STB is unavailable. */
    private static final class JpegEncoder {
        private boolean stbBroken;
        private boolean imageIoBroken;
        private final ByteArrayOutputStream bos = new ByteArrayOutputStream(256 * 1024);

        byte[] encode(ByteBuffer rgba, int w, int h, int quality) {
            if (!stbBroken) {
                try {
                    return encodeStb(rgba, w, h, quality);
                } catch (Throwable t) {
                    stbBroken = true;
                    LOG.warn("STB JPEG encoder unavailable ({}), falling back to ImageIO", t.toString());
                }
            }
            if (!imageIoBroken) {
                try {
                    return encodeImageIo(rgba, w, h, quality);
                } catch (Throwable t) {
                    imageIoBroken = true;
                    LOG.error("No JPEG encoder available: {}", t.toString());
                }
            }
            return null;
        }

        private byte[] encodeStb(ByteBuffer rgba, int w, int h, int quality) {
            bos.reset();
            org.lwjgl.stb.STBIWriteCallback cb = org.lwjgl.stb.STBIWriteCallback.create((context, data, size) -> {
                ByteBuffer d = org.lwjgl.stb.STBIWriteCallback.getData(data, size);
                byte[] tmp = new byte[size];
                d.get(tmp);
                bos.write(tmp, 0, size);
            });
            try {
                if (!org.lwjgl.stb.STBImageWrite.stbi_write_jpg_to_func(cb, 0L, w, h, 4, rgba, quality)) {
                    throw new IllegalStateException("stbi_write_jpg_to_func failed");
                }
            } finally {
                cb.free();
            }
            return bos.toByteArray();
        }

        private byte[] encodeImageIo(ByteBuffer rgba, int w, int h, int quality) throws Exception {
            java.awt.image.BufferedImage img = new java.awt.image.BufferedImage(w, h, java.awt.image.BufferedImage.TYPE_INT_RGB);
            int[] px = new int[w * h];
            for (int i = 0; i < px.length; i++) {
                int r = rgba.get() & 0xFF, g = rgba.get() & 0xFF, b = rgba.get() & 0xFF;
                rgba.get();
                px[i] = (r << 16) | (g << 8) | b;
            }
            img.setRGB(0, 0, w, h, px, 0, w);
            javax.imageio.ImageWriter writer = javax.imageio.ImageIO.getImageWritersByFormatName("jpg").next();
            javax.imageio.ImageWriteParam p = writer.getDefaultWriteParam();
            p.setCompressionMode(javax.imageio.ImageWriteParam.MODE_EXPLICIT);
            p.setCompressionQuality(quality / 100f);
            bos.reset();
            try (javax.imageio.stream.ImageOutputStream ios = javax.imageio.ImageIO.createImageOutputStream(bos)) {
                writer.setOutput(ios);
                writer.write(null, new javax.imageio.IIOImage(img, null, null), p);
            } finally {
                writer.dispose();
            }
            return bos.toByteArray();
        }
    }
}
