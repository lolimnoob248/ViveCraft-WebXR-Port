package dev.webxrcraft.vr;

import com.mojang.blaze3d.opengl.GlStateManager;
import dev.webxrcraft.WebXRMod;
import org.joml.Matrix4f;
import org.joml.Vector2i;
import org.joml.Vector2ic;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.vivecraft.client_vr.ClientDataHolderVR;
import org.vivecraft.client_vr.provider.MCVR;
import org.vivecraft.client_vr.provider.VRRenderer;
import org.vivecraft.client_vr.render.helpers.graphics.GraphicsHelper;

import java.nio.ByteBuffer;

/**
 * Stereo renderer for the WebXR device. Vivecraft renders both eyes into plain GL textures
 * (exactly like its built-in NullVR renderer). After each frame the left eye is captured and
 * streamed to the browser, which shows it on a head-locked virtual screen.
 *
 * The render size is a normal monitor-like 16:9 picture, because it is shown on a flat screen.
 */
public class WebXRStereoRenderer extends VRRenderer {
    private static final Logger LOG = LoggerFactory.getLogger("vivecraft-webxr");
    private float lastFov = -1.0F;
    private float lastAngle = -1.0F;

    public WebXRStereoRenderer(MCVR vr) {
        super(vr);
    }

    @Override
    public Vector2ic getRenderTextureSizes() {
        if (this.resolution == null) {
            this.resolution = new Vector2i(WebXRMod.config().streamWidth, WebXRMod.config().streamHeight);
            LOG.info("Vivecraft WebXR: render/stream resolution {}x{}", this.resolution.x(), this.resolution.y());
            this.ss = -1.0F;
        }
        return this.resolution;
    }

    @Override
    public Matrix4f getCachedProjectionMatrix(int eye, float nearClip, float farClip) {
        ClientDataHolderVR dh = ClientDataHolderVR.getInstance();
        if (this.lastFov != dh.vrSettings.nullvrFOV || this.lastAngle != dh.vrSettings.nullvrEyeAngle) {
            this.lastFarClip = 0.0F;
            this.lastFov = dh.vrSettings.nullvrFOV;
            this.lastAngle = dh.vrSettings.nullvrEyeAngle;
        }
        return super.getCachedProjectionMatrix(eye, nearClip, farClip);
    }

    @Override
    protected Matrix4f getProjectionMatrix(int eye, float nearClip, float farClip) {
        ClientDataHolderVR dh = ClientDataHolderVR.getInstance();
        Vector2ic res = this.getRenderTextureSizes();
        float aspect = (float) res.x() / (float) res.y();
        return new Matrix4f().setPerspectiveOffCenter(
            0.017453292F * dh.vrSettings.nullvrFOV,
            0.017453292F * dh.vrSettings.nullvrEyeAngle * (eye == 0 ? -1.0F : 1.0F),
            0.0F, aspect, nearClip, farClip);
    }

    @Override
    public void createRenderTexture(int width, int height) {
        for (int i = 0; i < 2; i++) {
            int previous = GlStateManager._getInteger(32873); // GL_TEXTURE_BINDING_2D
            this.eyeTextureId[i] = GlStateManager._genTexture();
            GlStateManager._bindTexture(this.eyeTextureId[i]);
            GlStateManager._texParameter(3553, 10241, 9729); // MIN_FILTER LINEAR
            GlStateManager._texParameter(3553, 10240, 9729); // MAG_FILTER LINEAR
            GlStateManager._texImage2D(3553, 0, 32856, width, height, 0, 6408, 5121, (ByteBuffer) null); // RGBA8 / UNSIGNED_BYTE (valid on GLES too)
            GlStateManager._bindTexture(previous);
            GraphicsHelper.INSTANCE.checkError("create VR textures " + (i == 0 ? "Left" : "Right"));
        }
        this.lastError = GraphicsHelper.INSTANCE.checkError("create VR textures");
    }

    @Override
    public void endFrame() {
        FrameCapture capture = WebXRMod.capture();
        if (capture != null) {
            Vector2ic res = this.getRenderTextureSizes();
            capture.capture(this.eyeTextureId[0], res.x(), res.y());
        }
    }

    @Override
    public boolean providesStencilMask() {
        return false;
    }

    @Override
    public String getName() {
        return "WebXR";
    }

    @Override
    protected void destroyBuffers() {
        super.destroyBuffers();
        for (int i = 0; i < 2; i++) {
            if (this.eyeTextureId[i] > -1) {
                GlStateManager._deleteTexture(this.eyeTextureId[i]);
                this.eyeTextureId[i] = -1;
            }
        }
    }
}
