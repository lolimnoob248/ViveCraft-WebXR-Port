package dev.vivewebxr.vr;

import dev.vivewebxr.WebXRConfig;
import dev.vivewebxr.WebXRMod;
import dev.vivewebxr.XRState;
import dev.vivewebxr.render.FrameGrabber;
import org.joml.Matrix4f;
import org.joml.Vector2i;
import org.joml.Vector2ic;
import org.vivecraft.api.client.data.RenderPass;
import org.vivecraft.client_vr.provider.MCVR;
import org.vivecraft.client_vr.provider.nullvr.NullVRStereoRenderer;

import java.util.List;

/**
 * Same as Vivecraft's built-in "null driver" renderer (it renders the eyes but shows them nowhere), with changes:
 *
 *  - FIELD OF VIEW: the null driver renders a fixed 2048x2048 square at ~110 degrees. We render with exactly the
 *    frustum the headset reported (XRState.view()) and size the eye texture to the same aspect ratio. The browser
 *    shows the picture on a screen of exactly that angular size, so it fills the headset: no black borders.
 *  - RESOLUTION: the eye texture IS the streamed picture (streamWidth pixels wide). No blurry down-scaling.
 *  - After each frame the finished left eye is copied out and streamed to the browser, tagged with the head pose
 *    it was rendered from (so the browser can keep it world-locked while newer frames are on their way).
 */
public class WebXRStereoRenderer extends NullVRStereoRenderer {
    private boolean checkedBackend;
    private boolean openGl;

    // The view (field of view) this renderer currently renders with. Only changed on the render thread.
    private int appliedVersion;
    private float tanX, tanY;
    private Vector2i target;

    /** Real size of the eye texture (what createRenderTexture was last called with). */
    private int texW, texH;

    public WebXRStereoRenderer(MCVR vr) {
        super(vr);
        XRState.View v = XRState.view();
        this.appliedVersion = v.version;
        this.tanX = v.tx;
        this.tanY = v.ty;
        this.target = sizeFor(v);
    }

    /** Eye texture size for a view: configured width, height from the field of view, both even. */
    private static Vector2i sizeFor(XRState.View v) {
        int w = Math.max(64, WebXRConfig.streamWidth) & ~1;
        int h = Math.round(w * (v.ty / v.tx)) & ~1;
        return new Vector2i(w, Math.max(64, h));
    }

    /**
     * Render thread, once per frame (from WebXRVR.poll). When the browser reports a different field of view the
     * projection changes right away and the eye textures are rebuilt by Vivecraft on the next frame.
     */
    public void applyView(XRState.View v) {
        if (v.version == appliedVersion) return;
        appliedVersion = v.version;
        tanX = v.tx;
        tanY = v.ty;
        this.lastFarClip = 0f; // forces Vivecraft to ask getProjectionMatrix() again
        Vector2i wanted = sizeFor(v);
        if (!wanted.equals(target)) {
            target = wanted;
            reinitFrameBuffers("WebXR field of view changed -> " + wanted.x + "x" + wanted.y);
        }
    }

    // ------------------------------------------------------------------ Vivecraft hooks

    @Override
    public Vector2ic getRenderTextureSizes() {
        this.resolution = target;
        return target;
    }

    @Override
    protected Matrix4f getProjectionMatrix(int eye, float near, float far) {
        // One symmetric frustum for both eyes: it covers what both eyes of the headset can see.
        return new Matrix4f().frustum(-tanX * near, tanX * near, -tanY * near, tanY * near, near, far);
    }

    @Override
    public void createRenderTexture(int w, int h) {
        super.createRenderTexture(w, h);
        texW = w;
        texH = h;
    }

    @Override
    public List<RenderPass> getRenderPasses(boolean mirror) {
        List<RenderPass> passes = super.getRenderPasses(mirror); // a fresh list on every call
        if (WebXRConfig.skipRightEye) passes.remove(RenderPass.RIGHT);
        return passes;
    }

    @Override
    public void endFrame() {
        super.endFrame(); // keeps NullVR's bookkeeping (it checks the headset was polled)

        if (!checkedBackend) {
            checkedBackend = true;
            String helper = org.vivecraft.client_vr.render.helpers.graphics.GraphicsHelper.INSTANCE.getClass().getSimpleName();
            openGl = helper.equals("OpenGLHelper");
            if (!openGl) {
                WebXRMod.LOGGER.warn("WebXR: graphics backend is {} - video streaming only works with OpenGL.", helper);
            }
        }
        if (!openGl) return;
        // Right after a field-of-view change the old-size texture is still in use for a frame: skip that one.
        if (texW != target.x || texH != target.y) return;

        int seq = this.vr instanceof WebXRVR w ? w.polledSeq() : 0;
        FrameGrabber.INSTANCE.capture(this.eyeTextureId[0], texW, texH, seq, tanX, tanY);
    }

    @Override
    protected void destroyBuffers() {
        FrameGrabber.INSTANCE.release();
        texW = texH = 0;
        super.destroyBuffers();
    }
}
