package dev.vivewebxr.vr;

import dev.vivewebxr.WebXRMod;
import dev.vivewebxr.XRInput;
import dev.vivewebxr.XRState;
import dev.vivewebxr.render.FrameGrabber;
import net.minecraft.client.Minecraft;
import org.joml.Matrix4f;
import org.joml.Matrix4fc;
import org.joml.Quaternionf;
import org.vivecraft.client_vr.ClientDataHolderVR;
import org.vivecraft.client_vr.gameplay.screenhandlers.GuiHandler;
import org.vivecraft.client_vr.provider.ControllerTransform;
import org.vivecraft.client_vr.provider.ControllerType;
import org.vivecraft.client_vr.provider.HardwareType;
import org.vivecraft.client_vr.provider.VRRenderer;
import org.vivecraft.client_vr.provider.nullvr.NullVR;
import org.vivecraft.client_vr.provider.openvr_lwjgl.VRInputAction;

/**
 * The "WEBXR" VR device.
 *
 * It starts from Vivecraft's own NullVR (a headset-less device that never crashes) and replaces:
 *  - poll(): head and hand poses come from the browser instead of the keyboard
 *  - processInputs(): browser controller buttons/sticks press Vivecraft's input actions
 *  - isActive(): true only while a browser is inside "Enter VR"  (Vivecraft then switches VR on/off by itself)
 *  - createVRRenderer(): the renderer that also streams the left eye to the browser
 *  - haptics: vibration is sent to the browser
 */
public class WebXRVR extends NullVR {
    private static final float PRESS = 0.5f;
    private static final ControllerType R = ControllerType.RIGHT;
    private static final ControllerType L = ControllerType.LEFT;

    private ControllerTransform transform = ControllerTransform.QUEST2_PRO_PLUS;
    private String lastProfile = "";

    /** Sequence number of the browser pose used by the latest poll() = the pose the current frame is rendered from. */
    private volatile int polledSeq;

    public WebXRVR(Minecraft mc, ClientDataHolderVR dh) {
        super(mc, dh);
        this.hapticScheduler = new WebXRHaptics();
    }

    // ------------------------------------------------------------------ identity

    @Override
    public boolean init() {
        boolean ok = super.init();
        this.detectedHardware = HardwareType.OCULUS;
        WebXRMod.LOGGER.info("WebXR VR device initialised");
        return ok;
    }

    @Override
    public String getName() {
        return "webxr";
    }

    @Override
    public String getRuntimeName() {
        return "WebXR";
    }

    @Override
    public boolean isActive() {
        return XRState.isVrActive();
    }

    @Override
    public float getIPD() {
        return XRState.input().ipd;
    }

    @Override
    public VRRenderer createVRRenderer() {
        return new WebXRStereoRenderer(this);
    }

    @Override
    public boolean handleKeyboardInputs(int key, int scanCode, int action, int modifiers) {
        return false; // the PC keyboard keeps its normal Minecraft meaning
    }

    // ------------------------------------------------------------------ controller models

    @Override
    public Matrix4fc getControllerComponentTransform(int controller, String componentName) {
        if (componentName.equals("tip")) {
            return controller == 0 ? transform.tipR : transform.tipL;
        } else if (componentName.equals("handgrip")) {
            return controller == 0 ? transform.handGripR : transform.handGripL;
        }
        return new Matrix4f();
    }

    private void pickTransform(String profile) {
        if (profile == null || profile.equals(lastProfile)) return;
        lastProfile = profile;
        String p = profile.toLowerCase();
        ControllerTransform t = ControllerTransform.QUEST2_PRO_PLUS;
        if (p.contains("index")) t = ControllerTransform.INDEX;
        else if (p.contains("vive")) t = ControllerTransform.VIVE;
        else if (p.contains("pico")) t = ControllerTransform.PICO4;
        else if (p.equals("oculus-touch")) t = ControllerTransform.RIFT_QUEST1;
        this.transform = t;
        WebXRMod.LOGGER.info("WebXR controller profile '{}' -> {}", profile, t);
    }

    // ------------------------------------------------------------------ tracking

    /** Pose sequence number the frame being rendered was based on (sent along with the video frame). */
    public int polledSeq() {
        return polledSeq;
    }

    @Override
    public void poll(long frameIndex) {
        if (!this.initialized) return;
        XRInput in = XRState.input();
        this.polledSeq = in.seq;
        pickTransform(in.profile);

        // field of view reported by the headset -> render with it
        if (this.dh.vrRenderer instanceof WebXRStereoRenderer r) r.applyView(XRState.view());
        // hand any finished video frame to the encoder threads as early as possible (less latency)
        FrameGrabber.INSTANCE.pump();

        // head
        this.headIsTracking = true;
        Quaternionf hq = new Quaternionf(in.hmd[3], in.hmd[4], in.hmd[5], in.hmd[6]).normalize();
        this.hmdPose.rotation(hq).setTranslation(in.hmd[0], in.hmd[1], in.hmd[2]);
        float half = in.ipd * 0.5f;
        this.hmdPoseLeftEye.m30(-half);
        this.hmdPoseRightEye.m30(half);

        // hands: slot 0 = main/right, slot 1 = off/left (swapped when the player uses "reverse hands")
        boolean reverse = this.dh.vrSettings.reverseHands;
        for (int slot = 0; slot < 2; slot++) {
            XRInput.Hand h = in.hands[reverse ? 1 - slot : slot];
            Quaternionf q = new Quaternionf(h.pose[3], h.pose[4], h.pose[5], h.pose[6]).normalize();
            this.controllerPose[slot] = new Matrix4f().rotation(q).setTranslation(h.pose[0], h.pose[1], h.pose[2]);
            this.controllerTracking[slot] = h.present;
        }

        updateAim();
        processInputs();
        hmdSampling();
        this.polled = true;
    }

    // ------------------------------------------------------------------ buttons and sticks

    @Override
    public void processInputs() {
        this.ignorePressesNextFrame = false;
        if (!XRState.isVrActive()) return;

        XRInput in = XRState.input();
        boolean reverse = this.dh.vrSettings.reverseHands;
        XRInput.Hand right = in.hands[reverse ? 1 : 0];
        XRInput.Hand left = in.hands[reverse ? 0 : 1];
        boolean gui = this.mc.screen != null;
        boolean game = !gui;

        // Layout = Vivecraft's default Oculus Touch layout.
        // --- in the world
        digital(getInputAction("key.attack"), R, game && right.trigger > PRESS);
        digital(getInputAction("key.use"), R, game && right.buttonA > PRESS);
        digital(getInputAction("vivecraft.key.radialMenu"), R, game && right.buttonB > PRESS);
        digital(getInputAction("vivecraft.key.hotbarNext"), R, game && right.grip > PRESS);
        digital(getInputAction("vivecraft.key.hotbarPrev"), L, game && left.grip > PRESS);
        digital(getInputAction("vivecraft.key.teleport"), L, game && left.trigger > PRESS);
        digital(getInputAction("key.jump"), L, game && left.stickClick > PRESS);
        digital(getInputAction("key.sneak"), R, game && right.stickClick > PRESS);
        analog(getInputAction("vivecraft.key.freeMoveStrafe"), L, game ? left.stickX : 0, game ? left.stickY : 0);
        analog(getInputAction("vivecraft.key.rotateAxis"), R, game ? right.stickX : 0, game ? right.stickY : 0);

        // --- in menus / inventory
        digital(getInputAction(GuiHandler.KEY_LEFT_CLICK), R, gui && right.trigger > PRESS);
        digital(getInputAction(GuiHandler.KEY_RIGHT_CLICK), R, gui && right.buttonA > PRESS);
        digital(getInputAction(GuiHandler.KEY_MIDDLE_CLICK), R, gui && right.grip > PRESS);
        digital(getInputAction(GuiHandler.KEY_SHIFT), L, gui && left.grip > PRESS);

        // --- always
        digital(getInputAction("key.inventory"), L, left.buttonA > PRESS);
        digital(getInputAction("vivecraft.key.ingameMenuButton"), L, left.buttonB > PRESS);

        // --- contextual (climbing boots, touching things); Vivecraft only enables them when they make sense
        VRInputAction climb = getInputAction("vivecraft.key.climbeyGrab");
        VRInputAction interact = getInputAction("vivecraft.key.vrInteract");
        boolean rGrab = right.trigger > PRESS || right.grip > PRESS;
        boolean lGrab = left.trigger > PRESS || left.grip > PRESS;
        digital(climb, R, rGrab);
        digital(climb, L, lGrab);
        digital(interact, R, rGrab);
        digital(interact, L, lGrab);
    }

    private void digital(VRInputAction a, ControllerType hand, boolean down) {
        if (a == null) return;
        boolean handed = a.isHanded();
        if (handed) a.setCurrentHand(hand);
        VRInputAction.DigitalData d = a.digitalData[handed ? hand.ordinal() : 0];
        boolean changed = d.state != down;
        d.state = down;
        d.isChanged = changed;
        d.isActive = true;
        if (!changed) return;
        if (down) {
            if (a.isEnabled()) a.pressBinding();
        } else {
            a.unpressBinding();
        }
    }

    private void analog(VRInputAction a, ControllerType hand, float x, float y) {
        if (a == null) return;
        boolean handed = a.isHanded();
        if (handed) a.setCurrentHand(hand);
        VRInputAction.AnalogData d = a.analogData[handed ? hand.ordinal() : 0];
        d.deltaX = x - d.x;
        d.deltaY = y - d.y;
        d.x = x;
        d.y = y;
        d.isChanged = d.deltaX != 0 || d.deltaY != 0;
        d.isActive = true;
    }
}
