package dev.vivewebxr;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/** Simple settings file: .minecraft/config/vivecraft-webxr.properties */
public final class WebXRConfig {
    /**
     * Bumped when default values change. A config file written by an older version keeps its
     * ports/keystore, but its picture-quality values are replaced by the new defaults once.
     */
    public static final int CONFIG_VERSION = 2;

    /** Master switch. false = this mod does nothing and Vivecraft behaves normally. */
    public static boolean enabled = true;
    /** Plain HTTP port (works with http://localhost, e.g. via `adb reverse`). 0 = off. */
    public static int httpPort = 8080;
    /** HTTPS port (self-signed certificate). Needed for WebXR from another device. 0 = off. */
    public static int httpsPort = 8443;
    /**
     * Width in pixels of the picture Minecraft renders AND streams (height follows the headset's field of view).
     * The game renders exactly this size, so there is no blurry down-scaling step. 1920 = light, 2048 = default,
     * 2560 = sharp (needs a strong PC + good Wi-Fi), 3072 = very sharp.
     */
    public static int streamWidth = 2048;
    /** Maximum frames per second sent to the headset. */
    public static int streamFps = 60;
    /** Highest JPEG quality 0.1 .. 1.0 (used whenever the network keeps up). */
    public static float jpegQuality = 0.85f;
    /** Lowest JPEG quality the automatic controller may drop to when the Wi-Fi cannot keep up. */
    public static float jpegQualityMin = 0.55f;
    /** Lower the JPEG quality automatically when frames cannot be sent in time (keeps latency low). */
    public static boolean adaptiveQuality = true;
    /** Number of parallel JPEG encoder threads (1..6). More threads = higher fps at big resolutions. */
    public static int encoderThreads = 3;
    /**
     * EXPERIMENTAL. Do not render the right eye (it is never streamed). Roughly doubles the game's fps,
     * but the PC's mirror window may show an empty right half. Turn on only if the game's fps is the problem.
     */
    public static boolean skipRightEye = false;
    /** Turn Vivecraft's VR mode on automatically (so you do not have to enable it in its settings). */
    public static boolean forceVR = true;
    /** Frames to wait (after Minecraft finished loading) before VR is switched on. */
    public static int startDelayFrames = 10;
    /** Optional: path to your own PKCS12 keystore (instead of the built-in self-signed one). */
    public static String keystorePath = "";
    public static String keystorePassword = "changeit";

    private WebXRConfig() {}

    public static void load() {
        Path file = FabricLoader.getInstance().getConfigDir().resolve("vivecraft-webxr.properties");
        Properties p = new Properties();
        if (Files.exists(file)) {
            try (InputStream in = Files.newInputStream(file)) {
                p.load(in);
            } catch (IOException e) {
                WebXRMod.LOGGER.warn("Could not read {}: {}", file, e.toString());
            }
        }
        boolean oldFile = integer(p, "configVersion", 1, 1, 1000) < CONFIG_VERSION;

        enabled = bool(p, "enabled", enabled);
        httpPort = integer(p, "httpPort", httpPort, 0, 65535);
        httpsPort = integer(p, "httpsPort", httpsPort, 0, 65535);
        if (!oldFile) {
            streamWidth = integer(p, "streamWidth", streamWidth, 320, 4096);
            streamFps = integer(p, "streamFps", streamFps, 5, 120);
            jpegQuality = decimal(p, "jpegQuality", jpegQuality, 0.1f, 1.0f);
        } else {
            WebXRMod.LOGGER.info("WebXR: upgrading config - picture settings reset to the new, sharper defaults "
                    + "({} px wide, {} fps, JPEG quality {})", streamWidth, streamFps, jpegQuality);
        }
        jpegQualityMin = Math.min(jpegQuality, decimal(p, "jpegQualityMin", jpegQualityMin, 0.1f, 1.0f));
        adaptiveQuality = bool(p, "adaptiveQuality", adaptiveQuality);
        encoderThreads = integer(p, "encoderThreads", encoderThreads, 1, 6);
        skipRightEye = bool(p, "skipRightEye", skipRightEye);
        forceVR = bool(p, "forceVR", forceVR);
        startDelayFrames = integer(p, "startDelayFrames", startDelayFrames, 0, 600);
        keystorePath = p.getProperty("keystorePath", keystorePath).trim();
        keystorePassword = p.getProperty("keystorePassword", keystorePassword);
        save(file);
    }

    private static void save(Path file) {
        Properties p = new Properties();
        p.setProperty("configVersion", String.valueOf(CONFIG_VERSION));
        p.setProperty("enabled", String.valueOf(enabled));
        p.setProperty("httpPort", String.valueOf(httpPort));
        p.setProperty("httpsPort", String.valueOf(httpsPort));
        p.setProperty("streamWidth", String.valueOf(streamWidth));
        p.setProperty("streamFps", String.valueOf(streamFps));
        p.setProperty("jpegQuality", String.valueOf(jpegQuality));
        p.setProperty("jpegQualityMin", String.valueOf(jpegQualityMin));
        p.setProperty("adaptiveQuality", String.valueOf(adaptiveQuality));
        p.setProperty("encoderThreads", String.valueOf(encoderThreads));
        p.setProperty("skipRightEye", String.valueOf(skipRightEye));
        p.setProperty("forceVR", String.valueOf(forceVR));
        p.setProperty("startDelayFrames", String.valueOf(startDelayFrames));
        p.setProperty("keystorePath", keystorePath);
        p.setProperty("keystorePassword", keystorePassword);
        try (OutputStream out = Files.newOutputStream(file)) {
            p.store(out, "Vivecraft WebXR Bridge settings (restart the game after editing)");
        } catch (IOException e) {
            WebXRMod.LOGGER.warn("Could not write {}: {}", file, e.toString());
        }
    }

    private static boolean bool(Properties p, String k, boolean def) {
        return Boolean.parseBoolean(p.getProperty(k, String.valueOf(def)).trim());
    }

    private static int integer(Properties p, String k, int def, int min, int max) {
        try {
            int v = Integer.parseInt(p.getProperty(k, String.valueOf(def)).trim());
            return Math.max(min, Math.min(max, v));
        } catch (NumberFormatException e) {
            return def;
        }
    }

    private static float decimal(Properties p, String k, float def, float min, float max) {
        try {
            float v = Float.parseFloat(p.getProperty(k, String.valueOf(def)).trim());
            if (Float.isNaN(v)) return def;
            return Math.max(min, Math.min(max, v));
        } catch (NumberFormatException e) {
            return def;
        }
    }
}
