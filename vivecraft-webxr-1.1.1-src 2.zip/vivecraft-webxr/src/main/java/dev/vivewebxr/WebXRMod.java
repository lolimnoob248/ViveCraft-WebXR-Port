package dev.vivewebxr;

import dev.vivewebxr.render.FrameGrabber;
import dev.vivewebxr.server.WebXRServer;
import net.fabricmc.api.ClientModInitializer;
import net.minecraft.client.Minecraft;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.vivecraft.client_vr.ClientDataHolderVR;
import org.vivecraft.client_vr.VRState;

public final class WebXRMod implements ClientModInitializer {
    public static final Logger LOGGER = LoggerFactory.getLogger("vivecraft-webxr");

    /** After a failed Vivecraft VR start we wait this long before trying again. */
    private static final long RETRY_DELAY_NANOS = 3_000_000_000L;
    private static final int MAX_START_FAILURES = 3;

    private static WebXRServer server;

    // --- start-up state (render thread only)
    private static int framesSinceLoaded;
    private static boolean weSwitchedVrOn;
    private static int startFailures;
    private static long nextStartAttemptNanos;
    private static boolean gaveUp;

    @Override
    public void onInitializeClient() {
        WebXRConfig.load();
        if (!WebXRConfig.enabled) {
            LOGGER.info("WebXR bridge is disabled in config/vivecraft-webxr.properties");
            return;
        }
        server = new WebXRServer();
        server.start();
        FrameGrabber.INSTANCE.setServer(server);
        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            if (server != null) server.stop();
        }, "WebXR-shutdown"));

        LOGGER.info("WebXR bridge ready. Open one of these in your headset browser:");
        for (String ip : NetUtil.lanAddresses()) {
            if (server.httpsPortBound > 0) LOGGER.info("   https://{}:{}", ip, server.httpsPortBound);
            if (server.httpPortBound > 0) LOGGER.info("   http://{}:{}", ip, server.httpPortBound);
        }
    }

    public static WebXRServer server() {
        return server;
    }

    /**
     * True once Minecraft is completely done loading: the resource reload (textures, fonts, shaders) has
     * finished AND the loading overlay is gone. Vivecraft's VR start-up builds GUI textures, shaders and the
     * menu world, so it must never run before this point. (This was the first-version crash: VR was switched
     * on during the very first frame, while the textures were still loading.)
     */
    private static boolean minecraftFinishedLoading(Minecraft mc) {
        return mc != null
                && mc.getOverlay() == null
                && mc.getTextureManager() != null
                && mc.font != null
                && mc.getWindow() != null;
    }

    /** Called at the start of every Minecraft frame (from MinecraftMixin). */
    public static void onFrame() {
        if (!WebXRConfig.enabled || !WebXRConfig.forceVR || gaveUp) return;

        Minecraft mc = Minecraft.getInstance();
        if (!minecraftFinishedLoading(mc)) {
            framesSinceLoaded = 0;
            return;
        }
        // Let the title screen draw a few frames before the (heavy) VR start-up happens.
        if (framesSinceLoaded < WebXRConfig.startDelayFrames) {
            framesSinceLoaded++;
            return;
        }

        ClientDataHolderVR dh = ClientDataHolderVR.getInstance();
        if (dh == null || dh.vrSettings == null || dh.completelyDisabled) return;

        if (VRState.VR_INITIALIZED) {
            // VR is up. Keep hot-switching on: Vivecraft renders VR only while isActive() is true
            // (= a browser is in "Enter VR"); otherwise the game looks and plays like normal Minecraft.
            dh.vrSettings.vrHotswitchingEnabled = true;
            weSwitchedVrOn = false;
            startFailures = 0;
            return;
        }

        if (VRState.VR_ENABLED) {
            return; // Vivecraft is in the middle of starting up (it delays its init by one frame)
        }

        // Not enabled and not initialised.
        if (weSwitchedVrOn) {
            // We turned it on earlier, and now it is off again without ever initialising:
            // Vivecraft's start-up failed and it destroyed VR (it also shows its own error screen).
            weSwitchedVrOn = false;
            startFailures++;
            nextStartAttemptNanos = System.nanoTime() + RETRY_DELAY_NANOS;
            if (startFailures >= MAX_START_FAILURES) {
                gaveUp = true;
                LOGGER.error("WebXR: Vivecraft failed to start VR {} times in a row - giving up for this session. "
                        + "Check the log above for Vivecraft's error.", startFailures);
                return;
            }
            LOGGER.warn("WebXR: Vivecraft failed to start VR (attempt {}/{}), retrying in 3 s",
                    startFailures, MAX_START_FAILURES);
            return;
        }
        if (System.nanoTime() < nextStartAttemptNanos) return;

        dh.vrSettings.vrHotswitchingEnabled = true;
        VRState.VR_ENABLED = true;
        weSwitchedVrOn = true;
        LOGGER.info("WebXR: Minecraft finished loading - starting Vivecraft VR");
    }
}
