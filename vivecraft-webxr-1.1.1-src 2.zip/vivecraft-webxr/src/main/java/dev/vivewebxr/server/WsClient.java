package dev.vivewebxr.server;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import dev.vivewebxr.WebXRMod;
import dev.vivewebxr.XRInput;
import dev.vivewebxr.XRState;

import java.io.ByteArrayOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayDeque;
import java.util.concurrent.atomic.AtomicInteger;

/** One connected browser (WebSocket, RFC 6455). */
final class WsClient {
    private static final int MAX_MESSAGE = 1 << 20;

    /** Video frames that were replaced by a newer one before they could be sent (= the network is too slow). */
    private static final AtomicInteger DROPPED = new AtomicInteger();

    static int takeDropped() {
        return DROPPED.getAndSet(0);
    }

    final int id;
    private final Socket socket;
    private final InputStream in;
    private final OutputStream out;

    private final Object lock = new Object();
    private byte[] pendingFrame;
    private int lastQueuedFrameId;
    private final ArrayDeque<String> pendingText = new ArrayDeque<>();
    private volatile boolean closed;
    volatile boolean inVr;

    WsClient(int id, Socket socket, InputStream in, OutputStream out) {
        this.id = id;
        this.socket = socket;
        this.in = in;
        this.out = out;
    }

    void run() throws IOException {
        Thread sender = new Thread(this::senderLoop, "WebXR-send-" + id);
        sender.setDaemon(true);
        sender.start();
        sendText("{\"t\":\"hello\",\"v\":1}");
        try {
            readLoop();
        } catch (SocketTimeoutException e) {
            WebXRMod.LOGGER.info("WebXR client {} timed out", id);
        } catch (EOFException ignored) {
        }
    }

    // ---------------------------------------------------------------- sending

    /**
     * @param message 16-byte frame header + JPEG (built by FrameGrabber)
     * @param frameId increasing id; with several encoder threads a frame can finish late - an older frame
     *                must never replace a newer one
     */
    void sendFrame(byte[] message, int frameId) {
        synchronized (lock) {
            if (frameId <= lastQueuedFrameId) return;
            lastQueuedFrameId = frameId;
            if (pendingFrame != null) DROPPED.incrementAndGet();
            pendingFrame = message; // newest frame wins; an old unsent frame is dropped
            lock.notifyAll();
        }
    }

    void sendText(String s) {
        synchronized (lock) {
            if (pendingText.size() < 256) pendingText.add(s);
            lock.notifyAll();
        }
    }

    private void senderLoop() {
        try {
            while (!closed) {
                String text;
                byte[] frame = null;
                synchronized (lock) {
                    while (!closed && pendingFrame == null && pendingText.isEmpty()) lock.wait(1000);
                    if (closed) return;
                    text = pendingText.poll();
                    if (text == null) {
                        frame = pendingFrame;
                        pendingFrame = null;
                    }
                }
                if (text != null) write(0x1, text.getBytes(StandardCharsets.UTF_8));
                else if (frame != null) write(0x2, frame);
            }
        } catch (Exception e) {
            close();
        }
    }

    private void write(int opcode, byte[] payload) throws IOException {
        ByteArrayOutputStream h = new ByteArrayOutputStream(10);
        h.write(0x80 | opcode);
        int n = payload.length;
        if (n < 126) {
            h.write(n);
        } else if (n < 65536) {
            h.write(126);
            h.write(n >> 8);
            h.write(n);
        } else {
            h.write(127);
            for (int i = 7; i >= 0; i--) h.write((int) (((long) n >> (8 * i)) & 0xFF));
        }
        synchronized (out) {
            out.write(h.toByteArray());
            out.write(payload);
            out.flush();
        }
    }

    // ---------------------------------------------------------------- receiving

    private void readLoop() throws IOException {
        ByteArrayOutputStream message = new ByteArrayOutputStream();
        int messageOpcode = 0;
        while (!closed) {
            int b0 = in.read();
            if (b0 < 0) return;
            int b1 = readByte();
            boolean fin = (b0 & 0x80) != 0;
            int opcode = b0 & 0x0F;
            boolean masked = (b1 & 0x80) != 0;
            long len = b1 & 0x7F;
            if (len == 126) {
                len = ((long) readByte() << 8) | readByte();
            } else if (len == 127) {
                len = 0;
                for (int i = 0; i < 8; i++) len = (len << 8) | readByte();
            }
            if (len < 0 || len > MAX_MESSAGE) throw new IOException("message too large");
            byte[] mask = new byte[4];
            if (masked) readFully(mask);
            byte[] payload = new byte[(int) len];
            readFully(payload);
            if (masked) for (int i = 0; i < payload.length; i++) payload[i] ^= mask[i & 3];

            switch (opcode) {
                case 0x8 -> { // close
                    try {
                        write(0x8, new byte[0]);
                    } catch (IOException ignored) {
                    }
                    return;
                }
                case 0x9 -> write(0xA, payload); // ping -> pong
                case 0xA -> { }                   // pong
                default -> {                      // 0x0 continuation, 0x1 text, 0x2 binary
                    if (opcode != 0x0) {
                        message.reset();
                        messageOpcode = opcode;
                    }
                    message.write(payload);
                    if (message.size() > MAX_MESSAGE) throw new IOException("message too large");
                    if (fin) {
                        if (messageOpcode == 0x1) onText(message.toString(StandardCharsets.UTF_8));
                        message.reset();
                    }
                }
            }
        }
    }

    private int readByte() throws IOException {
        int b = in.read();
        if (b < 0) throw new EOFException();
        return b;
    }

    private void readFully(byte[] buf) throws IOException {
        int off = 0;
        while (off < buf.length) {
            int n = in.read(buf, off, buf.length - off);
            if (n < 0) throw new EOFException();
            off += n;
        }
    }

    private void onText(String text) {
        try {
            JsonObject o = JsonParser.parseString(text).getAsJsonObject();
            String t = o.has("t") ? o.get("t").getAsString() : "";
            switch (t) {
                case "p" -> {
                    if (inVr) XRState.onInput(id, XRInput.parse(o));
                }
                case "v" -> { // field of view of the headset (see XRState.View)
                    if (inVr) XRState.setView(id, o.get("tx").getAsFloat(), o.get("ty").getAsFloat());
                }
                case "s" -> { // session start / end
                    boolean on = o.get("vr").getAsBoolean();
                    if (on) {
                        boolean ok = XRState.sessionChanged(id, true);
                        inVr = ok;
                        sendText("{\"t\":\"session\",\"ok\":" + ok + "}");
                    } else {
                        inVr = false;
                        XRState.sessionChanged(id, false);
                    }
                }
                default -> { } // "k" keep-alive etc.
            }
        } catch (Exception e) {
            WebXRMod.LOGGER.debug("bad message from client {}: {}", id, e.toString());
        }
    }

    void close() {
        if (closed) return;
        closed = true;
        inVr = false;
        synchronized (lock) {
            lock.notifyAll();
        }
        try {
            socket.close();
        } catch (IOException ignored) {
        }
    }
}
