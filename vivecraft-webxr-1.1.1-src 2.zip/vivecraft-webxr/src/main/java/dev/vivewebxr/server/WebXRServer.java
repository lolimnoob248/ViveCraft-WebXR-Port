package dev.vivewebxr.server;

import dev.vivewebxr.WebXRConfig;
import dev.vivewebxr.WebXRMod;
import dev.vivewebxr.XRState;

import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLServerSocket;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.KeyStore;
import java.security.MessageDigest;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Tiny HTTP + HTTPS + WebSocket server, no external libraries.
 * Serves the WebXR web page (from the mod's resources) and the /ws socket used for video + tracking.
 */
public final class WebXRServer {
    private static final String WS_GUID = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11";

    private final List<WsClient> clients = new CopyOnWriteArrayList<>();
    private final AtomicInteger ids = new AtomicInteger(1);
    private volatile boolean running;
    private ServerSocket httpSocket;
    private ServerSocket httpsSocket;

    public volatile String httpError = "";
    public volatile String httpsError = "";
    public volatile int httpPortBound = -1;
    public volatile int httpsPortBound = -1;

    public void start() {
        running = true;
        if (WebXRConfig.httpPort > 0) {
            try {
                httpSocket = new ServerSocket(WebXRConfig.httpPort, 50);
                httpPortBound = httpSocket.getLocalPort();
                accept(httpSocket, "WebXR-http");
            } catch (IOException e) {
                httpError = String.valueOf(e.getMessage());
                WebXRMod.LOGGER.error("WebXR: cannot open HTTP port {}: {}", WebXRConfig.httpPort, e.toString());
            }
        }
        if (WebXRConfig.httpsPort > 0) {
            try {
                SSLContext ctx = buildSsl();
                SSLServerSocket s = (SSLServerSocket) ctx.getServerSocketFactory()
                        .createServerSocket(WebXRConfig.httpsPort, 50, (InetAddress) null);
                httpsSocket = s;
                httpsPortBound = s.getLocalPort();
                accept(httpsSocket, "WebXR-https");
            } catch (Exception e) {
                httpsError = String.valueOf(e.getMessage());
                WebXRMod.LOGGER.error("WebXR: cannot open HTTPS port {}: {}", WebXRConfig.httpsPort, e.toString());
            }
        }
    }

    public void stop() {
        running = false;
        closeQuietly(httpSocket);
        closeQuietly(httpsSocket);
        for (WsClient c : clients) c.close();
    }

    private static void closeQuietly(ServerSocket s) {
        try {
            if (s != null) s.close();
        } catch (IOException ignored) {
        }
    }

    private SSLContext buildSsl() throws Exception {
        KeyStore ks = KeyStore.getInstance("PKCS12");
        char[] pw = WebXRConfig.keystorePassword.toCharArray();
        String custom = WebXRConfig.keystorePath;
        if (custom != null && !custom.isEmpty()) {
            try (InputStream in = Files.newInputStream(Path.of(custom))) {
                ks.load(in, pw);
            }
        } else {
            pw = "changeit".toCharArray();
            try (InputStream in = WebXRServer.class.getResourceAsStream("/webxr.p12")) {
                if (in == null) throw new IOException("built-in keystore missing");
                ks.load(in, pw);
            }
        }
        KeyManagerFactory kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
        kmf.init(ks, pw);
        SSLContext ctx = SSLContext.getInstance("TLS");
        ctx.init(kmf.getKeyManagers(), null, null);
        return ctx;
    }

    private void accept(ServerSocket server, String name) {
        Thread t = new Thread(() -> {
            while (running && !server.isClosed()) {
                try {
                    Socket s = server.accept();
                    Thread c = new Thread(() -> handle(s), "WebXR-conn");
                    c.setDaemon(true);
                    c.start();
                } catch (IOException e) {
                    if (running && !server.isClosed()) {
                        WebXRMod.LOGGER.debug("accept failed: {}", e.toString());
                    }
                }
            }
        }, name);
        t.setDaemon(true);
        t.start();
    }

    // ------------------------------------------------------------------ connections

    private void handle(Socket s) {
        boolean keep = false;
        try {
            s.setTcpNoDelay(true);
            s.setSoTimeout(15_000);
            InputStream in = s.getInputStream();
            OutputStream out = s.getOutputStream();

            String requestLine = readLine(in);
            if (requestLine == null || requestLine.isEmpty()) return;
            Map<String, String> headers = new HashMap<>();
            for (int i = 0; i < 100; i++) {
                String line = readLine(in);
                if (line == null) return;
                if (line.isEmpty()) break;
                int c = line.indexOf(':');
                if (c > 0) headers.put(line.substring(0, c).trim().toLowerCase(Locale.ROOT), line.substring(c + 1).trim());
            }
            String[] parts = requestLine.split(" ");
            if (parts.length < 2 || !parts[0].equals("GET")) {
                respond(out, 405, "text/plain", "Method not allowed".getBytes(StandardCharsets.UTF_8));
                return;
            }
            String path = parts[1];
            int q = path.indexOf('?');
            if (q >= 0) path = path.substring(0, q);

            if (path.equals("/ws") && "websocket".equalsIgnoreCase(headers.getOrDefault("upgrade", ""))) {
                if (!sameOrigin(headers)) {
                    respond(out, 403, "text/plain", "Forbidden".getBytes(StandardCharsets.UTF_8));
                    return;
                }
                String key = headers.get("sec-websocket-key");
                if (key == null) {
                    respond(out, 400, "text/plain", "Bad request".getBytes(StandardCharsets.UTF_8));
                    return;
                }
                String accept = Base64.getEncoder().encodeToString(
                        MessageDigest.getInstance("SHA-1").digest((key + WS_GUID).getBytes(StandardCharsets.ISO_8859_1)));
                String resp = "HTTP/1.1 101 Switching Protocols\r\n"
                        + "Upgrade: websocket\r\nConnection: Upgrade\r\n"
                        + "Sec-WebSocket-Accept: " + accept + "\r\n\r\n";
                out.write(resp.getBytes(StandardCharsets.ISO_8859_1));
                out.flush();
                keep = true;
                s.setSoTimeout(30_000); // the page sends a keep-alive every few seconds
                // A small send buffer: frames waiting inside the operating system's buffer cannot be replaced by a
                // newer one, so a big buffer = old pictures = extra latency.
                try {
                    s.setSendBufferSize(512 * 1024);
                } catch (Exception ignored) {
                }
                WsClient client = new WsClient(ids.getAndIncrement(), s, in, out);
                clients.add(client);
                XRState.clientConnected();
                try {
                    client.run();
                } finally {
                    clients.remove(client);
                    XRState.clientGone(client.id);
                    client.close();
                }
                return;
            }

            switch (path) {
                case "/", "/index.html" -> serveResource(out, "/web/index.html", "text/html; charset=utf-8");
                case "/client.js" -> serveResource(out, "/web/client.js", "application/javascript; charset=utf-8");
                case "/status" -> respond(out, 200, "application/json",
                        ("{\"vrActive\":" + XRState.isVrActive() + ",\"clients\":" + XRState.clients() + "}")
                                .getBytes(StandardCharsets.UTF_8));
                default -> respond(out, 404, "text/plain", "Not found".getBytes(StandardCharsets.UTF_8));
            }
        } catch (Exception e) {
            WebXRMod.LOGGER.debug("WebXR connection ended: {}", e.toString());
        } finally {
            if (!keep) {
                try {
                    s.close();
                } catch (IOException ignored) {
                }
            }
        }
    }

    /** Blocks other websites from opening a socket to us from the browser on this PC. */
    private static boolean sameOrigin(Map<String, String> h) {
        String origin = h.get("origin");
        if (origin == null) return true;
        String host = h.get("host");
        int i = origin.indexOf("://");
        String oh = i >= 0 ? origin.substring(i + 3) : origin;
        return host != null && host.equalsIgnoreCase(oh);
    }

    private static void serveResource(OutputStream out, String res, String type) throws IOException {
        try (InputStream r = WebXRServer.class.getResourceAsStream(res)) {
            if (r == null) {
                respond(out, 404, "text/plain", "Missing resource".getBytes(StandardCharsets.UTF_8));
                return;
            }
            respond(out, 200, type, r.readAllBytes());
        }
    }

    private static void respond(OutputStream out, int code, String type, byte[] body) throws IOException {
        String status = switch (code) {
            case 200 -> "OK";
            case 400 -> "Bad Request";
            case 403 -> "Forbidden";
            case 404 -> "Not Found";
            case 405 -> "Method Not Allowed";
            default -> "Error";
        };
        String head = "HTTP/1.1 " + code + " " + status + "\r\n"
                + "Content-Type: " + type + "\r\n"
                + "Content-Length: " + body.length + "\r\n"
                + "Cache-Control: no-store\r\n"
                + "Connection: close\r\n\r\n";
        out.write(head.getBytes(StandardCharsets.ISO_8859_1));
        out.write(body);
        out.flush();
    }

    private static String readLine(InputStream in) throws IOException {
        ByteArrayOutputStream b = new ByteArrayOutputStream(128);
        int c;
        while ((c = in.read()) != -1) {
            if (c == '\n') break;
            if (c != '\r') b.write(c);
            if (b.size() > 16_384) throw new IOException("header too long");
        }
        if (c == -1 && b.size() == 0) return null;
        return b.toString(StandardCharsets.ISO_8859_1);
    }

    // ------------------------------------------------------------------ outgoing

    /** True if the browser that owns the VR session wants video (so it makes sense to spend time encoding). */
    public boolean wantsFrames() {
        int owner = XRState.owner();
        for (WsClient c : clients) if (c.id == owner && c.inVr) return true;
        return false;
    }

    /** @param message 16-byte frame header + JPEG */
    public void broadcastFrame(byte[] message, int frameId) {
        int owner = XRState.owner();
        for (WsClient c : clients) if (c.id == owner && c.inVr) c.sendFrame(message, frameId);
    }

    /** Number of frames dropped since the last call because the network could not keep up. */
    public int takeDroppedFrames() {
        return WsClient.takeDropped();
    }

    /** Sends a text message to the browser that is currently playing. */
    public void sendToPlayer(String json) {
        int owner = XRState.owner();
        for (WsClient c : clients) if (c.id == owner) c.sendText(json);
    }
}
