package dev.vivewebxr.client;

import dev.vivewebxr.NetUtil;
import dev.vivewebxr.WebXRConfig;
import dev.vivewebxr.WebXRMod;
import dev.vivewebxr.XRState;
import dev.vivewebxr.server.WebXRServer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;

import java.util.ArrayList;
import java.util.List;

/** The "open this address in your headset" panel shown on the PC until a headset enters VR. */
public final class Overlay {
    private static long lastDrawNanos;
    private static List<String> cachedIps = new ArrayList<>();
    private static long ipsAtNanos;

    private Overlay() {}

    /** @param fromScreen true when called while a Screen is rendering, false for the in-game HUD */
    public static void draw(GuiGraphics g, boolean fromScreen) {
        if (!WebXRConfig.enabled || XRState.isVrActive()) return;
        Minecraft mc = Minecraft.getInstance();
        if ((mc.screen != null) != fromScreen) return;

        long now = System.nanoTime();
        if (now - lastDrawNanos < 1_000_000L) return; // already drawn this frame
        lastDrawNanos = now;

        WebXRServer server = WebXRMod.server();
        if (server == null) return;
        if (now - ipsAtNanos > 5_000_000_000L) {
            cachedIps = NetUtil.lanAddresses();
            ipsAtNanos = now;
        }

        List<String> lines = new ArrayList<>();
        lines.add("VIVECRAFT WEBXR - waiting for a headset");
        lines.add("On your headset browser open one of these, then press \"Enter VR\":");
        List<String> ips = cachedIps.isEmpty() ? List.of("<this-PC-ip>") : cachedIps;
        for (String ip : ips) {
            if (server.httpsPortBound > 0) lines.add("   https://" + ip + ":" + server.httpsPortBound + "   (use this one)");
            if (server.httpPortBound > 0) lines.add("   http://" + ip + ":" + server.httpPortBound);
        }
        if (server.httpsPortBound > 0) lines.add("HTTPS: accept the certificate warning once (\"Advanced\" -> continue).");
        if (!server.httpsError.isEmpty()) lines.add("HTTPS port error: " + server.httpsError);
        if (!server.httpError.isEmpty()) lines.add("HTTP port error: " + server.httpError);
        int c = XRState.clients();
        lines.add(c == 0 ? "No browser connected yet." : c + " browser(s) connected, none is in VR yet.");

        Font font = mc.font;
        int maxW = 0;
        for (String s : lines) maxW = Math.max(maxW, font.width(s));
        int pad = 6;
        int lineH = font.lineHeight + 2;
        int w = maxW + pad * 2;
        int h = lines.size() * lineH + pad * 2;
        int x = (g.guiWidth() - w) / 2;
        int y = 6;

        g.fill(x, y, x + w, y + h, 0xC0101018);
        g.fill(x, y, x + w, y + 1, 0xFF55FF55);
        int ty = y + pad;
        for (int i = 0; i < lines.size(); i++) {
            int color = i == 0 ? 0xFF55FF55 : 0xFFFFFFFF;
            g.drawString(font, lines.get(i), x + pad, ty, color);
            ty += lineH;
        }
    }
}
