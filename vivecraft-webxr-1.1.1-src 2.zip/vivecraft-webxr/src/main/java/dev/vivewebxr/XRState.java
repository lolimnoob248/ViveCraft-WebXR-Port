package dev.vivewebxr;

/**
 * Shared state between the network threads (writers) and the Minecraft render thread (reader).
 * Only one browser at a time "owns" the VR session; the first one that presses Enter VR gets it.
 */
public final class XRState {
    private static final long TIMEOUT_NANOS = 5_000_000_000L;

    private static volatile int owner = -1;
    private static volatile boolean inVr;
    private static volatile XRInput latest = XRInput.standing();
    private static volatile long lastInputNanos;
    private static volatile int connectedClients;

    /**
     * What the headset can see, as measured by the browser: half-width / half-height of the picture as tangents
     * (tan of the half field-of-view angle). Minecraft renders with exactly this frustum and the browser puts the
     * picture on a screen of exactly this angular size, so it fills the headset with no black borders.
     */
    public static final class View {
        public final float tx, ty;
        public final int version;

        View(float tx, float ty, int version) {
            this.tx = tx;
            this.ty = ty;
            this.version = version;
        }
    }

    // Defaults match a Quest 2 / 3 class headset (about 112 x 100 degrees) until the browser reports the real values.
    private static volatile View view = new View(1.45f, 1.20f, 0);

    private XRState() {}

    public static View view() {
        return view;
    }

    /** The owner of the VR session reports its field of view. Tiny changes (< 3 %) are ignored. */
    public static synchronized void setView(int clientId, float tx, float ty) {
        if (clientId != owner || !inVr) return;
        if (!(tx > 0.3f && tx < 6f && ty > 0.3f && ty < 6f)) return; // also rejects NaN
        View c = view;
        if (Math.abs(tx - c.tx) < 0.03f * c.tx && Math.abs(ty - c.ty) < 0.03f * c.ty) return;
        view = new View(tx, ty, c.version + 1);
        WebXRMod.LOGGER.info("WebXR headset field of view: {} x {} degrees",
                Math.round(Math.toDegrees(Math.atan(tx)) * 2), Math.round(Math.toDegrees(Math.atan(ty)) * 2));
    }

    /** True while a browser is inside an "Enter VR" session and is still sending data. */
    public static boolean isVrActive() {
        return inVr && (System.nanoTime() - lastInputNanos) < TIMEOUT_NANOS;
    }

    public static XRInput input() {
        return latest;
    }

    public static int clients() {
        return connectedClients;
    }

    public static synchronized void clientConnected() {
        connectedClients++;
    }

    public static synchronized void clientGone(int id) {
        connectedClients = Math.max(0, connectedClients - 1);
        sessionChanged(id, false);
    }

    /** @return true if this client now owns (or still owns) the VR session / was allowed to end it */
    public static synchronized boolean sessionChanged(int clientId, boolean on) {
        if (on) {
            if (inVr && owner != clientId && (System.nanoTime() - lastInputNanos) < TIMEOUT_NANOS) {
                return false; // someone else is already playing
            }
            owner = clientId;
            inVr = true;
            lastInputNanos = System.nanoTime();
            latest = XRInput.standing();
            WebXRMod.LOGGER.info("WebXR session started (client {})", clientId);
            return true;
        }
        if (owner == clientId && inVr) {
            inVr = false;
            owner = -1;
            WebXRMod.LOGGER.info("WebXR session ended (client {})", clientId);
            return true;
        }
        return false;
    }

    public static void onInput(int clientId, XRInput in) {
        if (clientId != owner || !inVr) return;
        latest = in;
        lastInputNanos = System.nanoTime();
    }

    public static int owner() {
        return owner;
    }
}
