'use strict';
/* Vivecraft WebXR client.
 *  - WebSocket to the PC:   receives JPEG frames (binary) and haptic commands (text),
 *                           sends head/controller poses ({"t":"p",...}) and session start/stop ({"t":"s","vr":bool}).
 *  - WebXR "immersive-vr":  shows the latest JPEG on a flat screen locked to the head.
 */
const $ = (id) => document.getElementById(id);
const params = new URLSearchParams(location.search);
const SCREEN_DIST = clampNum(parseFloat(params.get('d')), 0.5, 5, 1.5);
const SCREEN_WIDTH = clampNum(parseFloat(params.get('w')), 0.5, 6, 2.0);

function clampNum(v, lo, hi, def) { return Number.isFinite(v) ? Math.min(hi, Math.max(lo, v)) : def; }
const r4 = (v) => Math.round(v * 10000) / 10000;

// ------------------------------------------------------------------ state
let ws = null, wsOpen = false;
let session = null, refSpace = null, gl = null, glLayer = null;
let floorOffset = 0;
let prog = null, vbo = null, tex = null, loc = {};
let bitmap = null, newBitmap = false, decoding = false, nextBlob = null, frameAspect = 16 / 9;
let gotFrame = false;

function setStatus(text) { $('status').textContent = text; }
function showHelp(html) { const h = $('help'); h.innerHTML = html; h.style.display = 'block'; }

// ------------------------------------------------------------------ network
function connect() {
  const proto = location.protocol === 'https:' ? 'wss' : 'ws';
  ws = new WebSocket(proto + '://' + location.host + '/ws');
  ws.binaryType = 'arraybuffer';
  ws.onopen = () => { wsOpen = true; if (!session) setStatus('Connected to Minecraft. Press Enter VR.'); updateButton(); };
  ws.onclose = () => {
    wsOpen = false; updateButton();
    if (session) { try { session.end(); } catch (e) {} }
    setStatus('Connection lost. Retrying…');
    setTimeout(connect, 2000);
  };
  ws.onerror = () => {};
  ws.onmessage = onMessage;
}

function onMessage(ev) {
  if (typeof ev.data !== 'string') {
    nextBlob = new Blob([ev.data], { type: 'image/jpeg' });
    if (!decoding) pumpDecode();
    return;
  }
  let m; try { m = JSON.parse(ev.data); } catch (e) { return; }
  if (m.t === 'h') haptic(m.hand, m.d, m.a);
  else if (m.t === 'session' && m.ok === false) {
    setStatus('Another headset is already playing.');
    if (session) session.end();
  }
}

async function pumpDecode() {
  decoding = true;
  while (nextBlob) {
    const b = nextBlob; nextBlob = null;
    try {
      const bm = await createImageBitmap(b);
      if (bitmap) bitmap.close();
      bitmap = bm; newBitmap = true; gotFrame = true;
      frameAspect = bm.width / bm.height;
    } catch (e) { /* bad frame, ignore */ }
  }
  decoding = false;
}

setInterval(() => { if (wsOpen) ws.send('{"t":"k"}'); }, 4000);

function send(obj) { if (wsOpen) ws.send(JSON.stringify(obj)); }

function haptic(hand, durMs, amp) {
  if (!session) return;
  const want = hand === 0 ? 'right' : 'left';
  for (const src of session.inputSources) {
    if (src.handedness !== want || !src.gamepad) continue;
    const gp = src.gamepad;
    try {
      if (gp.hapticActuators && gp.hapticActuators[0] && gp.hapticActuators[0].pulse) gp.hapticActuators[0].pulse(amp, durMs);
      else if (gp.vibrationActuator) gp.vibrationActuator.playEffect('dual-rumble', { duration: durMs, strongMagnitude: amp, weakMagnitude: amp });
    } catch (e) {}
  }
}

// ------------------------------------------------------------------ small matrix helpers (column-major, like WebXR)
function mul(a, b) {
  const o = new Float32Array(16);
  for (let c = 0; c < 4; c++) for (let r = 0; r < 4; r++) {
    let s = 0; for (let k = 0; k < 4; k++) s += a[k * 4 + r] * b[c * 4 + k];
    o[c * 4 + r] = s;
  }
  return o;
}
function translation(x, y, z) { const m = new Float32Array(16); m[0] = m[5] = m[10] = m[15] = 1; m[12] = x; m[13] = y; m[14] = z; return m; }

// ------------------------------------------------------------------ WebGL: one textured quad
const VS = `#version 300 es
in vec2 aPos;
uniform mat4 uMVP;
uniform vec2 uHalf;
out vec2 vUv;
void main() {
  vUv = vec2(aPos.x * 0.5 + 0.5, 0.5 - aPos.y * 0.5);
  gl_Position = uMVP * vec4(aPos * uHalf, 0.0, 1.0);
}`;
const FS = `#version 300 es
precision mediump float;
in vec2 vUv;
uniform sampler2D uTex;
uniform float uHas;
out vec4 o;
void main() {
  vec3 c = texture(uTex, vUv).rgb;
  o = vec4(mix(vec3(0.07, 0.07, 0.12), c, uHas), 1.0);
}`;

function compile(type, src) {
  const s = gl.createShader(type); gl.shaderSource(s, src); gl.compileShader(s);
  if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(s));
  return s;
}

function initGL() {
  const canvas = document.createElement('canvas');
  gl = canvas.getContext('webgl2', { xrCompatible: true, antialias: false, alpha: false });
  if (!gl) throw new Error('WebGL2 is not available');
  prog = gl.createProgram();
  gl.attachShader(prog, compile(gl.VERTEX_SHADER, VS));
  gl.attachShader(prog, compile(gl.FRAGMENT_SHADER, FS));
  gl.linkProgram(prog);
  if (!gl.getProgramParameter(prog, gl.LINK_STATUS)) throw new Error(gl.getProgramInfoLog(prog));
  loc = {
    pos: gl.getAttribLocation(prog, 'aPos'),
    mvp: gl.getUniformLocation(prog, 'uMVP'),
    half: gl.getUniformLocation(prog, 'uHalf'),
    tex: gl.getUniformLocation(prog, 'uTex'),
    has: gl.getUniformLocation(prog, 'uHas'),
  };
  vbo = gl.createBuffer();
  gl.bindBuffer(gl.ARRAY_BUFFER, vbo);
  gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 1, -1, -1, 1, 1, 1]), gl.STATIC_DRAW);
  tex = gl.createTexture();
  gl.bindTexture(gl.TEXTURE_2D, tex);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
}

// ------------------------------------------------------------------ VR session
async function enterVR() {
  if (!navigator.xr) {
    showHelp('<b>WebXR is not available here.</b><br>Browsers only allow WebXR on secure pages. ' +
      'Open the <code>https://</code> address shown on the PC (accept the certificate warning), ' +
      'or use <code>http://localhost</code> via <code>adb reverse</code>.');
    return;
  }
  if (!(await navigator.xr.isSessionSupported('immersive-vr'))) {
    showHelp('This browser/device does not support immersive VR.');
    return;
  }
  try {
    if (!gl) initGL();
    try {
      session = await navigator.xr.requestSession('immersive-vr', { requiredFeatures: ['local-floor'] });
      refSpace = await session.requestReferenceSpace('local-floor'); floorOffset = 0;
    } catch (e) {
      session = await navigator.xr.requestSession('immersive-vr', { optionalFeatures: ['local'] });
      refSpace = await session.requestReferenceSpace('local'); floorOffset = 1.6; // assume standing eye height
    }
    await gl.makeXRCompatible();
    glLayer = new XRWebGLLayer(session, gl, { antialias: false });
    session.updateRenderState({ baseLayer: glLayer });
    session.addEventListener('end', onSessionEnd);
    send({ t: 's', vr: true });
    setStatus('In VR.');
    $('enter').disabled = true;
    session.requestAnimationFrame(onXRFrame);
  } catch (e) {
    session = null;
    showHelp('Could not start VR: ' + (e && e.message ? e.message : e));
  }
}

function onSessionEnd() {
  send({ t: 's', vr: false });
  session = null; refSpace = null; glLayer = null; gotFrame = false;
  setStatus(wsOpen ? 'Connected to Minecraft. Press Enter VR.' : 'Connection lost. Retrying…');
  updateButton();
}

function onXRFrame(time, frame) {
  if (!session) return;
  session.requestAnimationFrame(onXRFrame);
  const pose = frame.getViewerPose(refSpace);
  if (!pose) return;
  sendPose(frame, pose);

  if (newBitmap && bitmap) {
    gl.bindTexture(gl.TEXTURE_2D, tex);
    gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, false);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, bitmap);
    newBitmap = false;
  }

  gl.bindFramebuffer(gl.FRAMEBUFFER, glLayer.framebuffer);
  gl.clearColor(0, 0, 0, 1);
  gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
  gl.disable(gl.DEPTH_TEST);
  gl.useProgram(prog);
  gl.bindBuffer(gl.ARRAY_BUFFER, vbo);
  gl.enableVertexAttribArray(loc.pos);
  gl.vertexAttribPointer(loc.pos, 2, gl.FLOAT, false, 0, 0);
  gl.activeTexture(gl.TEXTURE0);
  gl.bindTexture(gl.TEXTURE_2D, tex);
  gl.uniform1i(loc.tex, 0);
  gl.uniform1f(loc.has, gotFrame ? 1 : 0);
  gl.uniform2f(loc.half, SCREEN_WIDTH / 2, SCREEN_WIDTH / frameAspect / 2);

  // The screen is fixed relative to the HEAD: model = headPose * translate(0,0,-dist).
  const head = pose.transform.matrix;
  const model = mul(head, translation(0, 0, -SCREEN_DIST));
  for (const view of pose.views) {
    const vp = glLayer.getViewport(view);
    gl.viewport(vp.x, vp.y, vp.width, vp.height);
    const mvp = mul(view.projectionMatrix, mul(view.transform.inverse.matrix, model));
    gl.uniformMatrix4fv(loc.mvp, false, mvp);
    gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
  }
}

// ------------------------------------------------------------------ tracking -> PC
function packPose(t) {
  return [r4(t.position.x), r4(t.position.y + floorOffset), r4(t.position.z),
          r4(t.orientation.x), r4(t.orientation.y), r4(t.orientation.z), r4(t.orientation.w)];
}

function sendPose(frame, viewerPose) {
  if (!wsOpen || ws.bufferedAmount > 200000) return;
  const msg = { t: 'p', h: packPose(viewerPose.transform) };
  if (viewerPose.views.length >= 2) {
    const a = viewerPose.views[0].transform.position, b = viewerPose.views[1].transform.position;
    msg.i = r4(Math.hypot(a.x - b.x, a.y - b.y, a.z - b.z));
  }
  for (const src of session.inputSources) {
    const space = src.gripSpace || src.targetRaySpace;
    if (!space) continue;
    const p = frame.getPose(space, refSpace);
    if (!p) continue;
    const hand = { p: packPose(p.transform), b: [], a: [] };
    if (src.gamepad) {
      hand.b = src.gamepad.buttons.slice(0, 6).map((b) => Math.round(b.value * 100) / 100);
      hand.a = src.gamepad.axes.map((v) => Math.round(v * 100) / 100);
    }
    if (src.profiles && src.profiles.length) msg.pr = src.profiles[0];
    if (src.handedness === 'right') msg.r = hand;
    else if (src.handedness === 'left') msg.l = hand;
  }
  ws.send(JSON.stringify(msg));
}

// ------------------------------------------------------------------ page
function updateButton() { $('enter').disabled = !(wsOpen && !session); }
$('enter').addEventListener('click', enterVR);

if (!navigator.xr) {
  setStatus('WebXR is not available in this page.');
  showHelp('Browsers only allow WebXR on <b>secure</b> pages. Open the <code>https://</code> address shown on the PC ' +
    'and accept the certificate warning (Advanced → continue).');
}
connect();
