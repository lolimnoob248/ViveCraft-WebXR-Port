# Vivecraft WebXR Bridge  (Fabric, Minecraft 1.21.11)

Play Vivecraft **wirelessly from a headset browser** (Quest Browser, Pico Browser, Chrome with a headset...).
Think "wireless PCVR", but the headset side is just a web page.

* The PC runs Minecraft + Vivecraft + this mod. The mod starts a small web server.
* The headset opens the page and presses **Enter VR**.
* The headset's head + controller movement is sent to Minecraft (Vivecraft uses it like a real VR device).
* The game picture (left eye) is streamed back as JPEG and shown **filling your whole view** (the picture is as large as
  possible while still fully visible; see the whole picture, as large as possible below).
* On the PC screen you see the **address to open** until a headset is really in VR. Then you see the normal VR mirror.

## Why a separate mod and not a changed Vivecraft jar?
A `.jar` only contains compiled code (no source), so it cannot be edited safely. This mod is an **add-on**
that plugs into Vivecraft with Mixins. It adds a new VR device called `webxr` (built on Vivecraft's own NullVR,
so it never crashes when no headset/SteamVR exists). **You still need the normal Vivecraft jar in your mods folder.**

## Build (makes the .jar)
1. Install **JDK 21** and **Gradle 9.x** (or open the folder in IntelliJ IDEA and let it import the Gradle project).
2. In this folder run:  `gradle wrapper`  (once), then  `./gradlew build`   (Windows: `gradlew build`)
3. Your mod is `build/libs/vivecraft-webxr-1.0.3.jar`.

(`libs/vivecraft-1_21_11-1_3_15-fabric.jar` is only used to compile against. It is not packed into your mod.)

## Build on Alpine Linux (automatic)
`sh build-alpine.sh` - installs JDK 21 + tools with `apk`, downloads the right Gradle, builds, and copies the jar to `dist/`.
Needs internet; the first build downloads Minecraft and Fabric.

## Install
`mods/` folder needs:  Fabric Loader (1.21.11) + **Vivecraft** jar + **vivecraft-webxr-1.0.3.jar**.   (Fabric API is not required.)

## Use
1. Start Minecraft. The PC shows a green panel with addresses, e.g. `https://192.168.1.23:8443`.
2. Put the headset on the **same Wi-Fi** (5 GHz / Wi-Fi 6 is best).
3. In the headset browser open the **https** address. First time: *Advanced -> Continue* (self-signed certificate).
4. Press **Enter VR**. The PC switches to VR mode by itself. Take the headset off / exit VR -> PC goes back to normal.

WebXR only works on secure pages, so use **https**. Alternative without the warning: connect the headset by USB and run
`adb reverse tcp:8080 tcp:8080`, then open `http://localhost:8080` in the headset.
Windows Firewall: allow Java on private networks when asked (ports 8080/8443).

## Controls (Vivecraft's default Oculus Touch layout)
| Button | In the world | In menus |
|---|---|---|
| Right trigger | Attack / break | Left click |
| Right A | Use / place | Right click |
| Right B | Radial menu | |
| Right grip | Next hotbar slot | Middle click |
| Left grip | Previous hotbar slot | Shift |
| Left trigger | Teleport (if enabled) | |
| Left stick | Walk | |
| Right stick | Turn | |
| Left stick click / Right stick click | Jump / Sneak | |
| Left X / Left Y | Inventory / Menu | Inventory / Menu |

## Settings: `.minecraft/config/vivecraft-webxr.properties` (restart the game after changing)
`httpPort`, `httpsPort`, `streamWidth` (default 0 = full native size, no rescaling; set e.g. 1280 to downscale), `streamFps` (default 72), `jpegQuality` (default 0.6), `forceVR`, `enabled`.
Page option: `https://IP:8443/?d=1.5&w=2.0` = small floating screen instead (distance and width in metres).

**Black screen?** The headset now shows a status panel instead (video messages received / decoded / errors). Together with the
`WebXR stream:` lines in `.minecraft/logs/latest.log` it shows which step stops: game frames 0 = Vivecraft is not rendering VR;
"no browser in VR" counting up = the browser is not counted as playing; captured 0 = GPU copy; sent 0 = encoding; sent > 0 but headset receives 0 = network.

Lower latency tips: 5 GHz / Wi-Fi 6 with the PC on a **cable** to the router; turn **VSync off** in Minecraft (the stream can only be as fast as the game renders);
if the picture stutters, lower `jpegQuality` (0.5) or set `streamWidth` (1280) first - smaller frames are the biggest lever. Full-size frames need more bandwidth: if the picture stutters, set `streamWidth=1280`.

## Honest notes
* **Untested in a real game.** This was written without Minecraft or a headset available. The web server, WebSocket
  protocol, HTTPS, and pose/button parsing were tested for real; all calls into Vivecraft were type-checked against
  your jar. The Minecraft-specific lines (`Overlay.java`, the 3 Minecraft mixins) use Mojang names from memory.
  If the build fails, the error will point at one of those few lines - the fix is usually a one-word rename.
* The picture is a flat video stream (JPEG), not a real stereo VR picture. Expect roughly 40-70 ms from head movement to picture on a good
  Wi-Fi (not measured in a real setup yet). It cannot match cable PCVR, but should feel like cloud gaming.
* Only the **left eye** is streamed (flat 2D picture, no stereo depth).
* Streaming needs the OpenGL graphics backend (the default).
* The built-in HTTPS certificate is the same for everyone. Use this on a **trusted home network only**, or set
  `keystorePath` to your own `.p12` file.
* Not mapped yet: menu scrolling with the stick, hotbar swipe, quick-commands, full-body trackers.

## Changes
* **1.0.3** - Streaming rewritten. Frame transport: every binary WebSocket message now starts with a tag byte (`V` video, `A` sound).
  Before, the page treated PC-sound messages as pictures, which could starve the video, and it never played the sound; now it plays the sound.
  Video: each frame is cut into horizontal JPEG stripes that are encoded on several threads at once (`encodeThreads`, default automatic) and
  decoded in parallel in the headset, packed into ONE message per frame (newest frame always wins). The picture is never bigger than the
  headset GPU's texture limit (a too-big picture used to show as black). While no video arrives the headset shows a status panel with
  counters instead of a black screen, and the PC log gets a line `WebXR stream: ...` every 5 seconds.
* **1.0.2** - Start-up: VR is now switched on only when the loading screen is gone AND a menu/world is showing AND 120 frames plus 3 seconds
  have passed (a slow PC draws few frames per second), once only, with errors caught.
  Latency: the finished frame is read back from the GPU in the same frame (GPU fence, max 2 ms wait) instead of one frame later; pixels go straight
  into the JPEG encoder with no per-pixel conversion; two JPEG encoders work in parallel and only the newest frame is ever sent; each video frame is a single
  network write; smaller OS send buffer so old frames cannot pile up; defaults 72 fps / quality 0.6 (old saved defaults are upgraded once);
  the headset page asks for its highest refresh rate. Picture: fills the whole headset view (the whole picture, as large as possible).
  Frames are streamed at full native size (`streamWidth=0`), no rescaling.
* **1.0.1** - Fixed a crash at startup ("Tried to lookup sprite, but atlas is not initialized"): VR mode is now switched on
  only after Minecraft finished loading, and only once. The address panel is also not drawn during loading.

## Running on iPhone / iPad (Amethyst, MobileGlues)
Possible, but not guaranteed. Vivecraft's VR renderer needs more OpenGL features and RAM than the iOS launchers usually give
(MobileGlues is OpenGL ES 3.0). If the log shows "Vivecraft: Failed to initialize VR" after the loading screen, that is the cause.
Give the game as much RAM as the launcher allows, use render distance 2, and allow "Local Network" access for the app
(iOS Settings) so the headset can reach it. Keep the app open on screen; iOS pauses background apps.
