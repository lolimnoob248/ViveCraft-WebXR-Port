package dev.vivewebxr.mixin;

import dev.vivewebxr.WebXRConfig;
import dev.vivewebxr.vr.WebXRVR;
import net.minecraft.client.Minecraft;
import org.objectweb.asm.Opcodes;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.vivecraft.client_vr.ClientDataHolderVR;
import org.vivecraft.client_vr.VRState;
import org.vivecraft.client_vr.provider.MCVR;

/**
 * Vivecraft picks its VR device in VRState.initializeVR(): OpenVR (SteamVR) or the "null driver".
 * Both branches end with "dh.vr = <device>". We intercept that assignment and store our WebXR device instead.
 */
@Mixin(value = VRState.class, remap = false)
public abstract class VRStateMixin {
    @Redirect(
            method = "initializeVR",
            remap = false,
            at = @At(
                    value = "FIELD",
                    opcode = Opcodes.PUTFIELD,
                    target = "Lorg/vivecraft/client_vr/ClientDataHolderVR;vr:Lorg/vivecraft/client_vr/provider/MCVR;",
                    remap = false))
    private static void webxr$useWebXrDevice(ClientDataHolderVR holder, MCVR original) {
        holder.vr = WebXRConfig.enabled ? new WebXRVR(Minecraft.getInstance(), holder) : original;
    }
}
