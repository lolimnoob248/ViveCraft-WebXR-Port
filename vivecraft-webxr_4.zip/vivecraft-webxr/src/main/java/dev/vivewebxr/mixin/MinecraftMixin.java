package dev.vivewebxr.mixin;

import dev.vivewebxr.WebXRMod;
import net.minecraft.client.Minecraft;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Priority 900 = run before Vivecraft's own start-of-frame code, so our flags are already set. */
@Mixin(value = Minecraft.class, priority = 900)
public abstract class MinecraftMixin {
    @Inject(method = "runTick", at = @At("HEAD"))
    private void webxr$onFrame(boolean renderLevel, CallbackInfo ci) {
        WebXRMod.onFrame();
    }
}
