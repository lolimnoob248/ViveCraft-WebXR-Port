package dev.vivewebxr.mixin;

import dev.vivewebxr.client.Overlay;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiGraphics;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Draws the "open this address" panel on top of the in-game HUD. */
@Mixin(Gui.class)
public abstract class GuiMixin {
    @Inject(method = "render", at = @At("TAIL"), require = 0)
    private void webxr$overlay(GuiGraphics graphics, DeltaTracker deltaTracker, CallbackInfo ci) {
        Overlay.draw(graphics, false);
    }
}
