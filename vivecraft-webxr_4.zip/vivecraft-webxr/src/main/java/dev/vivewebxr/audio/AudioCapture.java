package dev.vivewebxr.audio;

import dev.vivewebxr.WebXRConfig;
import dev.vivewebxr.WebXRMod;
import dev.vivewebxr.server.WebXRServer;

import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.DataLine;
import javax.sound.sampled.Mixer;
import javax.sound.sampled.TargetDataLine;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

/**
 * Streams the PC's sound to the headset as raw 16-bit stereo PCM (no codec = no encoding delay).
 *
 * Source: a "loopback" capture device that carries what the PC plays (Windows "Stereo Mix", VB-Cable /
 * VoiceMeeter "Output", macOS BlackHole, a PulseAudio "Monitor of ..." device). Java cannot record the system
 * output directly, so one of these devices must exist. A normal microphone is NEVER picked automatically:
 * only a device whose name matches a loopback hint, or the one named in `audioDevice`.
 *
 * The device is opened only while a headset is inside VR and closed again afterwards.
 */
public final class AudioCapture {
    public static final AudioCapture INSTANCE = new AudioCapture();

    private static final int[] RATES = {48000, 44100};
    private static final String[] LOOPBACK_HINTS = {
            "stereo mix", "what u hear", "what you hear", "wave out mix", "loopback", "monitor of",
            "cable output", "vb-audio", "voicemeeter", "blackhole", "soundflower"
    };

    private WebXRServer server;
    private volatile boolean running;
    private volatile String status = "Audio: starting...";

    private TargetDataLine line;
    private byte[] buf;

    private AudioCapture() {}

    /** One line for the PC overlay. */
    public String status() {
        return status;
    }

    public void start(WebXRServer s) {
        this.server = s;
        running = true;
        Thread t = new Thread(this::run, "WebXR-audio");
        t.setDaemon(true);
        t.start();
    }

    public void stop() {
        running = false;
    }

    // ------------------------------------------------------------------ device choice (pure, unit-testable)

    /**
     * @param names  mixer names in system order
     * @param wanted the `audioDevice` setting ("" = automatic)
     * @return indices to try, best first. Automatic mode returns only devices that look like loopback devices.
     */
    public static List<Integer> candidates(List<String> names, String wanted) {
        List<Integer> out = new ArrayList<>();
        String w = wanted == null ? "" : wanted.trim().toLowerCase(Locale.ROOT);
        for (int i = 0; i < names.size(); i++) {
            String n = names.get(i).toLowerCase(Locale.ROOT);
            if (!w.isEmpty()) {
                if (n.contains(w)) out.add(i);
            } else {
                for (String h : LOOPBACK_HINTS) {
                    if (n.contains(h)) {
                        out.add(i);
                        break;
                    }
                }
            }
        }
        return out;
    }

    private static AudioFormat format(int rate) {
        return new AudioFormat(rate, 16, 2, true, false); // signed 16-bit little-endian stereo
    }

    // ------------------------------------------------------------------ thread

    private void run() {
        Mixer.Info[] infos;
        List<String> names = new ArrayList<>();
        try {
            infos = AudioSystem.getMixerInfo();
        } catch (Throwable t) {
            status = "Audio: Java Sound is not available";
            WebXRMod.LOGGER.warn("WebXR audio: Java Sound not available: {}", t.toString());
            return;
        }
        List<String> capture = new ArrayList<>();
        for (Mixer.Info mi : infos) {
            names.add(mi.getName());
            try {
                if (AudioSystem.getMixer(mi).isLineSupported(new DataLine.Info(TargetDataLine.class, format(48000)))
                        || AudioSystem.getMixer(mi).isLineSupported(new DataLine.Info(TargetDataLine.class, format(44100)))) {
                    capture.add(mi.getName());
                }
            } catch (Throwable ignored) {
            }
        }
        WebXRMod.LOGGER.info("WebXR audio: capture-capable devices: {}", capture.isEmpty() ? "(none)" : capture);
        List<Integer> cand = candidates(names, WebXRConfig.audioDevice);
        cand.removeIf(i -> !capture.contains(names.get(i)));
        if (cand.isEmpty()) {
            status = WebXRConfig.audioDevice.isBlank()
                    ? "Audio: no PC-audio capture device found (enable Stereo Mix or use VB-Cable, see README)"
                    : "Audio: no capture device matches \"" + WebXRConfig.audioDevice + "\"";
            WebXRMod.LOGGER.warn("WebXR audio: {}", status);
            return;
        }
        status = "Audio: ready (" + names.get(cand.get(0)) + ")";

        boolean failedThisSession = false;
        while (running) {
            boolean want = server != null && server.wantsFrames();
            try {
                if (want && line == null && !failedThisSession) {
                    if (!open(infos, cand)) failedThisSession = true;
                } else if (!want) {
                    failedThisSession = false; // retry on the next session
                    if (line != null) close();
                }
                if (line != null) {
                    int n = line.read(buf, 0, buf.length);
                    if (n > 0) server.broadcastAudio(Arrays.copyOf(buf, n));
                } else {
                    Thread.sleep(200);
                }
            } catch (InterruptedException e) {
                return;
            } catch (Throwable t) {
                WebXRMod.LOGGER.warn("WebXR audio: capture stopped: {}", t.toString());
                close();
                failedThisSession = true;
            }
        }
        close();
    }

    private boolean open(Mixer.Info[] infos, List<Integer> cand) {
        for (int idx : cand) {
            for (int rate : RATES) {
                try {
                    AudioFormat fmt = format(rate);
                    Mixer mixer = AudioSystem.getMixer(infos[idx]);
                    DataLine.Info info = new DataLine.Info(TargetDataLine.class, fmt);
                    if (!mixer.isLineSupported(info)) continue;
                    int chunk = rate / 100 * 4; // 10 ms of stereo 16-bit
                    TargetDataLine l = (TargetDataLine) mixer.getLine(info);
                    l.open(fmt, chunk * 4);      // small device buffer (~40 ms): little capture delay
                    l.start();
                    line = l;
                    buf = new byte[chunk];
                    status = "Audio: streaming from " + infos[idx].getName();
                    WebXRMod.LOGGER.info("WebXR audio: {} at {} Hz", infos[idx].getName(), rate);
                    server.sendToPlayer("{\"t\":\"audio\",\"rate\":" + rate + ",\"ch\":2}");
                    return true;
                } catch (Throwable t) {
                    WebXRMod.LOGGER.debug("WebXR audio: cannot open {} at {} Hz: {}", infos[idx].getName(), rate, t.toString());
                }
            }
        }
        status = "Audio: could not open the capture device";
        WebXRMod.LOGGER.warn("WebXR audio: could not open any capture device");
        return false;
    }

    private void close() {
        TargetDataLine l = line;
        line = null;
        if (l != null) {
            try {
                l.stop();
                l.close();
            } catch (Throwable ignored) {
            }
            status = "Audio: ready";
        }
    }
}
