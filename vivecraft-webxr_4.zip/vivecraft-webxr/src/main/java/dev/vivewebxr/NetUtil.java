package dev.vivewebxr;

import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class NetUtil {
    private NetUtil() {}

    /** Private-network IPv4 addresses of this machine (192.168.x.x, 10.x.x.x, 172.16-31.x.x), best guess first. */
    public static List<String> lanAddresses() {
        List<String> preferred = new ArrayList<>();
        List<String> other = new ArrayList<>();
        try {
            for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!ni.isUp() || ni.isLoopback() || ni.isPointToPoint()) continue;
                String name = (ni.getDisplayName() + " " + ni.getName()).toLowerCase();
                boolean virtual = name.contains("virtual") || name.contains("vmware") || name.contains("vbox")
                        || name.contains("docker") || name.contains("hyper-v") || name.contains("vethernet")
                        || name.contains("wsl") || name.contains("tailscale") || name.contains("zerotier");
                for (InetAddress a : Collections.list(ni.getInetAddresses())) {
                    if (!(a instanceof Inet4Address) || a.isLoopbackAddress() || a.isLinkLocalAddress()) continue;
                    if (!a.isSiteLocalAddress()) continue;
                    (virtual ? other : preferred).add(a.getHostAddress());
                }
            }
        } catch (Exception ignored) {
        }
        preferred.addAll(other);
        return preferred;
    }
}
