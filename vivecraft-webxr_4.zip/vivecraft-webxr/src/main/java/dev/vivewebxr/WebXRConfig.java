package dev.vivewebxr;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/** Simple settings file: .minecraft/config/vivecraft-webxr.properties */
public final class WebXRConfig {
    /** Master switch. false = this mod does nothing and Vivecraft behaves normally. */
    public static boolean enabled = true;
    /** Plain HTTP port (works with http://localhost, e.g. via `adb reverse`). 0 = off. */
    public static int httpPort = 8080;
    /** HTTPS port (self-signed certificate). Needed for WebXR from another device. 0 = off. */
    public static int httpsPort = 8443;
    /** Width of the streamed picture in pixels. 0 = native: the full size Vivecraft renders, no rescaling. */
    public static int streamWidth = 0;
    /** Maximum frames per second sent to the headset (72 = Quest 2 default refresh rate). */
    public static int streamFps = 72;
    /** JPEG quality 0.1 .. 1.0 (lower = smaller frames = less network delay). */
    public static float jpegQuality = 0.6f;
    /** Threads that JPEG-encode stripes of a frame at the same time. 0 = automatic (half of your CPU cores, 2..6). */
    public static int encodeThreads = 0;
    /** Turn Vivecraft's VR mode on automatically (so you do not have to enable it in its settings). */
    public static boolean forceVR = true;
    /** Stream PC sound to the headset (needs a loopback capture device, see README). */
    public static boolean audio = true;
    /** Part of the capture device's name ("" = automatic: only loopback-style devices, never a microphone). */
    public static String audioDevice = "";
    /** Optional: path to your own PKCS12 keystore (instead of the built-in self-signed one). */
    public static String keystorePath = "";
    public static String keystorePassword = "changeit";

    /** Bumped when defaults change, so old saved defaults can be upgraded once. */
    private static final int CONFIG_VERSION = 3;

    private WebXRConfig() {}

    public static void load() {
        Path file = FabricLoader.getInstance().getConfigDir().resolve("vivecraft-webxr.properties");
        Properties p = new Properties();
        if (Files.exists(file)) {
            try (InputStream in = Files.newInputStream(file)) {
                p.load(in);
            } catch (IOException e) {
                WebXRMod.LOGGER.warn("Could not read {}: {}", file, e.toString());
            }
        }
        enabled = bool(p, "enabled", enabled);
        httpPort = integer(p, "httpPort", httpPort, 0, 65535);
        httpsPort = integer(p, "httpsPort", httpsPort, 0, 65535);
        streamWidth = integer(p, "streamWidth", streamWidth, 0, 7680);
        streamFps = integer(p, "streamFps", streamFps, 5, 144);
        jpegQuality = decimal(p, "jpegQuality", jpegQuality, 0.1f, 1.0f);
        int version = integer(p, "configVersion", 1, 0, 1000);
        if (version < CONFIG_VERSION) {
            // The file was written by an older version, which saved ITS defaults (36 fps, quality 0.7).
            // Upgrade those to the new low-latency defaults; anything the user changed is kept.
            if (streamFps == 36) streamFps = 72;
            if (streamWidth == 1280) streamWidth = 0; // old default (downscaled) -> native size
            if (Math.abs(jpegQuality - 0.7f) < 1e-4f) jpegQuality = 0.6f;
        }
        encodeThreads = integer(p, "encodeThreads", encodeThreads, 0, 8);
        forceVR = bool(p, "forceVR", forceVR);
        audio = bool(p, "audio", audio);
        audioDevice = p.getProperty("audioDevice", audioDevice).trim();
        keystorePath = p.getProperty("keystorePath", keystorePath).trim();
        keystorePassword = p.getProperty("keystorePassword", keystorePassword);
        save(file);
    }

    private static void save(Path file) {
        Properties p = new Properties();
        p.setProperty("configVersion", String.valueOf(CONFIG_VERSION));
        p.setProperty("enabled", String.valueOf(enabled));
        p.setProperty("httpPort", String.valueOf(httpPort));
        p.setProperty("httpsPort", String.valueOf(httpsPort));
        p.setProperty("streamWidth", String.valueOf(streamWidth));
        p.setProperty("streamFps", String.valueOf(streamFps));
        p.setProperty("encodeThreads", String.valueOf(encodeThreads));
        p.setProperty("jpegQuality", String.valueOf(jpegQuality));
        p.setProperty("forceVR", String.valueOf(forceVR));
        p.setProperty("audio", String.valueOf(audio));
        p.setProperty("audioDevice", audioDevice);
        p.setProperty("keystorePath", keystorePath);
        p.setProperty("keystorePassword", keystorePassword);
        try (OutputStream out = Files.newOutputStream(file)) {
            p.store(out, "Vivecraft WebXR Bridge settings (restart the game after editing)");
        } catch (IOException e) {
            WebXRMod.LOGGER.warn("Could not write {}: {}", file, e.toString());
        }
    }

    private static boolean bool(Properties p, String k, boolean def) {
        return Boolean.parseBoolean(p.getProperty(k, String.valueOf(def)).trim());
    }

    private static float decimal(Properties p, String k, float def, float min, float max) {
        try {
            float v = Float.parseFloat(p.getProperty(k, String.valueOf(def)).trim());
            return Float.isFinite(v) ? Math.max(min, Math.min(max, v)) : def;
        } catch (NumberFormatException e) {
            return def;
        }
    }

    private static int integer(Properties p, String k, int def, int min, int max) {
        try {
            int v = Integer.parseInt(p.getProperty(k, String.valueOf(def)).trim());
            return Math.max(min, Math.min(max, v));
        } catch (NumberFormatException e) {
            return def;
        }
    }
}
