package dev.vivewebxr;

/**
 * Shared state between the network threads (writers) and the Minecraft render thread (reader).
 * Only one browser at a time "owns" the VR session; the first one that presses Enter VR gets it.
 */
public final class XRState {
    private static final long TIMEOUT_NANOS = 5_000_000_000L;

    private static volatile int owner = -1;
    private static volatile boolean inVr;
    private static volatile XRInput latest = XRInput.standing();
    private static volatile long lastInputNanos;
    private static volatile int connectedClients;

    private XRState() {}

    /** True while a browser is inside an "Enter VR" session and is still sending data. */
    public static boolean isVrActive() {
        return inVr && (System.nanoTime() - lastInputNanos) < TIMEOUT_NANOS;
    }

    public static XRInput input() {
        return latest;
    }

    public static int clients() {
        return connectedClients;
    }

    public static synchronized void clientConnected() {
        connectedClients++;
    }

    public static synchronized void clientGone(int id) {
        connectedClients = Math.max(0, connectedClients - 1);
        sessionChanged(id, false);
    }

    /** @return true if this client now owns (or still owns) the VR session / was allowed to end it */
    public static synchronized boolean sessionChanged(int clientId, boolean on) {
        if (on) {
            if (inVr && owner != clientId && (System.nanoTime() - lastInputNanos) < TIMEOUT_NANOS) {
                return false; // someone else is already playing
            }
            owner = clientId;
            inVr = true;
            lastInputNanos = System.nanoTime();
            latest = XRInput.standing();
            WebXRMod.LOGGER.info("WebXR session started (client {})", clientId);
            return true;
        }
        if (owner == clientId && inVr) {
            inVr = false;
            owner = -1;
            WebXRMod.LOGGER.info("WebXR session ended (client {})", clientId);
            return true;
        }
        return false;
    }

    public static void onInput(int clientId, XRInput in) {
        if (clientId != owner || !inVr) return;
        latest = in;
        lastInputNanos = System.nanoTime();
    }

    public static int owner() {
        return owner;
    }
}
