package dev.vivewebxr.vr;

import dev.vivewebxr.WebXRMod;
import dev.vivewebxr.render.FrameGrabber;
import org.vivecraft.client_vr.provider.MCVR;
import org.vivecraft.client_vr.provider.nullvr.NullVRStereoRenderer;

/**
 * Same as Vivecraft's built-in "null driver" renderer (it renders the eyes but shows them nowhere),
 * plus: after each frame the finished left eye is copied out and streamed to the browser.
 */
public class WebXRStereoRenderer extends NullVRStereoRenderer {
    private boolean checkedBackend;
    private boolean openGl;

    public WebXRStereoRenderer(MCVR vr) {
        super(vr);
    }

    @Override
    public void endFrame() {
        super.endFrame(); // keeps NullVR's bookkeeping (it checks the headset was polled)

        if (!checkedBackend) {
            checkedBackend = true;
            String helper = org.vivecraft.client_vr.render.helpers.graphics.GraphicsHelper.INSTANCE.getClass().getSimpleName();
            openGl = helper.equals("OpenGLHelper");
            if (!openGl) {
                WebXRMod.LOGGER.warn("WebXR: graphics backend is {} - video streaming only works with OpenGL.", helper);
            }
        }
        if (!openGl) return;

        int tex = this.eyeTextureId[0];
        FrameGrabber.INSTANCE.capture(tex, this.resolution.x(), this.resolution.y());
    }

    @Override
    protected void destroyBuffers() {
        FrameGrabber.INSTANCE.release();
        super.destroyBuffers();
    }
}
