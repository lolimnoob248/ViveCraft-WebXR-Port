package dev.vivewebxr.vr;

import dev.vivewebxr.WebXRMod;
import org.vivecraft.client_vr.provider.ControllerType;
import org.vivecraft.client_vr.provider.HapticScheduler;

import java.util.Locale;
import java.util.concurrent.TimeUnit;

/** Sends Vivecraft's controller vibration requests to the browser. */
public class WebXRHaptics extends HapticScheduler {
    @Override
    public void queueHapticPulse(ControllerType hand, float durationSeconds, float frequency, float amplitude, float delaySeconds) {
        String json = String.format(Locale.ROOT, "{\"t\":\"h\",\"hand\":%d,\"d\":%d,\"a\":%.2f}",
                hand == ControllerType.RIGHT ? 0 : 1,
                Math.max(1, Math.round(durationSeconds * 1000f)),
                Math.max(0f, Math.min(1f, amplitude)));
        Runnable send = () -> {
            if (WebXRMod.server() != null) WebXRMod.server().sendToPlayer(json);
        };
        if (delaySeconds > 0.001f && this.executor != null) {
            this.executor.schedule(send, Math.round(delaySeconds * 1000f), TimeUnit.MILLISECONDS);
        } else {
            send.run();
        }
    }
}
