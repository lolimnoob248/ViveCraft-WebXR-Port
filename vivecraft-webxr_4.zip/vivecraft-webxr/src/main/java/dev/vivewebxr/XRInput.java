package dev.vivewebxr;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

/**
 * One snapshot of what the browser sent: head pose, both controllers' poses, buttons and sticks.
 * Poses are in WebXR "local-floor" space (metres, +Y up, -Z forward) which is the same convention
 * Vivecraft/OpenVR uses for its "room" space.
 */
public final class XRInput {
    /** Hand slots follow Vivecraft's ControllerType order: 0 = RIGHT, 1 = LEFT. */
    public static final int RIGHT = 0, LEFT = 1;

    public static final class Hand {
        public boolean present;
        /** px,py,pz, qx,qy,qz,qw (grip pose) */
        public final float[] pose = {0, 0, 0, 0, 0, 0, 1};
        public float trigger, grip, touchpad, stickClick, buttonA, buttonB;
        public float stickX, stickY;
    }

    /** px,py,pz, qx,qy,qz,qw */
    public final float[] hmd = {0, 1.62f, 0, 0, 0, 0, 1};
    public float ipd = 0.064f;
    public String profile = "";
    public final Hand[] hands = {new Hand(), new Hand()};

    public XRInput() {
        // sensible resting positions until a controller is really tracked
        hands[RIGHT].pose[0] = 0.25f; hands[RIGHT].pose[1] = 1.1f; hands[RIGHT].pose[2] = -0.3f;
        hands[LEFT].pose[0] = -0.25f; hands[LEFT].pose[1] = 1.1f; hands[LEFT].pose[2] = -0.3f;
    }

    public static XRInput standing() {
        return new XRInput();
    }

    /** Parses the compact message the web page sends (see client.js, function sendPose). */
    public static XRInput parse(JsonObject o) {
        XRInput in = new XRInput();
        copy(o.getAsJsonArray("h"), in.hmd, 7);
        if (o.has("i")) in.ipd = clamp(o.get("i").getAsFloat(), 0.04f, 0.095f);
        if (o.has("pr")) in.profile = o.get("pr").getAsString();
        readHand(o.getAsJsonObject("r"), in.hands[RIGHT]);
        readHand(o.getAsJsonObject("l"), in.hands[LEFT]);
        return in;
    }

    private static void readHand(JsonObject h, Hand out) {
        if (h == null) return;
        JsonArray p = h.getAsJsonArray("p");
        if (p == null || p.size() < 7) return;
        out.present = true;
        copy(p, out.pose, 7);
        JsonArray b = h.getAsJsonArray("b");
        float[] bv = new float[6];
        if (b != null) copy(b, bv, Math.min(6, b.size()));
        out.trigger = bv[0];
        out.grip = bv[1];
        out.touchpad = bv[2];
        out.stickClick = bv[3];
        out.buttonA = bv[4];
        out.buttonB = bv[5];
        JsonArray a = h.getAsJsonArray("a");
        if (a != null && a.size() >= 2) {
            // xr-standard: axes[0..1] = touchpad, axes[2..3] = thumbstick. Many runtimes only give 2 axes.
            int i = a.size() >= 4 ? 2 : 0;
            out.stickX = clamp(a.get(i).getAsFloat(), -1, 1);
            out.stickY = -clamp(a.get(i + 1).getAsFloat(), -1, 1); // WebXR: up = -1, we want up = +1
        }
    }

    private static void copy(JsonArray src, float[] dst, int n) {
        if (src == null) return;
        for (int i = 0; i < n && i < src.size(); i++) {
            JsonElement e = src.get(i);
            float v = e.isJsonNull() ? 0 : e.getAsFloat();
            dst[i] = Float.isFinite(v) ? v : 0;
        }
    }

    private static float clamp(float v, float lo, float hi) {
        return Math.max(lo, Math.min(hi, v));
    }
}
