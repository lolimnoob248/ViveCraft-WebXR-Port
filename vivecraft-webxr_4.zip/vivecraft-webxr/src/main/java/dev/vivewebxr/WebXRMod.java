package dev.vivewebxr;

import dev.vivewebxr.audio.AudioCapture;
import dev.vivewebxr.render.FrameGrabber;
import dev.vivewebxr.server.WebXRServer;
import net.fabricmc.api.ClientModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.vivecraft.client_vr.ClientDataHolderVR;
import net.minecraft.client.Minecraft;
import org.vivecraft.client_vr.VRState;

public final class WebXRMod implements ClientModInitializer {
    public static final Logger LOGGER = LoggerFactory.getLogger("vivecraft-webxr");

    private static WebXRServer server;

    @Override
    public void onInitializeClient() {
        WebXRConfig.load();
        if (!WebXRConfig.enabled) {
            LOGGER.info("WebXR bridge is disabled in config/vivecraft-webxr.properties");
            return;
        }
        server = new WebXRServer();
        server.start();
        FrameGrabber.INSTANCE.setServer(server);
        if (WebXRConfig.audio) AudioCapture.INSTANCE.start(server);
        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            if (server != null) server.stop();
        }, "WebXR-shutdown"));

        LOGGER.info("WebXR bridge ready. Open one of these in your headset browser:");
        for (String ip : NetUtil.lanAddresses()) {
            if (server.httpsPortBound > 0) LOGGER.info("   https://{}:{}", ip, server.httpsPortBound);
            if (server.httpPortBound > 0) LOGGER.info("   http://{}:{}", ip, server.httpPortBound);
        }
    }

    public static WebXRServer server() {
        return server;
    }

    private static boolean vrSwitchedOn;
    private static int readyFrames;
    private static long readySinceNanos;

    /** Frames AND wall-clock time Minecraft must have been fully loaded before VR may start. */
    private static final int MIN_READY_FRAMES = 120;
    private static final long MIN_READY_NANOS = 3_000_000_000L;

    /**
     * True once Minecraft has finished loading resources (textures, shaders, fonts) and is really showing
     * a normal screen (title screen) or a world. The loading screen is an "overlay"; while it is up the
     * texture atlases do not exist yet and Vivecraft's VR start-up ("initializeVR") would crash on them.
     */
    public static boolean gameReady() {
        Minecraft mc = Minecraft.getInstance();
        return mc != null && mc.getOverlay() == null && (mc.screen != null || mc.level != null);
    }

    /** Called at the start of every Minecraft frame (from MinecraftMixin). */
    public static void onFrame() {
        if (!WebXRConfig.enabled || !WebXRConfig.forceVR || vrSwitchedOn) return;
        // Do NOT start VR while Minecraft is still loading: Vivecraft needs the texture atlas to exist.
        if (!gameReady()) {
            readyFrames = 0;
            readySinceNanos = 0;
            return;
        }
        long now = System.nanoTime();
        if (readySinceNanos == 0) readySinceNanos = now;
        // Calm period after loading: enough frames AND enough real time (a slow PC can draw few frames per second).
        if (++readyFrames < MIN_READY_FRAMES || now - readySinceNanos < MIN_READY_NANOS) return;
        ClientDataHolderVR dh = ClientDataHolderVR.getInstance();
        if (dh == null || dh.vrSettings == null || dh.completelyDisabled) return;
        // Set the flag first: whatever happens below, we never try twice (no retry loop on failure).
        vrSwitchedOn = true;
        try {
            // VR "on", but with hot-switching: Vivecraft renders VR only while isActive() is true
            // (= a browser is in "Enter VR"); otherwise the game looks and plays like normal Minecraft.
            // Vivecraft notices VR_ENABLED in its own runTick hook, later in this same frame, and runs initializeVR().
            dh.vrSettings.vrHotswitchingEnabled = true;
            VRState.VR_ENABLED = true;
            LOGGER.info("WebXR: Vivecraft VR mode switched on (hot-switching)");
        } catch (Throwable t) {
            LOGGER.error("WebXR: could not switch Vivecraft VR mode on", t);
        }
    }
}
