package dev.vivewebxr.render;

import dev.vivewebxr.WebXRConfig;
import dev.vivewebxr.WebXRMod;
import dev.vivewebxr.server.WebXRServer;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL12;
import org.lwjgl.opengl.GL15;
import org.lwjgl.opengl.GL21;
import org.lwjgl.opengl.GL30;
import org.lwjgl.opengl.GL32;

import javax.imageio.IIOImage;
import javax.imageio.ImageIO;
import javax.imageio.ImageWriteParam;
import javax.imageio.ImageWriter;
import javax.imageio.stream.ImageOutputStream;
import javax.imageio.stream.MemoryCacheImageOutputStream;
import java.awt.image.BufferedImage;
import java.awt.image.DataBufferByte;
import java.io.ByteArrayOutputStream;
import java.nio.ByteBuffer;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Streams the finished left-eye picture to the browser.
 *
 * Pipeline
 *  1. Render thread (this class, grab()): blit the eye texture into a small FBO (flipped, and scaled only if it has
 *     to be), start an asynchronous glReadPixels into a pixel-buffer-object and wait at most ~2 ms on a GPU fence, so
 *     the picture of THIS frame is normally picked up in the same frame. A ring of 3 buffers covers slow GPUs.
 *     Pixels are read as BGR = exactly the memory layout of a TYPE_3BYTE_BGR image: no per-pixel conversion.
 *  2. Encoder threads: the picture is cut into horizontal STRIPES and every stripe is JPEG-encoded on its own thread
 *     at the same time (the JDK's JPEG encoder is single-threaded and slow, so this is ~N times faster for N stripes).
 *  3. When all stripes of a frame are done they are packed into ONE binary message (see buildMessage) and handed to
 *     the web server, which only ever sends the newest frame to the headset.
 *
 * A short statistics line is written to the log every 5 seconds, so it is visible which step does not work.
 */
public final class FrameGrabber {
    public static final FrameGrabber INSTANCE = new FrameGrabber();

    /** First byte of a video message (audio messages start with 0x41). */
    public static final int MSG_VIDEO = 0x56;

    private static final int RING = 3;
    private static final int MAX_STRIPES = 8;
    private static final int MAX_FRAMES_IN_FLIGHT = 2;
    private static final long SAME_FRAME_WAIT_NANOS = 2_000_000L;
    private static final long STATS_INTERVAL_NANOS = 5_000_000_000L;

    private WebXRServer server;
    private int consecutiveFailures;
    private volatile boolean broken;
    private int glErrorsLogged;

    // ---- GPU objects (render thread only)
    private int srcFbo, dstFbo, dstRb;
    private final int[] pbo = new int[RING];
    private final long[] fence = new long[RING]; // 0 = slot free
    private final long[] slotSeq = new long[RING];
    private int outW, outH;
    private long lastCaptureNanos;
    private long seq;

    // ---- encoder side
    private ExecutorService encoders;
    private int encoderThreads;
    private final AtomicInteger inFlight = new AtomicInteger();
    private final ConcurrentLinkedQueue<Frame> framePool = new ConcurrentLinkedQueue<>();
    private final ThreadLocal<ImageWriter> writers =
            ThreadLocal.withInitial(() -> ImageIO.getImageWritersByFormatName("jpeg").next());

    // ---- statistics
    private long statsStart = System.nanoTime();
    private int stCalls, stNoClient, stCaptured, stBusy;
    private final AtomicInteger stSent = new AtomicInteger(), stFailed = new AtomicInteger();
    private final AtomicLong stBytes = new AtomicLong(), stEncodeNanos = new AtomicLong();
    private boolean loggedFirstCall;

    /** One frame: its pixels, and the JPEG stripes made from it. */
    private static final class Frame {
        final int w, h;
        final byte[] px;
        final BufferedImage img;
        long seq;
        long startedNanos;
        int count;
        final int[] y0 = new int[MAX_STRIPES];
        final int[] sh = new int[MAX_STRIPES];
        final byte[][] jpeg = new byte[MAX_STRIPES][];
        final AtomicInteger remaining = new AtomicInteger();
        volatile boolean failed;

        Frame(int w, int h) {
            this.w = w;
            this.h = h;
            this.img = new BufferedImage(w, h, BufferedImage.TYPE_3BYTE_BGR);
            this.px = ((DataBufferByte) img.getRaster().getDataBuffer()).getData();
        }
    }

    private FrameGrabber() {}

    public void setServer(WebXRServer s) {
        this.server = s;
    }

    // ================================================================== render thread

    /** Call on the render thread once per VR frame, after the eye texture is complete. */
    public void capture(int eyeTexture, int srcW, int srcH) {
        if (broken || server == null) return;
        long now = System.nanoTime();
        stCalls++;
        if (!loggedFirstCall) {
            loggedFirstCall = true;
            WebXRMod.LOGGER.info("WebXR: first VR frame finished (eye texture {}, {}x{}). Streaming starts when a browser enters VR.",
                    eyeTexture, srcW, srcH);
        }
        try {
            if (eyeTexture == 0 || srcW <= 0 || srcH <= 0) {
                if (stCalls < 3) WebXRMod.LOGGER.warn("WebXR: eye texture is not valid yet (id {}, {}x{})", eyeTexture, srcW, srcH);
            } else if (!server.wantsFrames()) {
                stNoClient++;
                dropPending();
            } else {
                // 10% slack so that timing jitter does not skip a frame when the game runs at exactly the stream rate
                long minInterval = (long) (1_000_000_000L / (double) Math.max(1, WebXRConfig.streamFps) * 0.9);
                if (now - lastCaptureNanos >= minInterval) {
                    grab(eyeTexture, srcW, srcH, now);
                    consecutiveFailures = 0;
                }
            }
        } catch (Throwable t) {
            consecutiveFailures++;
            if (consecutiveFailures <= 3) WebXRMod.LOGGER.error("WebXR: frame capture failed ({} in a row)", consecutiveFailures, t);
            if (consecutiveFailures >= 20) {
                broken = true;
                WebXRMod.LOGGER.error("WebXR: frame capture failed 20 times in a row, streaming is switched off");
            }
        }
        if (now - statsStart >= STATS_INTERVAL_NANOS) logStats(now);
    }

    private void logStats(long now) {
        double s = (now - statsStart) / 1e9;
        int sent = stSent.getAndSet(0);
        long bytes = stBytes.getAndSet(0);
        long enc = stEncodeNanos.getAndSet(0);
        WebXRMod.LOGGER.info("WebXR stream: game frames {}/s, no browser in VR {}, captured {}/s, sent {}/s{}, skipped(busy) {}, failed {}, stripes {}",
                Math.round(stCalls / s), stNoClient, Math.round(stCaptured / s), Math.round(sent / s),
                sent > 0 ? String.format(" (avg %d KB, encode %.1f ms)", bytes / sent / 1024, enc / 1e6 / sent) : "",
                stBusy, stFailed.getAndSet(0), encoderThreads);
        stCalls = stNoClient = stCaptured = stBusy = 0;
        statsStart = now;
    }

    private void grab(int eyeTexture, int srcW, int srcH, long now) {
        ensureEncoders();

        // ---- size of the streamed picture: full size by default, only shrunk if the browser cannot hold it
        int maxTex = Math.max(1024, Math.min(server.maxTexture(), 16384));
        int w = WebXRConfig.streamWidth > 0 ? Math.min(WebXRConfig.streamWidth, srcW) : srcW;
        int h = Math.round(w * (srcH / (float) srcW));
        if (w > maxTex) {
            w = maxTex;
            h = Math.round(w * (srcH / (float) srcW));
        }
        if (h > maxTex) {
            h = maxTex;
            w = Math.round(h * (srcW / (float) srcH));
        }
        w = Math.max(16, w & ~1);
        h = Math.max(16, h & ~1);
        boolean unscaled = (w == (srcW & ~1) && h == (srcH & ~1));
        int blitSrcW = srcW, blitSrcH = srcH;
        if (unscaled) { // JPEG wants even sizes: crop at most 1 pixel instead of scaling
            blitSrcW = w;
            blitSrcH = h;
        }
        int filter = unscaled ? GL11.GL_NEAREST : GL11.GL_LINEAR;
        if (w != outW || h != outH || srcFbo == 0) createTargets(w, h);

        // ---- save the GL state we touch
        int prevRead = GL11.glGetInteger(GL30.GL_READ_FRAMEBUFFER_BINDING);
        int prevDraw = GL11.glGetInteger(GL30.GL_DRAW_FRAMEBUFFER_BINDING);
        int prevPack = GL11.glGetInteger(GL21.GL_PIXEL_PACK_BUFFER_BINDING);
        int prevPackAlign = GL11.glGetInteger(GL11.GL_PACK_ALIGNMENT);
        boolean scissor = GL11.glIsEnabled(GL11.GL_SCISSOR_TEST); // an active scissor would clip (blank) the copy
        if (scissor) GL11.glDisable(GL11.GL_SCISSOR_TEST);
        while (GL11.glGetError() != GL11.GL_NO_ERROR) { /* errors that are not ours */ }
        try {
            collectReady(); // frames of earlier calls whose copy has finished meanwhile (no waiting)

            int slot = freeSlot();
            if (slot < 0 || inFlight.get() >= MAX_FRAMES_IN_FLIGHT) {
                stBusy++; // GPU or encoders are behind: skip this frame instead of stalling the game
                return;
            }
            lastCaptureNanos = now;
            stCaptured++;

            // scale + vertical flip (GL images are bottom-up, JPEG is top-down)
            GL30.glBindFramebuffer(GL30.GL_READ_FRAMEBUFFER, srcFbo);
            GL30.glFramebufferTexture2D(GL30.GL_READ_FRAMEBUFFER, GL30.GL_COLOR_ATTACHMENT0, GL11.GL_TEXTURE_2D, eyeTexture, 0);
            GL30.glBindFramebuffer(GL30.GL_DRAW_FRAMEBUFFER, dstFbo);
            GL30.glBlitFramebuffer(0, 0, blitSrcW, blitSrcH, 0, outH, outW, 0, GL11.GL_COLOR_BUFFER_BIT, filter);

            // start an async read of the small image (BGR = layout of TYPE_3BYTE_BGR, no conversion later)
            GL30.glBindFramebuffer(GL30.GL_READ_FRAMEBUFFER, dstFbo);
            GL11.glPixelStorei(GL11.GL_PACK_ALIGNMENT, 1);
            GL15.glBindBuffer(GL21.GL_PIXEL_PACK_BUFFER, pbo[slot]);
            GL11.glReadPixels(0, 0, outW, outH, GL12.GL_BGR, GL11.GL_UNSIGNED_BYTE, 0L);
            fence[slot] = GL32.glFenceSync(GL32.GL_SYNC_GPU_COMMANDS_COMPLETE, 0);
            slotSeq[slot] = ++seq;
            GL11.glFlush();

            // Try to finish THIS frame right now (usually succeeds within a fraction of a millisecond).
            if (tryCollect(slot, SAME_FRAME_WAIT_NANOS)) {
                for (int i = 0; i < RING; i++) releaseFence(i); // anything older that is still pending is obsolete
            }

            int err = GL11.glGetError();
            if (err != GL11.GL_NO_ERROR && glErrorsLogged++ < 5) {
                WebXRMod.LOGGER.warn("WebXR: OpenGL error 0x{} while copying the frame (size {}x{} -> {}x{})",
                        Integer.toHexString(err), srcW, srcH, outW, outH);
            }
        } finally {
            if (scissor) GL11.glEnable(GL11.GL_SCISSOR_TEST);
            GL15.glBindBuffer(GL21.GL_PIXEL_PACK_BUFFER, prevPack);
            GL11.glPixelStorei(GL11.GL_PACK_ALIGNMENT, prevPackAlign);
            GL30.glBindFramebuffer(GL30.GL_READ_FRAMEBUFFER, prevRead);
            GL30.glBindFramebuffer(GL30.GL_DRAW_FRAMEBUFFER, prevDraw);
        }
    }

    private int freeSlot() {
        for (int i = 0; i < RING; i++) if (fence[i] == 0) return i;
        return -1;
    }

    /** Hands over every pending frame whose copy is already finished, oldest first, without waiting. */
    private void collectReady() {
        for (;;) {
            int oldest = -1;
            for (int i = 0; i < RING; i++) {
                if (fence[i] != 0 && (oldest < 0 || slotSeq[i] < slotSeq[oldest])) oldest = i;
            }
            if (oldest < 0 || !tryCollect(oldest, 0)) return;
        }
    }

    /** @return true if the copy in this slot was finished (and handed to the encoders, or dropped if they are busy) */
    private boolean tryCollect(int slot, long timeoutNanos) {
        int r = GL32.glClientWaitSync(fence[slot], timeoutNanos > 0 ? GL32.GL_SYNC_FLUSH_COMMANDS_BIT : 0, timeoutNanos);
        if (r == GL32.GL_WAIT_FAILED) throw new IllegalStateException("glClientWaitSync failed");
        if (r != GL32.GL_ALREADY_SIGNALED && r != GL32.GL_CONDITION_SATISFIED) return false;

        long frameSeq = slotSeq[slot];
        releaseFence(slot);
        if (inFlight.get() >= MAX_FRAMES_IN_FLIGHT) {
            stBusy++;
            return true;
        }

        Frame f = framePool.poll();
        if (f == null || f.w != outW || f.h != outH) f = new Frame(outW, outH);
        f.seq = frameSeq;

        GL15.glBindBuffer(GL21.GL_PIXEL_PACK_BUFFER, pbo[slot]);
        ByteBuffer mapped = GL30.glMapBufferRange(GL21.GL_PIXEL_PACK_BUFFER, 0, (long) outW * outH * 3, GL30.GL_MAP_READ_BIT);
        if (mapped == null) {
            framePool.offer(f);
            throw new IllegalStateException("glMapBufferRange returned null");
        }
        mapped.get(f.px, 0, Math.min(f.px.length, mapped.remaining()));
        GL15.glUnmapBuffer(GL21.GL_PIXEL_PACK_BUFFER);
        encode(f);
        return true;
    }

    private void releaseFence(int slot) {
        if (fence[slot] != 0) {
            GL32.glDeleteSync(fence[slot]);
            fence[slot] = 0;
        }
    }

    private void dropPending() {
        if (srcFbo == 0) return;
        for (int i = 0; i < RING; i++) releaseFence(i);
    }

    private void createTargets(int w, int h) {
        int prevRb = GL11.glGetInteger(GL30.GL_RENDERBUFFER_BINDING);
        int prevFbo = GL11.glGetInteger(GL30.GL_DRAW_FRAMEBUFFER_BINDING);
        int prevPack = GL11.glGetInteger(GL21.GL_PIXEL_PACK_BUFFER_BINDING);

        destroyTargets();
        outW = w;
        outH = h;
        framePool.clear();

        srcFbo = GL30.glGenFramebuffers();
        dstFbo = GL30.glGenFramebuffers();
        dstRb = GL30.glGenRenderbuffers();
        GL30.glBindRenderbuffer(GL30.GL_RENDERBUFFER, dstRb);
        GL30.glRenderbufferStorage(GL30.GL_RENDERBUFFER, GL11.GL_RGBA8, w, h);
        GL30.glBindFramebuffer(GL30.GL_DRAW_FRAMEBUFFER, dstFbo);
        GL30.glFramebufferRenderbuffer(GL30.GL_DRAW_FRAMEBUFFER, GL30.GL_COLOR_ATTACHMENT0, GL30.GL_RENDERBUFFER, dstRb);

        for (int i = 0; i < RING; i++) {
            pbo[i] = GL15.glGenBuffers();
            GL15.glBindBuffer(GL21.GL_PIXEL_PACK_BUFFER, pbo[i]);
            GL15.glBufferData(GL21.GL_PIXEL_PACK_BUFFER, (long) w * h * 3, GL15.GL_STREAM_READ);
        }

        GL15.glBindBuffer(GL21.GL_PIXEL_PACK_BUFFER, prevPack);
        GL30.glBindFramebuffer(GL30.GL_DRAW_FRAMEBUFFER, prevFbo);
        GL30.glBindRenderbuffer(GL30.GL_RENDERBUFFER, prevRb);
        WebXRMod.LOGGER.info("WebXR: streaming {}x{} JPEG, up to {} fps, {} encoder threads", w, h, WebXRConfig.streamFps, encoderThreads);
    }

    private void destroyTargets() {
        for (int i = 0; i < RING; i++) {
            releaseFence(i);
            if (pbo[i] != 0) GL15.glDeleteBuffers(pbo[i]);
            pbo[i] = 0;
        }
        if (srcFbo != 0) GL30.glDeleteFramebuffers(srcFbo);
        if (dstFbo != 0) GL30.glDeleteFramebuffers(dstFbo);
        if (dstRb != 0) GL30.glDeleteRenderbuffers(dstRb);
        srcFbo = dstFbo = dstRb = 0;
    }

    /** Called when the VR renderer is torn down (GL objects are tied to the context). */
    public void release() {
        try {
            destroyTargets();
        } catch (Throwable ignored) {
        }
        outW = outH = 0;
        consecutiveFailures = 0;
        broken = false;
    }

    // ================================================================== encoder threads

    private void ensureEncoders() {
        if (encoders != null) return;
        int n = WebXRConfig.encodeThreads;
        if (n <= 0) n = Math.max(2, Math.min(6, Runtime.getRuntime().availableProcessors() / 2));
        encoderThreads = Math.min(n, MAX_STRIPES);
        AtomicInteger counter = new AtomicInteger();
        encoders = Executors.newFixedThreadPool(encoderThreads, r -> {
            Thread t = new Thread(r, "WebXR-jpeg-" + counter.incrementAndGet());
            t.setDaemon(true);
            return t;
        });
    }

    /** Cuts the frame into stripes and encodes all of them at the same time. */
    private void encode(Frame f) {
        int n = Math.max(1, Math.min(encoderThreads, f.h / 64));
        int base = ((f.h / n) / 16) * 16; // stripe borders on JPEG block boundaries
        f.count = n;
        for (int i = 0; i < n; i++) {
            f.y0[i] = i * base;
            f.sh[i] = (i == n - 1) ? f.h - i * base : base;
            f.jpeg[i] = null;
        }
        f.failed = false;
        f.remaining.set(n);
        f.startedNanos = System.nanoTime();
        inFlight.incrementAndGet();
        for (int i = 0; i < n; i++) {
            final int idx = i;
            encoders.execute(() -> {
                try {
                    f.jpeg[idx] = encodeStripe(f, f.y0[idx], f.sh[idx]);
                } catch (Throwable t) {
                    f.failed = true;
                    if (stFailed.incrementAndGet() <= 3) WebXRMod.LOGGER.error("WebXR: JPEG encoding failed", t);
                } finally {
                    if (f.remaining.decrementAndGet() == 0) finish(f);
                }
            });
        }
    }

    private byte[] encodeStripe(Frame f, int y0, int h) throws Exception {
        ImageWriter writer = writers.get();
        ImageWriteParam p = writer.getDefaultWriteParam();
        p.setCompressionMode(ImageWriteParam.MODE_EXPLICIT);
        p.setCompressionQuality(WebXRConfig.jpegQuality);
        BufferedImage part = f.img.getSubimage(0, y0, f.w, h);
        ByteArrayOutputStream bos = new ByteArrayOutputStream(Math.max(4096, f.w * h / 6));
        // in-memory output: ImageIO.createImageOutputStream() may write a temp FILE per picture
        try (ImageOutputStream ios = new MemoryCacheImageOutputStream(bos)) {
            writer.setOutput(ios);
            writer.write(null, new IIOImage(part, null, null), p);
        } finally {
            writer.reset();
        }
        return bos.toByteArray();
    }

    /** Runs on the encoder thread that finished the last stripe. */
    private void finish(Frame f) {
        try {
            if (f.failed || server == null) return;
            byte[] msg = buildMessage(f);
            server.broadcastFrame(msg, f.seq);
            stSent.incrementAndGet();
            stBytes.addAndGet(msg.length);
            stEncodeNanos.addAndGet(System.nanoTime() - f.startedNanos);
        } catch (Throwable t) {
            WebXRMod.LOGGER.warn("WebXR: could not send a frame: {}", t.toString());
        } finally {
            for (int i = 0; i < f.count; i++) f.jpeg[i] = null;
            framePool.offer(f);
            inFlight.decrementAndGet();
        }
    }

    /**
     * One binary WebSocket message per frame, all numbers big-endian:
     *   u8 0x56 ('V') | u8 stripeCount | u16 width | u16 height | u32 sequence
     *   then per stripe: u16 y | u16 height | u32 jpegLength
     *   then the JPEG data of the stripes, in the same order.
     */
    private static byte[] buildMessage(Frame f) {
        int total = 10 + 8 * f.count;
        for (int i = 0; i < f.count; i++) total += f.jpeg[i].length;
        ByteBuffer b = ByteBuffer.allocate(total); // big-endian by default
        b.put((byte) MSG_VIDEO).put((byte) f.count).putShort((short) f.w).putShort((short) f.h).putInt((int) f.seq);
        for (int i = 0; i < f.count; i++) {
            b.putShort((short) f.y0[i]).putShort((short) f.sh[i]).putInt(f.jpeg[i].length);
        }
        for (int i = 0; i < f.count; i++) b.put(f.jpeg[i]);
        return b.array();
    }
}
