'use strict';
/* Vivecraft WebXR client.
 *  - WebSocket to the PC. Binary messages are tagged by their FIRST byte:
 *        0x56 'V'  one video frame = several JPEG stripes (decoded in parallel)   (format: see FrameGrabber.java)
 *        0x41 'A'  raw 16-bit stereo PCM sound
 *    Text messages: haptics, session answer, audio format.
 *  - Sends head/controller poses ({"t":"p",...}) and session start/stop ({"t":"s","vr":bool,"maxTex":n}).
 *  - WebXR "immersive-vr": shows the newest video frame filling the view (or a status panel while there is no video).
 */
const $ = (id) => document.getElementById(id);
const params = new URLSearchParams(location.search);
const SCREEN_DIST = clampNum(parseFloat(params.get('d')), 0.5, 5, 1.5);
const SCREEN_WIDTH = clampNum(parseFloat(params.get('w')), 0.5, 6, 2.0);
// Default: the picture fills the headset view. ?d= or ?w= or ?screen=1 -> small floating screen instead.
const FLOATING = params.has('d') || params.has('w') || params.get('screen') === '1';

function clampNum(v, lo, hi, def) { return Number.isFinite(v) ? Math.min(hi, Math.max(lo, v)) : def; }
const r4 = (v) => Math.round(v * 10000) / 10000;

const MSG_VIDEO = 0x56, MSG_AUDIO = 0x41;

// ------------------------------------------------------------------ state
let ws = null, wsOpen = false;
let session = null, refSpace = null, gl = null, glLayer = null;
let floorOffset = 0;
let prog = null, vbo = null, loc = {};
let videoTex = null, infoTex = null, texW = 0, texH = 0;
let frameAspect = 16 / 9;
let latestVideo = null, decoding = false, lastSeq = -1;
let pending = null;               // a fully decoded frame, waiting to be uploaded in the next XR frame
let videoReady = false, lastShownAt = 0;
let infoCanvas = null, infoCtx = null, infoDirty = true, infoAt = 0;
const stats = { msgs: 0, video: 0, audio: 0, decoded: 0, errors: 0, lastError: '', bytes: 0, w: 0, h: 0, stripes: 0, lastKB: 0, droppedOld: 0 };

function setStatus(text) { $('status').textContent = text; }
function showHelp(html) { const h = $('help'); h.innerHTML = html; h.style.display = 'block'; }

// ------------------------------------------------------------------ network
function connect() {
  const proto = location.protocol === 'https:' ? 'wss' : 'ws';
  ws = new WebSocket(proto + '://' + location.host + '/ws');
  ws.binaryType = 'arraybuffer';
  ws.onopen = () => { wsOpen = true; if (!session) setStatus('Connected to Minecraft. Press Enter VR.'); updateButton(); };
  ws.onclose = () => {
    wsOpen = false; updateButton();
    if (session) { try { session.end(); } catch (e) {} }
    setStatus('Connection lost. Retrying…');
    setTimeout(connect, 2000);
  };
  ws.onerror = () => {};
  ws.onmessage = onMessage;
}

function onMessage(ev) {
  if (typeof ev.data !== 'string') {
    const buf = ev.data;
    stats.msgs++; stats.bytes += buf.byteLength;
    if (buf.byteLength < 2) return;
    const kind = new Uint8Array(buf, 0, 1)[0];
    if (kind === MSG_VIDEO) {
      stats.video++;
      latestVideo = buf;           // newest wins: an older, not yet decoded frame is simply dropped
      if (!decoding) pumpDecode();
    } else if (kind === MSG_AUDIO) {
      stats.audio++;
      playAudio(buf);
    }
    infoDirty = true;
    return;
  }
  let m; try { m = JSON.parse(ev.data); } catch (e) { return; }
  if (m.t === 'h') haptic(m.hand, m.d, m.a);
  else if (m.t === 'audio') { audioRate = m.rate || 48000; playHead = 0; }
  else if (m.t === 'session' && m.ok === false) {
    setStatus('Another headset is already playing.');
    if (session) session.end();
  }
}

// ------------------------------------------------------------------ video: parse + decode (all stripes at once)
// <parse>
// Message: u8 0x56 | u8 count | u16 width | u16 height | u32 seq | count * (u16 y, u16 h, u32 len) | jpeg data ...
function parseVideoMessage(buf) {
  const dv = new DataView(buf);
  if (dv.getUint8(0) !== 0x56) throw new Error('not a video message');
  const count = dv.getUint8(1), w = dv.getUint16(2), h = dv.getUint16(4), seq = dv.getUint32(6);
  let tab = 10, data = 10 + count * 8;
  const stripes = [];
  for (let i = 0; i < count; i++, tab += 8) {
    const y = dv.getUint16(tab), sh = dv.getUint16(tab + 2), len = dv.getUint32(tab + 4);
    if (data + len > buf.byteLength) throw new Error('video message is cut off');
    stripes.push({ y, h: sh, bytes: new Uint8Array(buf, data, len) });
    data += len;
  }
  return { w, h, seq, stripes };
}
// </parse>

async function pumpDecode() {
  decoding = true;
  while (latestVideo) {
    const buf = latestVideo; latestVideo = null;
    try {
      const f = parseVideoMessage(buf);
      const maxTex = gl ? gl.getParameter(gl.MAX_TEXTURE_SIZE) : 4096;
      if (f.w > maxTex || f.h > maxTex) throw new Error('video ' + f.w + 'x' + f.h + ' is bigger than this GPU allows (' + maxTex + ')');
      if (f.seq <= lastSeq && lastSeq - f.seq < 0x40000000) { stats.droppedOld++; continue; }
      const bitmaps = await Promise.all(f.stripes.map((s) => createImageBitmap(new Blob([s.bytes], { type: 'image/jpeg' }))));
      if (pending) for (const s of pending.stripes) s.bm.close();   // never uploaded: replaced by this newer frame
      pending = { w: f.w, h: f.h, stripes: f.stripes.map((s, i) => ({ y: s.y, bm: bitmaps[i] })) };
      lastSeq = f.seq;
      stats.decoded++; stats.w = f.w; stats.h = f.h; stats.stripes = f.stripes.length; stats.lastKB = Math.round(buf.byteLength / 1024);
    } catch (e) {
      stats.errors++; stats.lastError = String(e && e.message ? e.message : e);
      if (stats.errors <= 3) console.error('video frame failed', e);
    }
    infoDirty = true;
  }
  decoding = false;
}

setInterval(() => { if (wsOpen) ws.send('{"t":"k"}'); }, 4000);

function send(obj) { if (wsOpen) ws.send(JSON.stringify(obj)); }

// ------------------------------------------------------------------ audio (raw 16-bit stereo PCM from the PC)
let actx = null, audioRate = 48000, playHead = 0;
function startAudioContext() {   // must run inside the click on "Enter VR" (browsers need a user gesture)
  try {
    if (!actx) actx = new (window.AudioContext || window.webkitAudioContext)({ latencyHint: 'interactive' });
    if (actx.state === 'suspended') actx.resume();
  } catch (e) { actx = null; }
}
function playAudio(buf) {
  if (!actx || actx.state !== 'running') return;
  const frames = (buf.byteLength - 1) >> 2;
  if (frames <= 0) return;
  const pcm = new Int16Array(buf.slice(1, 1 + frames * 4));
  const ab = actx.createBuffer(2, frames, audioRate);
  const L = ab.getChannelData(0), R = ab.getChannelData(1);
  for (let i = 0; i < frames; i++) { L[i] = pcm[2 * i] / 32768; R[i] = pcm[2 * i + 1] / 32768; }
  const now = actx.currentTime;
  if (playHead < now + 0.005) playHead = now + 0.03;      // ran dry: restart with a small cushion
  else if (playHead > now + 0.2) return;                  // too far ahead (late burst): drop it, stay in sync
  const src = actx.createBufferSource();
  src.buffer = ab; src.connect(actx.destination); src.start(playHead);
  playHead += ab.duration;
}

function haptic(hand, durMs, amp) {
  if (!session) return;
  const want = hand === 0 ? 'right' : 'left';
  for (const src of session.inputSources) {
    if (src.handedness !== want || !src.gamepad) continue;
    const gp = src.gamepad;
    try {
      if (gp.hapticActuators && gp.hapticActuators[0] && gp.hapticActuators[0].pulse) gp.hapticActuators[0].pulse(amp, durMs);
      else if (gp.vibrationActuator) gp.vibrationActuator.playEffect('dual-rumble', { duration: durMs, strongMagnitude: amp, weakMagnitude: amp });
    } catch (e) {}
  }
}

// ------------------------------------------------------------------ small matrix helpers (column-major, like WebXR)
function mul(a, b) {
  const o = new Float32Array(16);
  for (let c = 0; c < 4; c++) for (let r = 0; r < 4; r++) {
    let s = 0; for (let k = 0; k < 4; k++) s += a[k * 4 + r] * b[c * 4 + k];
    o[c * 4 + r] = s;
  }
  return o;
}
function translation(x, y, z) { const m = new Float32Array(16); m[0] = m[5] = m[10] = m[15] = 1; m[12] = x; m[13] = y; m[14] = z; return m; }

// ------------------------------------------------------------------ WebGL: one textured quad
const VS = `#version 300 es
in vec2 aPos;
uniform mat4 uMVP;
uniform vec2 uHalf;
uniform vec2 uScale;
uniform float uFull;
out vec2 vUv;
void main() {
  vUv = vec2(aPos.x * 0.5 + 0.5, 0.5 - aPos.y * 0.5);
  if (uFull > 0.5) gl_Position = vec4(aPos * uScale, 0.0, 1.0);   // fills the eye view directly in clip space
  else gl_Position = uMVP * vec4(aPos * uHalf, 0.0, 1.0);          // floating screen in the room
}`;
const FS = `#version 300 es
precision mediump float;
in vec2 vUv;
uniform sampler2D uTex;
out vec4 o;
void main() { o = vec4(texture(uTex, vUv).rgb, 1.0); }`;

function compile(type, src) {
  const s = gl.createShader(type); gl.shaderSource(s, src); gl.compileShader(s);
  if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(s));
  return s;
}

function makeTexture() {
  const t = gl.createTexture();
  gl.bindTexture(gl.TEXTURE_2D, t);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
  return t;
}

function initGL() {
  const canvas = document.createElement('canvas');
  gl = canvas.getContext('webgl2', { xrCompatible: true, antialias: false, alpha: false });
  if (!gl) throw new Error('WebGL2 is not available');
  prog = gl.createProgram();
  gl.attachShader(prog, compile(gl.VERTEX_SHADER, VS));
  gl.attachShader(prog, compile(gl.FRAGMENT_SHADER, FS));
  gl.bindAttribLocation(prog, 0, 'aPos');
  gl.linkProgram(prog);
  if (!gl.getProgramParameter(prog, gl.LINK_STATUS)) throw new Error(gl.getProgramInfoLog(prog));
  loc = {
    mvp: gl.getUniformLocation(prog, 'uMVP'),
    half: gl.getUniformLocation(prog, 'uHalf'),
    scale: gl.getUniformLocation(prog, 'uScale'),
    full: gl.getUniformLocation(prog, 'uFull'),
    tex: gl.getUniformLocation(prog, 'uTex'),
  };
  vbo = gl.createBuffer();
  gl.bindBuffer(gl.ARRAY_BUFFER, vbo);
  gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 1, -1, -1, 1, 1, 1]), gl.STATIC_DRAW);
  videoTex = makeTexture();
  infoTex = makeTexture();
  infoCanvas = document.createElement('canvas');
  infoCanvas.width = 1024; infoCanvas.height = 512;
  infoCtx = infoCanvas.getContext('2d');
}

// A text panel that is shown instead of the video while there is none (so a black screen can be told apart from
// "connected, but no video arrives"). It shows the counters, which say exactly where the stream stops.
function drawInfo() {
  const c = infoCtx;
  c.fillStyle = '#10163a'; c.fillRect(0, 0, 1024, 512);
  c.fillStyle = '#55ff55'; c.font = 'bold 54px sans-serif'; c.fillText('Vivecraft WebXR', 40, 80);
  c.fillStyle = '#ffffff'; c.font = '38px sans-serif';
  const lines = [
    'Connection to Minecraft: ' + (wsOpen ? 'OK' : 'LOST'),
    'Video messages received: ' + stats.video + '   decoded: ' + stats.decoded + '   errors: ' + stats.errors,
    'Last video: ' + (stats.w ? stats.w + 'x' + stats.h + ', ' + stats.stripes + ' stripes, ' + stats.lastKB + ' KB' : '-'),
    'Sound messages: ' + stats.audio + '   all messages: ' + stats.msgs,
    stats.video === 0 ? 'No video arrives from the PC yet.' : (stats.decoded === 0 ? 'Video arrives but cannot be decoded.' : 'Video is working.'),
  ];
  lines.forEach((l, i) => c.fillText(l, 40, 160 + i * 56));
  if (stats.lastError) { c.fillStyle = '#ff8888'; c.font = '30px sans-serif'; c.fillText(stats.lastError.slice(0, 70), 40, 480); }
  else if (stats.video === 0) { c.fillStyle = '#aaaaaa'; c.font = '30px sans-serif'; c.fillText('PC log: look for lines starting with "WebXR stream:"', 40, 480); }
}

// ------------------------------------------------------------------ VR session
async function enterVR() {
  startAudioContext();
  if (!navigator.xr) {
    showHelp('<b>WebXR is not available here.</b><br>Browsers only allow WebXR on secure pages. ' +
      'Open the <code>https://</code> address shown on the PC (accept the certificate warning), ' +
      'or use <code>http://localhost</code> via <code>adb reverse</code>.');
    return;
  }
  if (!(await navigator.xr.isSessionSupported('immersive-vr'))) {
    showHelp('This browser/device does not support immersive VR.');
    return;
  }
  try {
    if (!gl) initGL();
    try {
      session = await navigator.xr.requestSession('immersive-vr', { requiredFeatures: ['local-floor'] });
      refSpace = await session.requestReferenceSpace('local-floor'); floorOffset = 0;
    } catch (e) {
      session = await navigator.xr.requestSession('immersive-vr', { optionalFeatures: ['local'] });
      refSpace = await session.requestReferenceSpace('local'); floorOffset = 1.6; // assume standing eye height
    }
    await gl.makeXRCompatible();
    glLayer = new XRWebGLLayer(session, gl, { antialias: false, depth: false, stencil: false, alpha: false });
    session.updateRenderState({ baseLayer: glLayer });
    session.addEventListener('end', onSessionEnd);
    // highest display refresh rate the headset offers = freshest head pose sent to the PC
    try {
      if (session.supportedFrameRates && session.updateTargetFrameRate) {
        session.updateTargetFrameRate(Math.max(...session.supportedFrameRates)).catch(() => {});
      }
    } catch (e) {}
    videoReady = false; lastSeq = -1; pending = null; texW = texH = 0; infoDirty = true;
    send({ t: 's', vr: true, maxTex: gl.getParameter(gl.MAX_TEXTURE_SIZE) });
    setStatus('In VR.');
    $('enter').disabled = true;
    session.requestAnimationFrame(onXRFrame);
  } catch (e) {
    session = null;
    showHelp('Could not start VR: ' + (e && e.message ? e.message : e));
  }
}

function onSessionEnd() {
  send({ t: 's', vr: false });
  session = null; refSpace = null; glLayer = null; videoReady = false; texW = texH = 0;
  setStatus(wsOpen ? 'Connected to Minecraft. Press Enter VR.' : 'Connection lost. Retrying…');
  updateButton();
}

// Uploads the newest decoded frame (all stripes) into the video texture.
function uploadPending() {
  const fr = pending; pending = null;
  gl.bindTexture(gl.TEXTURE_2D, videoTex);
  gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, false);
  gl.pixelStorei(gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL, false);
  if (fr.w !== texW || fr.h !== texH) {
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, fr.w, fr.h, 0, gl.RGBA, gl.UNSIGNED_BYTE, null);
    texW = fr.w; texH = fr.h;
  }
  for (const s of fr.stripes) {
    gl.texSubImage2D(gl.TEXTURE_2D, 0, 0, s.y, gl.RGBA, gl.UNSIGNED_BYTE, s.bm);
    s.bm.close();
  }
  const err = gl.getError();
  if (err !== gl.NO_ERROR) { stats.errors++; stats.lastError = 'texture upload failed, GL error ' + err; infoDirty = true; return; }
  frameAspect = fr.w / fr.h;
  videoReady = true; lastShownAt = performance.now();
}

function onXRFrame(time, frame) {
  if (!session) return;
  session.requestAnimationFrame(onXRFrame);
  const pose = frame.getViewerPose(refSpace);
  if (!pose) return;
  sendPose(frame, pose);

  if (pending) uploadPending();

  // video, or the status panel while there is no (or stalled) video
  const showVideo = videoReady && performance.now() - lastShownAt < 3000;
  let aspect = frameAspect;
  gl.bindTexture(gl.TEXTURE_2D, showVideo ? videoTex : infoTex);
  if (!showVideo) {
    if (performance.now() - infoAt > 250) {
      infoAt = performance.now(); infoDirty = false;
      drawInfo();
      gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, false);
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, infoCanvas);
    }
    aspect = 2;
  }

  gl.bindFramebuffer(gl.FRAMEBUFFER, glLayer.framebuffer);
  gl.clearColor(0, 0, 0, 1);
  gl.clear(gl.COLOR_BUFFER_BIT);
  gl.disable(gl.DEPTH_TEST);
  gl.useProgram(prog);
  gl.bindBuffer(gl.ARRAY_BUFFER, vbo);
  gl.enableVertexAttribArray(0);
  gl.vertexAttribPointer(0, 2, gl.FLOAT, false, 0, 0);
  gl.activeTexture(gl.TEXTURE0);
  gl.uniform1i(loc.tex, 0);
  gl.uniform2f(loc.half, SCREEN_WIDTH / 2, SCREEN_WIDTH / aspect / 2);
  gl.uniform1f(loc.full, FLOATING ? 0 : 1);

  // Floating mode: the screen is fixed relative to the HEAD: model = headPose * translate(0,0,-dist).
  const model = mul(pose.transform.matrix, translation(0, 0, -SCREEN_DIST));
  for (const view of pose.views) {
    const vp = glLayer.getViewport(view);
    gl.viewport(vp.x, vp.y, vp.width, vp.height);
    if (FLOATING) {
      gl.uniformMatrix4fv(loc.mvp, false, mul(view.projectionMatrix, mul(view.transform.inverse.matrix, model)));
    } else {
      const sc = fitScale(aspect, vp.width / vp.height);
      gl.uniform2f(loc.scale, sc[0], sc[1]);
    }
    gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
  }
}

// Scale of the picture quad in clip space (1 = whole eye view): the whole picture is visible and as large as
// possible, without distortion. A = picture aspect, V = eye view aspect.
function fitScale(A, V) {
  return A > V ? [1, V / A] : [A / V, 1];
}

// ------------------------------------------------------------------ tracking -> PC
function packPose(t) {
  return [r4(t.position.x), r4(t.position.y + floorOffset), r4(t.position.z),
          r4(t.orientation.x), r4(t.orientation.y), r4(t.orientation.z), r4(t.orientation.w)];
}

function sendPose(frame, viewerPose) {
  if (!wsOpen || ws.bufferedAmount > 200000) return;
  const msg = { t: 'p', h: packPose(viewerPose.transform) };
  if (viewerPose.views.length >= 2) {
    const a = viewerPose.views[0].transform.position, b = viewerPose.views[1].transform.position;
    msg.i = r4(Math.hypot(a.x - b.x, a.y - b.y, a.z - b.z));
  }
  for (const src of session.inputSources) {
    const space = src.gripSpace || src.targetRaySpace;
    if (!space) continue;
    const p = frame.getPose(space, refSpace);
    if (!p) continue;
    const hand = { p: packPose(p.transform), b: [], a: [] };
    if (src.gamepad) {
      hand.b = src.gamepad.buttons.slice(0, 6).map((b) => Math.round(b.value * 100) / 100);
      hand.a = src.gamepad.axes.map((v) => Math.round(v * 100) / 100);
    }
    if (src.profiles && src.profiles.length) msg.pr = src.profiles[0];
    if (src.handedness === 'right') msg.r = hand;
    else if (src.handedness === 'left') msg.l = hand;
  }
  ws.send(JSON.stringify(msg));
}

// ------------------------------------------------------------------ page
function updateButton() { $('enter').disabled = !(wsOpen && !session); }
$('enter').addEventListener('click', enterVR);
if (!navigator.xr) {
  setStatus('WebXR is not available in this page.');
  showHelp('Browsers only allow WebXR on <b>secure</b> pages. Open the <code>https://</code> address shown on the PC ' +
    'and accept the certificate warning (Advanced → continue).');
}
connect();
