#!/bin/sh
# Builds vivecraft-webxr-<version>.jar on Alpine Linux (POSIX sh / busybox ash).
# Usage:  sh build-alpine.sh        (run it inside the project folder)
# Needs internet (Gradle, Minecraft and Fabric files are downloaded on the first build).
set -eu

cd "$(dirname "$0")"
PROJECT_DIR=$(pwd)

say() { printf '\n==> %s\n' "$*"; }
die() { printf 'ERROR: %s\n' "$*" >&2; exit 1; }

# ---- 1. root / sudo / doas for "apk add"
if [ "$(id -u)" -eq 0 ]; then SUDO=""
elif command -v doas >/dev/null 2>&1; then SUDO="doas"
elif command -v sudo >/dev/null 2>&1; then SUDO="sudo"
else SUDO="__none__"; fi

# ---- 2. packages: JDK 21 + tools (gcompat/libstdc++ help Gradle's native helpers on musl)
say "Checking packages"
NEED=""
command -v javac >/dev/null 2>&1 || NEED="$NEED openjdk21-jdk"
command -v curl  >/dev/null 2>&1 || NEED="$NEED curl"
command -v unzip >/dev/null 2>&1 || NEED="$NEED unzip"
command -v bash  >/dev/null 2>&1 || NEED="$NEED bash"
[ -e /lib/libgcompat.so.0 ] || NEED="$NEED gcompat"
[ -e /usr/lib/libstdc++.so.6 ] || NEED="$NEED libstdc++"
if [ -n "$NEED" ]; then
  [ "$SUDO" = "__none__" ] && die "Missing packages:$NEED  - run as root or install doas/sudo, then retry."
  say "Installing:$NEED"
  # shellcheck disable=SC2086
  $SUDO apk add --no-cache $NEED
fi

# ---- 3. Java 21 must be the active JDK
JAVA_HOME_GUESS=$(ls -d /usr/lib/jvm/java-21-openjdk* 2>/dev/null | head -n 1 || true)
if [ -z "${JAVA_HOME:-}" ] || ! "$JAVA_HOME/bin/javac" -version 2>&1 | grep -q ' 21'; then
  [ -n "$JAVA_HOME_GUESS" ] || die "JDK 21 not found in /usr/lib/jvm (package openjdk21-jdk)."
  JAVA_HOME="$JAVA_HOME_GUESS"
fi
export JAVA_HOME
export PATH="$JAVA_HOME/bin:$PATH"
say "Using $(javac -version 2>&1) at $JAVA_HOME"

# ---- 4. Gradle: the version this project asks for (gradle/wrapper/gradle-wrapper.properties)
GRADLE_VERSION=$(sed -n 's/.*gradle-\([0-9][0-9.]*\)-bin\.zip.*/\1/p' gradle/wrapper/gradle-wrapper.properties | head -n 1)
GRADLE_VERSION=${GRADLE_VERSION:-9.2.0}
GRADLE_ROOT="${GRADLE_INSTALL_DIR:-$HOME/.local/gradle}"
GRADLE_BIN="$GRADLE_ROOT/gradle-$GRADLE_VERSION/bin/gradle"

if [ ! -x "$GRADLE_BIN" ]; then
  say "Downloading Gradle $GRADLE_VERSION"
  mkdir -p "$GRADLE_ROOT"
  TMP_ZIP=$(mktemp /tmp/gradle.XXXXXX.zip)
  curl -fL --retry 3 -o "$TMP_ZIP" "https://services.gradle.org/distributions/gradle-$GRADLE_VERSION-bin.zip" \
    || { rm -f "$TMP_ZIP"; die "Could not download Gradle (no internet?)."; }
  unzip -q -o "$TMP_ZIP" -d "$GRADLE_ROOT"
  rm -f "$TMP_ZIP"
fi
[ -x "$GRADLE_BIN" ] || die "Gradle was not installed correctly: $GRADLE_BIN"

# ---- 5. Build (the Vivecraft jar in ./libs is only compiled against, as the README says)
[ -f libs/vivecraft-1_21_11-1_3_15-fabric.jar ] || die "libs/vivecraft-1_21_11-1_3_15-fabric.jar is missing."
say "Building (the first run downloads Minecraft + Fabric and can take several minutes)"
"$GRADLE_BIN" --no-daemon --console=plain build

# ---- 6. Collect the result
OUT_DIR="$PROJECT_DIR/dist"
mkdir -p "$OUT_DIR"
JAR=$(ls "$PROJECT_DIR"/build/libs/vivecraft-webxr-*.jar 2>/dev/null | grep -v -e '-sources' -e '-dev' | head -n 1 || true)
[ -n "$JAR" ] || die "Build finished but no jar was found in build/libs."
cp "$JAR" "$OUT_DIR/"
say "Done: $OUT_DIR/$(basename "$JAR")"
echo "Put it in your mods folder next to Fabric Loader and the Vivecraft jar."
