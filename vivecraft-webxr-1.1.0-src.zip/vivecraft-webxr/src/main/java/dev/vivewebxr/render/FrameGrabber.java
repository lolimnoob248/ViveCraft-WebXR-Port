package dev.vivewebxr.render;

import dev.vivewebxr.WebXRConfig;
import dev.vivewebxr.WebXRMod;
import dev.vivewebxr.server.WebXRServer;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL12;
import org.lwjgl.opengl.GL15;
import org.lwjgl.opengl.GL21;
import org.lwjgl.opengl.GL30;
import org.lwjgl.opengl.GL32;

import javax.imageio.IIOImage;
import javax.imageio.ImageIO;
import javax.imageio.ImageWriteParam;
import javax.imageio.ImageWriter;
import javax.imageio.stream.MemoryCacheImageOutputStream;
import java.awt.image.BufferedImage;
import java.awt.image.DataBufferInt;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Copies the finished left-eye picture from the GPU, turns it into a JPEG on background threads and hands it to
 * the web server.
 *
 * GPU part (render thread): blit (flipped, 1:1 normally) into a renderbuffer, then glReadPixels into one of three
 * pixel-buffer-objects. A GPU fence tells us when a PBO is ready, so the render thread never waits for the GPU.
 * Every frame we pick up the NEWEST finished PBO (older ones are dropped) and give it to an encoder thread.
 *
 * Wire format of one video message (WebSocket binary, big endian):
 *   int  frameId   increasing; the browser ignores anything older than what it already shows
 *   int  poseSeq   sequence number of the head pose Minecraft used to render this frame (browser reprojection)
 *   float tanX     half-width  of the picture as tan(half FOV)   } the exact frustum Minecraft rendered with
 *   float tanY     half-height of the picture as tan(half FOV)   }
 *   ...  JPEG
 */
public final class FrameGrabber {
    public static final FrameGrabber INSTANCE = new FrameGrabber();

    public static final int HEADER_BYTES = 16;
    private static final int SLOTS = 3;

    private WebXRServer server;
    private boolean broken;

    // ---- GPU objects (render thread only)
    private int srcFbo, dstFbo, dstRb;
    private final int[] pbo = new int[SLOTS];
    private final long[] fence = new long[SLOTS];
    private final int[] slotFrameId = new int[SLOTS];
    private final int[] slotPoseSeq = new int[SLOTS];
    private final float[] slotTanX = new float[SLOTS];
    private final float[] slotTanY = new float[SLOTS];
    private int outW, outH;
    private int head;   // oldest pending slot
    private int count;  // number of pending slots

    // ---- pacing / adaptive quality (render thread only)
    private long nextDueNanos;
    private int nextFrameId = 1;
    private float quality = -1;
    private long lastAdaptNanos;
    private long calmSinceNanos;

    // ---- encoder side
    private ExecutorService encoders;
    private int encoderCount;
    private final AtomicInteger inFlight = new AtomicInteger();
    private volatile ImagePool pool;

    private static final ThreadLocal<ImageWriter> WRITER =
            ThreadLocal.withInitial(() -> ImageIO.getImageWritersByFormatName("jpeg").next());

    private FrameGrabber() {}

    public void setServer(WebXRServer s) {
        this.server = s;
    }

    // ================================================================== render thread API

    /** Call on the render thread at the start of a frame: hands any finished picture to the encoders. */
    public void pump() {
        if (broken || srcFbo == 0) return;
        try {
            pickUpFinished();
        } catch (Throwable t) {
            fail(t);
        }
    }

    /**
     * Call on the render thread, once per VR frame, after the eye texture is complete.
     *
     * @param poseSeq pose sequence number that was used to render this frame (0 = unknown)
     * @param tanX    tan of the half horizontal FOV Minecraft rendered with
     * @param tanY    tan of the half vertical FOV Minecraft rendered with
     */
    public void capture(int eyeTexture, int srcW, int srcH, int poseSeq, float tanX, float tanY) {
        if (broken || server == null || eyeTexture <= 0 || srcW <= 0 || srcH <= 0) return;
        try {
            pickUpFinished();

            if (!server.wantsFrames()) {
                dropPending();
                return;
            }

            long now = System.nanoTime();
            adaptQuality(now);

            if (now < nextDueNanos) return;
            if (count >= SLOTS) return;                         // the GPU has not finished the earlier copies
            if (inFlight.get() >= encoderCount()) return;       // encoders are busy -> skip this frame

            long interval = 1_000_000_000L / Math.max(1, WebXRConfig.streamFps);
            // Accumulate instead of "now + interval" so e.g. 90 game-fps with a 60 fps limit still averages 60.
            nextDueNanos = (now - nextDueNanos > interval) ? now + interval : nextDueNanos + interval;

            grab(eyeTexture, srcW, srcH, poseSeq, tanX, tanY);
        } catch (Throwable t) {
            fail(t);
        }
    }

    /** Called when the VR renderer is torn down (GL objects are tied to the context). */
    public void release() {
        try {
            destroyTargets();
        } catch (Throwable ignored) {
        }
        outW = outH = 0;
    }

    private void fail(Throwable t) {
        broken = true;
        WebXRMod.LOGGER.error("WebXR: frame capture failed, streaming disabled", t);
    }

    // ================================================================== GPU side

    private void grab(int eyeTexture, int srcW, int srcH, int poseSeq, float tanX, float tanY) {
        int w = srcW, h = srcH;
        int cap = WebXRConfig.streamWidth;
        if (w > cap) { // only when the eye texture is bigger than the configured stream width
            h = Math.round(h * (cap / (float) w));
            w = cap;
        }
        w &= ~1;
        h &= ~1;
        if (w < 2 || h < 2) return;
        if (w != outW || h != outH || srcFbo == 0) createTargets(w, h);

        // ---- save the GL state we touch
        int prevRead = GL11.glGetInteger(GL30.GL_READ_FRAMEBUFFER_BINDING);
        int prevDraw = GL11.glGetInteger(GL30.GL_DRAW_FRAMEBUFFER_BINDING);
        int prevPack = GL11.glGetInteger(GL21.GL_PIXEL_PACK_BUFFER_BINDING);
        int prevPackAlign = GL11.glGetInteger(GL11.GL_PACK_ALIGNMENT);
        try {
            // copy + vertical flip (GL images are bottom-up, JPEG is top-down); scales only if w/h differ
            GL30.glBindFramebuffer(GL30.GL_READ_FRAMEBUFFER, srcFbo);
            GL30.glFramebufferTexture2D(GL30.GL_READ_FRAMEBUFFER, GL30.GL_COLOR_ATTACHMENT0, GL11.GL_TEXTURE_2D, eyeTexture, 0);
            GL30.glBindFramebuffer(GL30.GL_DRAW_FRAMEBUFFER, dstFbo);
            GL30.glBlitFramebuffer(0, 0, srcW, srcH, 0, outH, outW, 0, GL11.GL_COLOR_BUFFER_BIT, GL11.GL_LINEAR);

            // start an async read of the image. BGRA + 8_8_8_8_REV = every pixel is exactly a Java 0xAARRGGBB int.
            int slot = (head + count) % SLOTS;
            GL30.glBindFramebuffer(GL30.GL_READ_FRAMEBUFFER, dstFbo);
            GL11.glPixelStorei(GL11.GL_PACK_ALIGNMENT, 4);
            GL15.glBindBuffer(GL21.GL_PIXEL_PACK_BUFFER, pbo[slot]);
            GL11.glReadPixels(0, 0, outW, outH, GL12.GL_BGRA, GL12.GL_UNSIGNED_INT_8_8_8_8_REV, 0L);

            fence[slot] = GL32.glFenceSync(GL32.GL_SYNC_GPU_COMMANDS_COMPLETE, 0);
            GL11.glFlush(); // make sure the fence is really sent to the GPU
            slotFrameId[slot] = nextFrameId++;
            slotPoseSeq[slot] = poseSeq;
            slotTanX[slot] = tanX;
            slotTanY[slot] = tanY;
            count++;
        } finally {
            GL15.glBindBuffer(GL21.GL_PIXEL_PACK_BUFFER, prevPack);
            GL11.glPixelStorei(GL11.GL_PACK_ALIGNMENT, prevPackAlign);
            GL30.glBindFramebuffer(GL30.GL_READ_FRAMEBUFFER, prevRead);
            GL30.glBindFramebuffer(GL30.GL_DRAW_FRAMEBUFFER, prevDraw);
        }
    }

    /** Finds the NEWEST finished copy, sends it to an encoder, and forgets the older ones. */
    private void pickUpFinished() {
        if (count == 0) return;

        int newest = -1; // offset from head
        for (int i = 0; i < count; i++) {
            if (!isSignaled(fence[(head + i) % SLOTS])) break; // fences complete in order
            newest = i;
        }
        if (newest < 0) return;

        ImagePool p = pool;
        if (p == null) return;
        BufferedImage img = p.lease();
        if (img == null) return; // all images are being encoded -> try again next call

        int slot = (head + newest) % SLOTS;
        int prevPack = GL11.glGetInteger(GL21.GL_PIXEL_PACK_BUFFER_BINDING);
        try {
            GL15.glBindBuffer(GL21.GL_PIXEL_PACK_BUFFER, pbo[slot]);
            ByteBuffer mapped = GL30.glMapBufferRange(GL21.GL_PIXEL_PACK_BUFFER, 0, (long) outW * outH * 4, GL30.GL_MAP_READ_BIT);
            if (mapped == null) {
                p.give(img);
            } else {
                int[] px = ((DataBufferInt) img.getRaster().getDataBuffer()).getData();
                mapped.order(ByteOrder.nativeOrder()).asIntBuffer().get(px, 0, outW * outH);
                GL15.glUnmapBuffer(GL21.GL_PIXEL_PACK_BUFFER);
                submit(p, img, slotFrameId[slot], slotPoseSeq[slot], slotTanX[slot], slotTanY[slot]);
            }
        } finally {
            GL15.glBindBuffer(GL21.GL_PIXEL_PACK_BUFFER, prevPack);
        }

        for (int i = 0; i <= newest; i++) {
            int s = (head + i) % SLOTS;
            deleteFence(s);
        }
        head = (head + newest + 1) % SLOTS;
        count -= newest + 1;
    }

    private void dropPending() {
        for (int i = 0; i < count; i++) deleteFence((head + i) % SLOTS);
        head = 0;
        count = 0;
    }

    private static boolean isSignaled(long sync) {
        if (sync == 0L) return true;
        int r = GL32.glClientWaitSync(sync, 0, 0L); // timeout 0 = never blocks
        return r != GL32.GL_TIMEOUT_EXPIRED;        // ALREADY_SIGNALED, CONDITION_SATISFIED or WAIT_FAILED
    }

    private void deleteFence(int slot) {
        if (fence[slot] != 0L) {
            GL32.glDeleteSync(fence[slot]);
            fence[slot] = 0L;
        }
    }

    private void createTargets(int w, int h) {
        int prevRb = GL11.glGetInteger(GL30.GL_RENDERBUFFER_BINDING);
        int prevFbo = GL11.glGetInteger(GL30.GL_DRAW_FRAMEBUFFER_BINDING);
        int prevPack = GL11.glGetInteger(GL21.GL_PIXEL_PACK_BUFFER_BINDING);

        destroyTargets();
        outW = w;
        outH = h;

        srcFbo = GL30.glGenFramebuffers();
        dstFbo = GL30.glGenFramebuffers();
        dstRb = GL30.glGenRenderbuffers();
        GL30.glBindRenderbuffer(GL30.GL_RENDERBUFFER, dstRb);
        GL30.glRenderbufferStorage(GL30.GL_RENDERBUFFER, GL11.GL_RGBA8, w, h);
        GL30.glBindFramebuffer(GL30.GL_DRAW_FRAMEBUFFER, dstFbo);
        GL30.glFramebufferRenderbuffer(GL30.GL_DRAW_FRAMEBUFFER, GL30.GL_COLOR_ATTACHMENT0, GL30.GL_RENDERBUFFER, dstRb);

        for (int i = 0; i < SLOTS; i++) {
            pbo[i] = GL15.glGenBuffers();
            GL15.glBindBuffer(GL21.GL_PIXEL_PACK_BUFFER, pbo[i]);
            GL15.glBufferData(GL21.GL_PIXEL_PACK_BUFFER, (long) w * h * 4, GL15.GL_STREAM_READ);
        }

        pool = new ImagePool(w, h, encoderCount() + 1);

        GL15.glBindBuffer(GL21.GL_PIXEL_PACK_BUFFER, prevPack);
        GL30.glBindFramebuffer(GL30.GL_DRAW_FRAMEBUFFER, prevFbo);
        GL30.glBindRenderbuffer(GL30.GL_RENDERBUFFER, prevRb);
        WebXRMod.LOGGER.info("WebXR: streaming {}x{} JPEG at up to {} fps ({} encoder threads)",
                w, h, WebXRConfig.streamFps, encoderCount());
    }

    private void destroyTargets() {
        dropPending();
        if (srcFbo != 0) GL30.glDeleteFramebuffers(srcFbo);
        if (dstFbo != 0) GL30.glDeleteFramebuffers(dstFbo);
        if (dstRb != 0) GL30.glDeleteRenderbuffers(dstRb);
        for (int i = 0; i < SLOTS; i++) {
            if (pbo[i] != 0) GL15.glDeleteBuffers(pbo[i]);
            pbo[i] = 0;
        }
        srcFbo = dstFbo = dstRb = 0;
        pool = null;
    }

    // ================================================================== adaptive quality

    /** Every half second: if the network dropped frames, lower the JPEG quality; if it is calm, raise it again. */
    private void adaptQuality(long now) {
        if (quality < 0) quality = WebXRConfig.jpegQuality;
        if (now - lastAdaptNanos < 500_000_000L) return;
        lastAdaptNanos = now;

        float max = WebXRConfig.jpegQuality;
        float min = Math.min(max, WebXRConfig.jpegQualityMin);
        int dropped = server.takeDroppedFrames();
        if (!WebXRConfig.adaptiveQuality) {
            quality = max;
        } else if (dropped >= 2) {
            quality = Math.max(min, quality - 0.05f);
            calmSinceNanos = now;
        } else if (dropped == 0 && now - calmSinceNanos > 2_000_000_000L) {
            quality = Math.min(max, quality + 0.02f);
            calmSinceNanos = now;
        }
    }

    // ================================================================== encoder threads

    private int encoderCount() {
        if (encoders == null) {
            encoderCount = Math.max(1, Math.min(6, WebXRConfig.encoderThreads));
            encoders = Executors.newFixedThreadPool(encoderCount, r -> {
                Thread t = new Thread(r, "WebXR-jpeg");
                t.setDaemon(true);
                return t;
            });
        }
        return encoderCount;
    }

    private void submit(ImagePool p, BufferedImage img, int frameId, int poseSeq, float tanX, float tanY) {
        final float q = quality < 0 ? WebXRConfig.jpegQuality : quality;
        inFlight.incrementAndGet();
        encoders.execute(() -> {
            try {
                byte[] message = encode(img, frameId, poseSeq, tanX, tanY, q);
                WebXRServer s = server;
                if (s != null) s.broadcastFrame(message, frameId);
            } catch (Throwable t) {
                WebXRMod.LOGGER.warn("WebXR: JPEG encode failed: {}", t.toString());
            } finally {
                p.give(img);
                inFlight.decrementAndGet();
            }
        });
    }

    private static byte[] encode(BufferedImage img, int frameId, int poseSeq, float tanX, float tanY, float quality)
            throws IOException {
        ImageWriter writer = WRITER.get();
        ImageWriteParam param = writer.getDefaultWriteParam();
        param.setCompressionMode(ImageWriteParam.MODE_EXPLICIT);
        param.setCompressionQuality(quality);

        ByteArrayOutputStream bos = new ByteArrayOutputStream(img.getWidth() * img.getHeight() / 4 + 1024);
        bos.write(new byte[HEADER_BYTES]); // header is filled in below
        // NOT ImageIO.createImageOutputStream(): that may use a temp file on disk for every single frame.
        try (MemoryCacheImageOutputStream ios = new MemoryCacheImageOutputStream(bos)) {
            writer.setOutput(ios);
            writer.write(null, new IIOImage(img, null, null), param);
            ios.flush();
        } finally {
            writer.reset();
        }
        byte[] message = bos.toByteArray();
        ByteBuffer.wrap(message).putInt(0, frameId).putInt(4, poseSeq).putFloat(8, tanX).putFloat(12, tanY);
        return message;
    }

    /** A small set of reusable pictures, so the 60 fps stream does not create 14 MB of garbage per frame. */
    private static final class ImagePool {
        final int w, h, max;
        final ArrayBlockingQueue<BufferedImage> free;
        final AtomicInteger created = new AtomicInteger();

        ImagePool(int w, int h, int max) {
            this.w = w;
            this.h = h;
            this.max = max;
            this.free = new ArrayBlockingQueue<>(max);
        }

        BufferedImage lease() {
            BufferedImage img = free.poll();
            if (img != null) return img;
            if (created.get() < max && created.incrementAndGet() <= max) {
                return new BufferedImage(w, h, BufferedImage.TYPE_INT_RGB);
            }
            return null;
        }

        void give(BufferedImage img) {
            free.offer(img); // if this pool was replaced (resolution change) nobody leases from it any more
        }
    }
}
