'use strict';
/* Vivecraft WebXR client.
 *  - WebSocket to the PC:   receives JPEG frames (binary) and haptic commands (text),
 *                           sends head/controller poses ({"t":"p",...}), the headset field of view ({"t":"v",...})
 *                           and session start/stop ({"t":"s","vr":bool}).
 *  - WebXR "immersive-vr":  shows the latest JPEG on a screen that is
 *      * exactly as big (in degrees) as the picture Minecraft rendered, so it fills the headset: no black borders,
 *      * WORLD-LOCKED in rotation, using the head pose the frame was rendered from ("reprojection"). When you turn
 *        your head the picture stays put until the next frame arrives, instead of swimming with your head.
 *        That hides most of the network latency for head movement.
 *
 * Binary message from the PC (big endian):
 *   u32 frameId, u32 poseSeq, f32 tanX, f32 tanY, then the JPEG.
 */
const $ = (id) => document.getElementById(id);
const params = new URLSearchParams(location.search);
/** Distance of the (mono) picture in metres. Only changes how your eyes converge; the angular size is automatic. */
const SCREEN_DIST = clampNum(parseFloat(params.get('d')), 1, 20, 4);
/** Extra field of view rendered around what the headset can show (room for head movement). 1.08 = 8 %. */
const MARGIN = clampNum(parseFloat(params.get('m')), 1.0, 1.5, 1.08);
/** The screen is drawn this much bigger than the picture; the outside repeats the edge pixels instead of black. */
const EXTEND = 1.6;
const HEADER = 16;

function clampNum(v, lo, hi, def) { return Number.isFinite(v) ? Math.min(hi, Math.max(lo, v)) : def; }
const r4 = (v) => Math.round(v * 10000) / 10000;

// ------------------------------------------------------------------ state
let ws = null, wsOpen = false;
let session = null, refSpace = null, gl = null, glLayer = null;
let floorOffset = 0;
let prog = null, vbo = null, tex = null, texW = 0, texH = 0, loc = {};

// video
let nextFrame = null;          // newest received, not yet decoded
let decoding = false;
let readyFrame = null;         // decoded, waiting for the next XR frame: {bitmap, id, seq, tx, ty}
let lastDecodedId = 0;
let shown = null;              // what is on screen: {id, seq, tx, ty}
let bitmapOptionsOk = true;

// pose history for reprojection: poseSeq -> head orientation at that moment
const HIST = 256;
const histSeq = new Int32Array(HIST);
const histQ = new Float32Array(HIST * 4);
let poseSeq = 0;

// field of view
let sentView = { tx: 0, ty: 0 };
let measured = { tx: 1.5, ty: 1.2 };

function setStatus(text) { $('status').textContent = text; }
function showHelp(html) { const h = $('help'); h.innerHTML = html; h.style.display = 'block'; }

// ------------------------------------------------------------------ network
function connect() {
  const proto = location.protocol === 'https:' ? 'wss' : 'ws';
  ws = new WebSocket(proto + '://' + location.host + '/ws');
  ws.binaryType = 'arraybuffer';
  ws.onopen = () => {
    wsOpen = true; lastDecodedId = 0;
    if (!session) setStatus('Connected to Minecraft. Press Enter VR.');
    updateButton();
  };
  ws.onclose = () => {
    wsOpen = false; updateButton();
    if (session) { try { session.end(); } catch (e) {} }
    setStatus('Connection lost. Retrying…');
    setTimeout(connect, 2000);
  };
  ws.onerror = () => {};
  ws.onmessage = onMessage;
}

function onMessage(ev) {
  if (typeof ev.data !== 'string') {
    if (ev.data.byteLength <= HEADER) return;
    const dv = new DataView(ev.data);
    nextFrame = {
      id: dv.getUint32(0), seq: dv.getUint32(4), tx: dv.getFloat32(8), ty: dv.getFloat32(12),
      blob: new Blob([new Uint8Array(ev.data, HEADER)], { type: 'image/jpeg' }),
    };
    if (!decoding) pumpDecode();
    return;
  }
  let m; try { m = JSON.parse(ev.data); } catch (e) { return; }
  if (m.t === 'h') haptic(m.hand, m.d, m.a);
  else if (m.t === 'session' && m.ok === false) {
    setStatus('Another headset is already playing.');
    if (session) session.end();
  }
}

async function decodeBlob(blob) {
  if (bitmapOptionsOk) {
    try { return await createImageBitmap(blob, { premultiplyAlpha: 'none', colorSpaceConversion: 'none' }); }
    catch (e) { bitmapOptionsOk = false; }
  }
  return createImageBitmap(blob);
}

async function pumpDecode() {
  decoding = true;
  while (nextFrame) {
    const f = nextFrame; nextFrame = null;
    try {
      const bm = await decodeBlob(f.blob);
      if (f.id <= lastDecodedId) { bm.close(); continue; }   // an older frame finished late: skip it
      lastDecodedId = f.id;
      if (readyFrame) readyFrame.bitmap.close();             // the previous one was never shown: replace it
      readyFrame = { bitmap: bm, id: f.id, seq: f.seq, tx: f.tx, ty: f.ty };
    } catch (e) { /* bad frame, ignore */ }
  }
  decoding = false;
}

setInterval(() => { if (wsOpen) ws.send('{"t":"k"}'); }, 4000);

function send(obj) { if (wsOpen) ws.send(JSON.stringify(obj)); }

function haptic(hand, durMs, amp) {
  if (!session) return;
  const want = hand === 0 ? 'right' : 'left';
  for (const src of session.inputSources) {
    if (src.handedness !== want || !src.gamepad) continue;
    const gp = src.gamepad;
    try {
      if (gp.hapticActuators && gp.hapticActuators[0] && gp.hapticActuators[0].pulse) gp.hapticActuators[0].pulse(amp, durMs);
      else if (gp.vibrationActuator) gp.vibrationActuator.playEffect('dual-rumble', { duration: durMs, strongMagnitude: amp, weakMagnitude: amp });
    } catch (e) {}
  }
}

// ------------------------------------------------------------------ small math helpers (column-major, like WebXR)
function mul(a, b) {
  const o = new Float32Array(16);
  for (let c = 0; c < 4; c++) for (let r = 0; r < 4; r++) {
    let s = 0; for (let k = 0; k < 4; k++) s += a[k * 4 + r] * b[c * 4 + k];
    o[c * 4 + r] = s;
  }
  return o;
}
// quaternions are [x, y, z, w]
function qmul(a, b) {
  return [
    a[3] * b[0] + a[0] * b[3] + a[1] * b[2] - a[2] * b[1],
    a[3] * b[1] - a[0] * b[2] + a[1] * b[3] + a[2] * b[0],
    a[3] * b[2] + a[0] * b[1] - a[1] * b[0] + a[2] * b[3],
    a[3] * b[3] - a[0] * b[0] - a[1] * b[1] - a[2] * b[2],
  ];
}
function qconj(q) { return [-q[0], -q[1], -q[2], q[3]]; }
function qrot(q, v) { // rotate vector v by unit quaternion q
  const p = qmul(qmul(q, [v[0], v[1], v[2], 0]), qconj(q));
  return [p[0], p[1], p[2]];
}
/** Model matrix of the screen: rotation q, centred `dist` metres in front of (px,py,pz) along q's forward axis. */
function screenModel(q, px, py, pz, dist) {
  const x = q[0], y = q[1], z = q[2], w = q[3];
  const m = new Float32Array(16);
  m[0] = 1 - 2 * (y * y + z * z); m[1] = 2 * (x * y + w * z);     m[2] = 2 * (x * z - w * y);
  m[4] = 2 * (x * y - w * z);     m[5] = 1 - 2 * (x * x + z * z); m[6] = 2 * (y * z + w * x);
  m[8] = 2 * (x * z + w * y);     m[9] = 2 * (y * z - w * x);     m[10] = 1 - 2 * (x * x + y * y);
  m[12] = px - dist * m[8]; m[13] = py - dist * m[9]; m[14] = pz - dist * m[10];
  m[15] = 1;
  return m;
}

// ------------------------------------------------------------------ field of view
/**
 * What the headset can see, as one symmetric frustum around the head: tangents of the half angles.
 * Both eyes' frusta are turned into head space and merged, then a little margin is added.
 */
function measureView(pose) {
  const ho = pose.transform.orientation;
  const hInv = qconj([ho.x, ho.y, ho.z, ho.w]);
  let tx = 0, ty = 0;
  for (const v of pose.views) {
    const P = v.projectionMatrix;
    if (!P || !P[0] || !P[5]) continue;
    const l = (P[8] - 1) / P[0], r = (P[8] + 1) / P[0];
    const b = (P[9] - 1) / P[5], t = (P[9] + 1) / P[5];
    const vo = v.transform.orientation;
    const rel = qmul(hInv, [vo.x, vo.y, vo.z, vo.w]);          // eye orientation relative to the head
    for (const c of [[l, b], [r, b], [l, t], [r, t]]) {
      const d = qrot(rel, [c[0], c[1], -1]);                    // frustum corner direction in head space
      if (d[2] > -0.2) continue;                                // pointing sideways or backwards: ignore
      tx = Math.max(tx, Math.abs(d[0] / d[2]));
      ty = Math.max(ty, Math.abs(d[1] / d[2]));
    }
  }
  if (!(tx > 0.2 && ty > 0.2)) return null;
  let ipd = 0.064;
  if (pose.views.length >= 2) {
    const a = pose.views[0].transform.position, b = pose.views[1].transform.position;
    ipd = Math.hypot(a.x - b.x, a.y - b.y, a.z - b.z) || ipd;
  }
  // the picture is flat and mono: each eye sits ipd/2 beside the centre, which shifts its edge by ipd/2/dist
  return {
    tx: Math.min(3.5, (tx + ipd * 0.5 / SCREEN_DIST) * MARGIN),
    ty: Math.min(3.5, ty * MARGIN),
  };
}

function maybeSendView(pose) {
  const v = measureView(pose);
  if (!v) return;
  measured = v;
  const changed = (a, b) => !(b > 0) || Math.abs(a - b) / b > 0.03;
  if (changed(v.tx, sentView.tx) || changed(v.ty, sentView.ty)) {
    sentView = v;
    send({ t: 'v', tx: r4(v.tx), ty: r4(v.ty) });
  }
}

// ------------------------------------------------------------------ WebGL: one textured quad
const VS = `#version 300 es
in vec2 aPos;
uniform mat4 uMVP;
uniform vec2 uHalf;   // half size of the screen in metres (already including EXTEND)
uniform float uExt;   // EXTEND: the part of the screen outside the picture repeats the edge pixels
out vec2 vUv;
void main() {
  vUv = vec2(aPos.x * uExt * 0.5 + 0.5, 0.5 - aPos.y * uExt * 0.5);
  gl_Position = uMVP * vec4(aPos * uHalf, 0.0, 1.0);
}`;
const FS = `#version 300 es
precision highp float;   // mediump (16 bit) is too coarse for texture coordinates of a 2000+ pixel picture
in vec2 vUv;
uniform sampler2D uTex;
uniform float uHas;
out vec4 o;
void main() {
  vec3 c = texture(uTex, vUv).rgb;
  o = vec4(mix(vec3(0.07, 0.07, 0.12), c, uHas), 1.0);
}`;

function compile(type, src) {
  const s = gl.createShader(type); gl.shaderSource(s, src); gl.compileShader(s);
  if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(s));
  return s;
}

function newTexture() {
  const t = gl.createTexture();
  gl.bindTexture(gl.TEXTURE_2D, t);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
  return t;
}

function initGL() {
  const canvas = document.createElement('canvas');
  gl = canvas.getContext('webgl2', { xrCompatible: true, antialias: false, alpha: false, depth: false, stencil: false });
  if (!gl) throw new Error('WebGL2 is not available');
  prog = gl.createProgram();
  gl.attachShader(prog, compile(gl.VERTEX_SHADER, VS));
  gl.attachShader(prog, compile(gl.FRAGMENT_SHADER, FS));
  gl.linkProgram(prog);
  if (!gl.getProgramParameter(prog, gl.LINK_STATUS)) throw new Error(gl.getProgramInfoLog(prog));
  loc = {
    pos: gl.getAttribLocation(prog, 'aPos'),
    mvp: gl.getUniformLocation(prog, 'uMVP'),
    half: gl.getUniformLocation(prog, 'uHalf'),
    ext: gl.getUniformLocation(prog, 'uExt'),
    tex: gl.getUniformLocation(prog, 'uTex'),
    has: gl.getUniformLocation(prog, 'uHas'),
  };
  vbo = gl.createBuffer();
  gl.bindBuffer(gl.ARRAY_BUFFER, vbo);
  gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 1, -1, -1, 1, 1, 1]), gl.STATIC_DRAW);
  tex = newTexture();
  gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, 1, 1, 0, gl.RGBA, gl.UNSIGNED_BYTE, new Uint8Array([18, 18, 30, 255]));
  texW = texH = 0;
}

/** Puts a decoded picture into the texture. The texture storage is allocated once per picture size. */
function uploadFrame(f) {
  const bm = f.bitmap;
  if (bm.width !== texW || bm.height !== texH) {
    if (tex) gl.deleteTexture(tex);
    tex = newTexture();
    gl.texStorage2D(gl.TEXTURE_2D, 1, gl.RGBA8, bm.width, bm.height);
    texW = bm.width; texH = bm.height;
  } else {
    gl.bindTexture(gl.TEXTURE_2D, tex);
  }
  gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, false);
  gl.pixelStorei(gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL, false);
  gl.texSubImage2D(gl.TEXTURE_2D, 0, 0, 0, gl.RGBA, gl.UNSIGNED_BYTE, bm);
  bm.close();
  f.bitmap = null;
  shown = { id: f.id, seq: f.seq, tx: f.tx, ty: f.ty };
}

// ------------------------------------------------------------------ VR session
async function enterVR() {
  if (!navigator.xr) {
    showHelp('<b>WebXR is not available here.</b><br>Browsers only allow WebXR on secure pages. ' +
      'Open the <code>https://</code> address shown on the PC (accept the certificate warning), ' +
      'or use <code>http://localhost</code> via <code>adb reverse</code>.');
    return;
  }
  if (!(await navigator.xr.isSessionSupported('immersive-vr'))) {
    showHelp('This browser/device does not support immersive VR.');
    return;
  }
  try {
    if (!gl) initGL();
    try {
      session = await navigator.xr.requestSession('immersive-vr', { requiredFeatures: ['local-floor'] });
      refSpace = await session.requestReferenceSpace('local-floor'); floorOffset = 0;
    } catch (e) {
      session = await navigator.xr.requestSession('immersive-vr', { optionalFeatures: ['local'] });
      refSpace = await session.requestReferenceSpace('local'); floorOffset = 1.6; // assume standing eye height
    }
    await gl.makeXRCompatible();

    // Full native resolution (the default is noticeably lower), no foveation blur in the picture's edges.
    let fbScale = 1;
    try { fbScale = Math.max(1, Math.min(2, XRWebGLLayer.getNativeFramebufferScaleFactor(session))); } catch (e) {}
    glLayer = new XRWebGLLayer(session, gl, {
      antialias: false, depth: false, stencil: false, alpha: false, framebufferScaleFactor: fbScale,
    });
    try { glLayer.fixedFoveation = 0; } catch (e) {}
    session.updateRenderState({ baseLayer: glLayer });
    session.addEventListener('end', onSessionEnd);

    // Highest refresh rate the headset offers: more head-tracking updates, smoother reprojection.
    try {
      if (session.supportedFrameRates && session.updateTargetFrameRate) {
        await session.updateTargetFrameRate(Math.max(...Array.from(session.supportedFrameRates)));
      }
    } catch (e) {}

    sentView = { tx: 0, ty: 0 };
    readyFrame = null; shown = null;
    send({ t: 's', vr: true });
    setStatus('In VR.');
    $('enter').disabled = true;
    session.requestAnimationFrame(onXRFrame);
  } catch (e) {
    session = null;
    showHelp('Could not start VR: ' + (e && e.message ? e.message : e));
  }
}

function onSessionEnd() {
  send({ t: 's', vr: false });
  session = null; refSpace = null; glLayer = null; shown = null;
  if (readyFrame) { readyFrame.bitmap.close(); readyFrame = null; }
  setStatus(wsOpen ? 'Connected to Minecraft. Press Enter VR.' : 'Connection lost. Retrying…');
  updateButton();
}

function onXRFrame(time, frame) {
  if (!session) return;
  session.requestAnimationFrame(onXRFrame);
  const pose = frame.getViewerPose(refSpace);
  if (!pose) return;
  maybeSendView(pose);
  sendPose(frame, pose);

  if (readyFrame) { const f = readyFrame; readyFrame = null; uploadFrame(f); }

  gl.bindFramebuffer(gl.FRAMEBUFFER, glLayer.framebuffer);
  gl.clearColor(0, 0, 0, 1);
  gl.clear(gl.COLOR_BUFFER_BIT);
  gl.disable(gl.DEPTH_TEST);
  gl.useProgram(prog);
  gl.bindBuffer(gl.ARRAY_BUFFER, vbo);
  gl.enableVertexAttribArray(loc.pos);
  gl.vertexAttribPointer(loc.pos, 2, gl.FLOAT, false, 0, 0);
  gl.activeTexture(gl.TEXTURE0);
  gl.bindTexture(gl.TEXTURE_2D, tex);
  gl.uniform1i(loc.tex, 0);
  gl.uniform1f(loc.has, shown ? 1 : 0);
  gl.uniform1f(loc.ext, EXTEND);

  // Where and how big is the screen?
  //  * size:     exactly the field of view Minecraft rendered (from the frame itself, or our own measurement)
  //  * rotation: the head rotation Minecraft rendered from (world-locked); falls back to "stuck to the head"
  //  * position: always centred on the head, so leaning does not move the picture
  const head = pose.transform;
  const ho = head.orientation, hp = head.position;
  let q = [ho.x, ho.y, ho.z, ho.w];
  let tx = measured.tx, ty = measured.ty;
  if (shown) {
    tx = shown.tx; ty = shown.ty;
    const o = lookupPose(shown.seq);
    if (o) q = o;
  }
  gl.uniform2f(loc.half, tx * SCREEN_DIST * EXTEND, ty * SCREEN_DIST * EXTEND);
  const model = screenModel(q, hp.x, hp.y, hp.z, SCREEN_DIST);

  for (const view of pose.views) {
    const vp = glLayer.getViewport(view);
    gl.viewport(vp.x, vp.y, vp.width, vp.height);
    const mvp = mul(view.projectionMatrix, mul(view.transform.inverse.matrix, model));
    gl.uniformMatrix4fv(loc.mvp, false, mvp);
    gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
  }
}

// ------------------------------------------------------------------ tracking -> PC
function packPose(t) {
  return [r4(t.position.x), r4(t.position.y + floorOffset), r4(t.position.z),
          r4(t.orientation.x), r4(t.orientation.y), r4(t.orientation.z), r4(t.orientation.w)];
}

function rememberPose(seq, h) {
  const i = seq & (HIST - 1);
  histSeq[i] = seq;
  histQ[i * 4] = h[3]; histQ[i * 4 + 1] = h[4]; histQ[i * 4 + 2] = h[5]; histQ[i * 4 + 3] = h[6];
}

function lookupPose(seq) {
  if (!seq) return null;
  const i = seq & (HIST - 1);
  if (histSeq[i] !== seq) return null;   // too old (or never sent)
  const x = histQ[i * 4], y = histQ[i * 4 + 1], z = histQ[i * 4 + 2], w = histQ[i * 4 + 3];
  const n = Math.hypot(x, y, z, w) || 1;
  return [x / n, y / n, z / n, w / n];
}

function sendPose(frame, viewerPose) {
  if (!wsOpen || ws.bufferedAmount > 200000) return;
  const seq = ++poseSeq;
  const msg = { t: 'p', n: seq, h: packPose(viewerPose.transform) };
  rememberPose(seq, msg.h);
  if (viewerPose.views.length >= 2) {
    const a = viewerPose.views[0].transform.position, b = viewerPose.views[1].transform.position;
    msg.i = r4(Math.hypot(a.x - b.x, a.y - b.y, a.z - b.z));
  }
  for (const src of session.inputSources) {
    const space = src.gripSpace || src.targetRaySpace;
    if (!space) continue;
    const p = frame.getPose(space, refSpace);
    if (!p) continue;
    const hand = { p: packPose(p.transform), b: [], a: [] };
    if (src.gamepad) {
      hand.b = src.gamepad.buttons.slice(0, 6).map((b) => Math.round(b.value * 100) / 100);
      hand.a = src.gamepad.axes.map((v) => Math.round(v * 100) / 100);
    }
    if (src.profiles && src.profiles.length) msg.pr = src.profiles[0];
    if (src.handedness === 'right') msg.r = hand;
    else if (src.handedness === 'left') msg.l = hand;
  }
  ws.send(JSON.stringify(msg));
}

// ------------------------------------------------------------------ page
function updateButton() { $('enter').disabled = !(wsOpen && !session); }
$('enter').addEventListener('click', enterVR);

if (!navigator.xr) {
  setStatus('WebXR is not available in this page.');
  showHelp('Browsers only allow WebXR on <b>secure</b> pages. Open the <code>https://</code> address shown on the PC ' +
    'and accept the certificate warning (Advanced → continue).');
}
connect();
