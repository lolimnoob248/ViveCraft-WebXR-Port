# Vivecraft WebXR Bridge  (Fabric, Minecraft 1.21.11)

Play Vivecraft **wirelessly from a headset browser** (Quest Browser, Pico Browser, Chrome with a headset...).
Think "wireless PCVR", but the headset side is just a web page.

* The PC runs Minecraft + Vivecraft + this mod. The mod starts a small web server.
* The headset opens the page and presses **Enter VR**.
* The headset's head + controller movement is sent to Minecraft (Vivecraft uses it like a real VR device).
* The game picture (left eye) is streamed back as JPEG and shown on a **flat screen locked in front of your face**.
* On the PC screen you see the **address to open** until a headset is really in VR. Then you see the normal VR mirror.

## Why a separate mod and not a changed Vivecraft jar?
A `.jar` only contains compiled code (no source), so it cannot be edited safely. This mod is an **add-on**
that plugs into Vivecraft with Mixins. It adds a new VR device called `webxr` (built on Vivecraft's own NullVR,
so it never crashes when no headset/SteamVR exists). **You still need the normal Vivecraft jar in your mods folder.**

## Build (makes the .jar)
1. Install **JDK 21** and **Gradle 9.x** (or open the folder in IntelliJ IDEA and let it import the Gradle project).
2. In this folder run:  `gradle wrapper`  (once), then  `./gradlew build`   (Windows: `gradlew build`)
3. Your mod is `build/libs/vivecraft-webxr-1.1.0.jar`.

(`libs/vivecraft-1_21_11-1_3_15-fabric.jar` is only used to compile against. It is not packed into your mod.)

## Install
`mods/` folder needs:  Fabric Loader (1.21.11) + **Vivecraft** jar + **vivecraft-webxr-1.1.0.jar**.   (Fabric API is not required.)

## Use
1. Start Minecraft. The PC shows a green panel with addresses, e.g. `https://192.168.1.23:8443`.
2. Put the headset on the **same Wi-Fi** (5 GHz / Wi-Fi 6 is best).
3. In the headset browser open the **https** address. First time: *Advanced -> Continue* (self-signed certificate).
4. Press **Enter VR**. The PC switches to VR mode by itself. Take the headset off / exit VR -> PC goes back to normal.

WebXR only works on secure pages, so use **https**. Alternative without the warning: connect the headset by USB and run
`adb reverse tcp:8080 tcp:8080`, then open `http://localhost:8080` in the headset.
Windows Firewall: allow Java on private networks when asked (ports 8080/8443).

## Controls (Vivecraft's default Oculus Touch layout)
| Button | In the world | In menus |
|---|---|---|
| Right trigger | Attack / break | Left click |
| Right A | Use / place | Right click |
| Right B | Radial menu | |
| Right grip | Next hotbar slot | Middle click |
| Left grip | Previous hotbar slot | Shift |
| Left trigger | Teleport (if enabled) | |
| Left stick | Walk | |
| Right stick | Turn | |
| Left stick click / Right stick click | Jump / Sneak | |
| Left X / Left Y | Inventory / Menu | Inventory / Menu |

## Settings: `.minecraft/config/vivecraft-webxr.properties` (restart the game after changing)
`httpPort`, `httpsPort`, `streamWidth` (default 1280), `streamFps` (default 36), `jpegQuality`, `forceVR`, `enabled`.
Page options: `https://IP:8443/?d=4&m=1.08` = picture distance in metres, extra field-of-view margin.
New in 1.1.0: `jpegQualityMin`, `adaptiveQuality`, `encoderThreads`, `startDelayFrames`, `skipRightEye` (experimental, roughly doubles game fps).
Old config files get the new sharper picture defaults once (2048 px, 60 fps, quality 0.85).

## Honest notes
* **Untested in a real game.** This was written without Minecraft or a headset available. The web server, WebSocket
  protocol, HTTPS, and pose/button parsing were tested for real; all calls into Vivecraft were type-checked against
  your jar. The Minecraft-specific lines (`Overlay.java`, the 3 Minecraft mixins) use Mojang names from memory.
  If the build fails, the error will point at one of those few lines - the fix is usually a one-word rename.
* The picture is a flat screen with network delay (~50-100 ms). Head-turning feels laggy compared with real PCVR.
* Only the **left eye** is streamed (flat 2D picture, no stereo depth).
* Streaming needs the OpenGL graphics backend (the default).
* The built-in HTTPS certificate is the same for everyone. Use this on a **trusted home network only**, or set
  `keystorePath` to your own `.p12` file.
* Not mapped yet: menu scrolling with the stick, hotbar swipe, quick-commands, full-body trackers.
