package dev.vivewebxr.render;

import dev.vivewebxr.WebXRConfig;
import dev.vivewebxr.WebXRMod;
import dev.vivewebxr.server.WebXRServer;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL12;
import org.lwjgl.opengl.GL15;
import org.lwjgl.opengl.GL21;
import org.lwjgl.opengl.GL30;
import org.lwjgl.opengl.GL32;

import javax.imageio.IIOImage;
import javax.imageio.ImageIO;
import javax.imageio.ImageWriteParam;
import javax.imageio.ImageWriter;
import javax.imageio.stream.ImageOutputStream;
import java.awt.image.BufferedImage;
import java.awt.image.DataBufferByte;
import java.io.ByteArrayOutputStream;
import java.nio.ByteBuffer;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Copies the finished left-eye picture from the GPU, shrinks it, turns it into a JPEG on background
 * threads and hands it to the web server.
 *
 * Latency design (the picture should be on its way to the headset in the SAME frame it was drawn):
 *  - GPU part (render thread): blit (scaled + flipped) into a small renderbuffer, glReadPixels into a
 *    pixel-buffer-object (asynchronous), then wait on a GPU fence for at most ~2 ms. Normally the copy is
 *    done by then, so the frame is picked up immediately. If the GPU is slower, the frame is picked up on a
 *    later call instead (a ring of PBOs), and never blocks the render thread for longer than that.
 *  - Pixels are read as BGR, which is exactly the memory layout of a TYPE_3BYTE_BGR image, so there is no
 *    per-pixel conversion loop: the bytes go straight into the image that the JPEG encoder reads.
 *  - Two encoder threads work in parallel. Every frame has a sequence number; the network layer only ever
 *    sends the newest one, so a slow encode can never make the picture show older frames after newer ones.
 */
public final class FrameGrabber {
    public static final FrameGrabber INSTANCE = new FrameGrabber();

    private static final int RING = 3;
    private static final int ENCODERS = 2;
    /** How long the render thread may wait for the GPU copy of the frame it just drew. */
    private static final long SAME_FRAME_WAIT_NANOS = 2_000_000L;

    private WebXRServer server;
    private boolean broken;
    private volatile boolean loggedFirst;

    private int srcFbo, dstFbo, dstRb;
    private final int[] pbo = new int[RING];
    private final long[] fence = new long[RING];     // 0 = slot free
    private final long[] slotSeq = new long[RING];
    private int outW, outH;
    private long lastCaptureNanos;
    private long seq;

    /** One reusable image (and its pixel array) per frame in flight. */
    private static final class Job {
        final BufferedImage img;
        final byte[] px;
        final int w, h;
        long seq;

        Job(int w, int h) {
            this.w = w;
            this.h = h;
            this.img = new BufferedImage(w, h, BufferedImage.TYPE_3BYTE_BGR);
            this.px = ((DataBufferByte) img.getRaster().getDataBuffer()).getData();
        }
    }

    private final ConcurrentLinkedQueue<Job> jobPool = new ConcurrentLinkedQueue<>();
    private final AtomicInteger inFlight = new AtomicInteger();
    private final ExecutorService encoders = Executors.newFixedThreadPool(ENCODERS, r -> {
        Thread t = new Thread(r, "WebXR-jpeg");
        t.setDaemon(true);
        return t;
    });
    /** ImageWriter is not thread-safe, so every encoder thread gets its own. */
    private final ThreadLocal<ImageWriter> writers =
            ThreadLocal.withInitial(() -> ImageIO.getImageWritersByFormatName("jpeg").next());

    private FrameGrabber() {}

    public void setServer(WebXRServer s) {
        this.server = s;
    }

    /** Call on the render thread, once per VR frame, after the eye texture is complete. */
    public void capture(int eyeTexture, int srcW, int srcH) {
        if (broken || server == null || eyeTexture == 0 || srcW <= 0 || srcH <= 0) return;
        if (!server.wantsFrames()) {
            dropPending();
            return;
        }
        long now = System.nanoTime();
        // 10% slack so that timing jitter does not skip a frame when the game runs at exactly the stream rate
        long minInterval = (long) (1_000_000_000L / (double) Math.max(1, WebXRConfig.streamFps) * 0.9);
        if (now - lastCaptureNanos < minInterval) return;

        try {
            grab(eyeTexture, srcW, srcH, now);
        } catch (Throwable t) {
            broken = true;
            WebXRMod.LOGGER.error("WebXR: frame capture failed, streaming disabled", t);
        }
    }

    private void grab(int eyeTexture, int srcW, int srcH, long now) {
        // streamWidth 0 (default) = native size: every rendered pixel is streamed, nothing is rescaled.
        boolean native_ = WebXRConfig.streamWidth <= 0 || WebXRConfig.streamWidth >= srcW;
        int w = (native_ ? srcW : WebXRConfig.streamWidth) & ~1;
        int h = native_ ? (srcH & ~1) : Math.max(2, Math.round(w * (srcH / (float) srcW))) & ~1;
        if (native_) { // JPEG wants even sizes: crop at most 1 pixel instead of scaling
            srcW = w;
            srcH = h;
        }
        final int filter = native_ ? GL11.GL_NEAREST : GL11.GL_LINEAR;
        if (w != outW || h != outH || srcFbo == 0) createTargets(w, h);

        // ---- save the GL state we touch
        int prevRead = GL11.glGetInteger(GL30.GL_READ_FRAMEBUFFER_BINDING);
        int prevDraw = GL11.glGetInteger(GL30.GL_DRAW_FRAMEBUFFER_BINDING);
        int prevPack = GL11.glGetInteger(GL21.GL_PIXEL_PACK_BUFFER_BINDING);
        int prevPackAlign = GL11.glGetInteger(GL11.GL_PACK_ALIGNMENT);
        boolean scissor = GL11.glIsEnabled(GL11.GL_SCISSOR_TEST); // an active scissor would clip (blank) the copy
        if (scissor) GL11.glDisable(GL11.GL_SCISSOR_TEST);
        try {
            // frames from earlier calls whose GPU copy has finished meanwhile (no waiting)
            collectReady();

            int slot = freeSlot();
            if (slot < 0) return; // the GPU is far behind: skip this frame instead of stalling the game
            if (inFlight.get() >= ENCODERS) return; // both encoders are busy: skip (newest frame wins later)
            lastCaptureNanos = now;

            // scale + vertical flip (GL images are bottom-up, JPEG is top-down)
            GL30.glBindFramebuffer(GL30.GL_READ_FRAMEBUFFER, srcFbo);
            GL30.glFramebufferTexture2D(GL30.GL_READ_FRAMEBUFFER, GL30.GL_COLOR_ATTACHMENT0, GL11.GL_TEXTURE_2D, eyeTexture, 0);
            GL30.glBindFramebuffer(GL30.GL_DRAW_FRAMEBUFFER, dstFbo);
            GL30.glBlitFramebuffer(0, 0, srcW, srcH, 0, outH, outW, 0, GL11.GL_COLOR_BUFFER_BIT, filter);

            // start an async read of the small image (BGR = layout of TYPE_3BYTE_BGR, no conversion later)
            GL30.glBindFramebuffer(GL30.GL_READ_FRAMEBUFFER, dstFbo);
            GL11.glPixelStorei(GL11.GL_PACK_ALIGNMENT, 1);
            GL15.glBindBuffer(GL21.GL_PIXEL_PACK_BUFFER, pbo[slot]);
            GL11.glReadPixels(0, 0, outW, outH, GL12.GL_BGR, GL11.GL_UNSIGNED_BYTE, 0L);
            fence[slot] = GL32.glFenceSync(GL32.GL_SYNC_GPU_COMMANDS_COMPLETE, 0);
            slotSeq[slot] = ++seq;
            GL11.glFlush();

            // Try to finish THIS frame right now (usually succeeds within a fraction of a millisecond).
            if (tryCollect(slot, SAME_FRAME_WAIT_NANOS)) {
                // a newer frame went out, so anything older that is still pending is obsolete
                for (int i = 0; i < RING; i++) if (fence[i] != 0) freeSlotFence(i);
            }
        } finally {
            if (scissor) GL11.glEnable(GL11.GL_SCISSOR_TEST);
            GL15.glBindBuffer(GL21.GL_PIXEL_PACK_BUFFER, prevPack);
            GL11.glPixelStorei(GL11.GL_PACK_ALIGNMENT, prevPackAlign);
            GL30.glBindFramebuffer(GL30.GL_READ_FRAMEBUFFER, prevRead);
            GL30.glBindFramebuffer(GL30.GL_DRAW_FRAMEBUFFER, prevDraw);
        }
    }

    private int freeSlot() {
        for (int i = 0; i < RING; i++) if (fence[i] == 0) return i;
        return -1;
    }

    /** Hands over every pending frame whose copy is already finished, oldest first, without waiting. */
    private void collectReady() {
        for (;;) {
            int oldest = -1;
            for (int i = 0; i < RING; i++) {
                if (fence[i] != 0 && (oldest < 0 || slotSeq[i] < slotSeq[oldest])) oldest = i;
            }
            if (oldest < 0 || !tryCollect(oldest, 0)) return;
        }
    }

    /** @return true if the frame in this slot was finished and handed to an encoder (or dropped as unusable) */
    private boolean tryCollect(int slot, long timeoutNanos) {
        int r = GL32.glClientWaitSync(fence[slot], timeoutNanos > 0 ? GL32.GL_SYNC_FLUSH_COMMANDS_BIT : 0, timeoutNanos);
        if (r == GL32.GL_WAIT_FAILED) throw new IllegalStateException("glClientWaitSync failed");
        if (r != GL32.GL_ALREADY_SIGNALED && r != GL32.GL_CONDITION_SATISFIED) return false;

        long frameSeq = slotSeq[slot];
        freeSlotFence(slot);
        if (inFlight.get() >= ENCODERS) return true; // encoders busy: this frame is dropped

        Job job = jobPool.poll();
        if (job == null || job.w != outW || job.h != outH) job = new Job(outW, outH);
        job.seq = frameSeq;

        GL15.glBindBuffer(GL21.GL_PIXEL_PACK_BUFFER, pbo[slot]);
        ByteBuffer mapped = GL30.glMapBufferRange(GL21.GL_PIXEL_PACK_BUFFER, 0, (long) outW * outH * 3, GL30.GL_MAP_READ_BIT);
        if (mapped == null) {
            jobPool.offer(job);
            return true;
        }
        mapped.get(job.px, 0, Math.min(job.px.length, mapped.remaining()));
        GL15.glUnmapBuffer(GL21.GL_PIXEL_PACK_BUFFER);
        submit(job);
        return true;
    }

    private void freeSlotFence(int slot) {
        if (fence[slot] != 0) {
            GL32.glDeleteSync(fence[slot]);
            fence[slot] = 0;
        }
    }

    private void dropPending() {
        if (srcFbo == 0) return;
        try {
            for (int i = 0; i < RING; i++) freeSlotFence(i);
        } catch (Throwable ignored) {
        }
    }

    private void createTargets(int w, int h) {
        int prevRb = GL11.glGetInteger(GL30.GL_RENDERBUFFER_BINDING);
        int prevFbo = GL11.glGetInteger(GL30.GL_DRAW_FRAMEBUFFER_BINDING);
        int prevPack = GL11.glGetInteger(GL21.GL_PIXEL_PACK_BUFFER_BINDING);

        destroyTargets();
        outW = w;
        outH = h;
        jobPool.clear();

        srcFbo = GL30.glGenFramebuffers();
        dstFbo = GL30.glGenFramebuffers();
        dstRb = GL30.glGenRenderbuffers();
        GL30.glBindRenderbuffer(GL30.GL_RENDERBUFFER, dstRb);
        GL30.glRenderbufferStorage(GL30.GL_RENDERBUFFER, GL11.GL_RGBA8, w, h);
        GL30.glBindFramebuffer(GL30.GL_DRAW_FRAMEBUFFER, dstFbo);
        GL30.glFramebufferRenderbuffer(GL30.GL_DRAW_FRAMEBUFFER, GL30.GL_COLOR_ATTACHMENT0, GL30.GL_RENDERBUFFER, dstRb);

        for (int i = 0; i < RING; i++) {
            pbo[i] = GL15.glGenBuffers();
            GL15.glBindBuffer(GL21.GL_PIXEL_PACK_BUFFER, pbo[i]);
            GL15.glBufferData(GL21.GL_PIXEL_PACK_BUFFER, (long) w * h * 3, GL15.GL_STREAM_READ);
        }

        GL15.glBindBuffer(GL21.GL_PIXEL_PACK_BUFFER, prevPack);
        GL30.glBindFramebuffer(GL30.GL_DRAW_FRAMEBUFFER, prevFbo);
        GL30.glBindRenderbuffer(GL30.GL_RENDERBUFFER, prevRb);
        WebXRMod.LOGGER.info("WebXR: streaming {}x{} JPEG at up to {} fps", w, h, WebXRConfig.streamFps);
    }

    private void destroyTargets() {
        for (int i = 0; i < RING; i++) {
            freeSlotFence(i);
            if (pbo[i] != 0) GL15.glDeleteBuffers(pbo[i]);
            pbo[i] = 0;
        }
        if (srcFbo != 0) GL30.glDeleteFramebuffers(srcFbo);
        if (dstFbo != 0) GL30.glDeleteFramebuffers(dstFbo);
        if (dstRb != 0) GL30.glDeleteRenderbuffers(dstRb);
        srcFbo = dstFbo = dstRb = 0;
    }

    /** Called when the VR renderer is torn down (GL objects are tied to the context). */
    public void release() {
        try {
            destroyTargets();
        } catch (Throwable ignored) {
        }
        outW = outH = 0;
    }

    // ------------------------------------------------------------------ encoding (background threads)

    private void submit(Job job) {
        inFlight.incrementAndGet();
        encoders.execute(() -> {
            try {
                byte[] jpeg = encode(job);
                if (jpeg != null && server != null) {
                    server.broadcastFrame(jpeg, job.seq);
                    if (!loggedFirst) {
                        loggedFirst = true;
                        WebXRMod.LOGGER.info("WebXR: first video frame sent: {}x{}, {} KB", job.w, job.h, jpeg.length / 1024);
                    }
                }
            } catch (Throwable t) {
                WebXRMod.LOGGER.warn("WebXR: JPEG encode failed: {}", t.toString());
            } finally {
                jobPool.offer(job);
                inFlight.decrementAndGet();
            }
        });
    }

    private byte[] encode(Job job) throws Exception {
        ImageWriter writer = writers.get();
        ImageWriteParam p = writer.getDefaultWriteParam();
        p.setCompressionMode(ImageWriteParam.MODE_EXPLICIT);
        p.setCompressionQuality(WebXRConfig.jpegQuality);
        ByteArrayOutputStream bos = new ByteArrayOutputStream(job.w * job.h / 8);
        try (ImageOutputStream ios = ImageIO.createImageOutputStream(bos)) {
            writer.setOutput(ios);
            writer.write(null, new IIOImage(job.img, null, null), p);
            writer.reset();
        }
        return bos.toByteArray();
    }
}
