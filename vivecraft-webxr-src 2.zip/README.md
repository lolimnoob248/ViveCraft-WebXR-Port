# Vivecraft WebXR (wireless, browser-based VR for Vivecraft)

Adds a **WebXR** VR device to Vivecraft 1.21.11-1.3.15 (Fabric). The game runs on your PC; your
headset only opens a web page. Like wireless PCVR, but through the browser.

```
 PC (Minecraft + this mod)                         Headset browser (Quest Browser, etc.)
 ┌──────────────────────────────┐   poses+buttons  ┌─────────────────────────────┐
 │ Vivecraft "WebXR" VR device  │ <──────────────  │ WebXR page, "Enter VR"      │
 │ renders VR, grabs left eye,  │   JPEG frames    │ head-locked flat screen     │
 │ JPEG-encodes, streams        │ ───────────────> │ shows the stream            │
 └──────────────────────────────┘   (WebSocket)    └─────────────────────────────┘
```

## Build
Needs JDK 21 and Gradle 9.x (or generate a wrapper with `gradle wrapper`).

    gradle build

The mod jar is `build/libs/vivecraft-webxr-1.0.0.jar`.
The original Vivecraft jar is already in `libs/` (compile-time only).

If a version in `gradle.properties` doesn't resolve, take the current numbers for 1.21.11 from
https://fabricmc.net/develop and paste them in.

## Install
Put these three in your `mods` folder (Minecraft 1.21.11, Fabric):
1. `vivecraft-1_21_11-1_3_15-fabric.jar` (the original)
2. `vivecraft-webxr-1.0.0.jar` (this mod)
3. Fabric API

## Use
1. Start the game. The top-left of the game window shows the addresses, e.g. `https://192.168.1.23:8443`.
2. Put the headset on the same Wi-Fi, open that address in its browser.
   The certificate is self-signed: choose *Advanced → Proceed* once.
   (WebXR only works on `https://` or `localhost`, which is why HTTPS is needed.)
3. Press **Enter VR**. The host overlay disappears, Vivecraft switches to VR rendering
   and the host window shows Vivecraft's mirror. Leaving VR switches back and shows the address again.

Head and controller tracking is sent to the game; you see the VR picture on a flat,
head-locked screen. "Screen size" / "Distance" sliders are on the page.

## Controls (xr-standard controllers)
| | Right | Left |
|---|---|---|
| Trigger | Attack / destroy | Use / place |
| Grip | Use / place | Sprint (hold) |
| A / X | Jump | Sneak (hold) |
| B / Y | Swap hands | Vivecraft menu |
| Stick | Turn; up/down = hotbar | Move |
| Stick click | Inventory | Drop item |

With a screen open: trigger = left click, grip = right click.

## Config (`config/vivecraft-webxr.properties`, restart after editing)
`httpPort` (8080), `httpsPort` (8443), `streamWidth/Height` (1280x720 = Vivecraft's render size),
`streamFps`, `jpegQuality`, `autoEnableVR`, `showOverlay`, `enabled`.
Higher resolution/quality needs more Wi-Fi bandwidth (1280x720 @ 60 fps ≈ 20-40 Mbit/s).

## How it hooks into Vivecraft
* `VRStateMixin` swaps Vivecraft's `NullVR` device for `WebXRVR` (extends NullVR) and selects it at startup.
* `WebXRVR` takes head/controller poses and buttons from the browser instead of mouse/keyboard.
  `isActive()` is true only while a headset is inside "Enter VR", so Vivecraft's hot-switching
  turns VR rendering on/off automatically.
* `WebXRStereoRenderer` renders both eyes at 16:9 into GL textures; `FrameCapture` reads the left eye
  back through pixel buffers and JPEG-encodes it on a worker thread.
* `net/*` is a self-contained HTTP/HTTPS/WebSocket server with a generated self-signed certificate.

## Notes
* Streaming is mono: both eyes see the same flat picture, so there is no stereoscopic depth, and
  you will notice a little latency (Wi-Fi 5/6 on a 5 GHz band strongly recommended).
* Tested here: the server, TLS certificate, WebSocket protocol and pose parsing against real clients,
  and that the Vivecraft-facing classes compile against the supplied jar.
  **Not tested here:** an in-game run with Minecraft and a real headset.
* Vivecraft's own saved `vrEnabled` setting is switched on by this mod.
