package dev.webxrcraft.net;

import dev.webxrcraft.WebXRConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.net.ssl.SSLContext;
import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.NetworkInterface;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Tiny HTTP + WebSocket server. Serves the WebXR page from the mod's resources and accepts the
 * pose/input WebSocket at /ws. Runs the same code on a plain-HTTP port and a TLS port.
 */
public final class WebXRServer {
    private static final Logger LOG = LoggerFactory.getLogger("vivecraft-webxr");
    private static final String WS_GUID = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11";
    private static final String RES_ROOT = "/assets/webxrcraft/web/";

    private final WebXRConfig cfg;
    private final XRState state;
    private final Path keystore;
    private final java.util.function.Supplier<String> configJson;
    private volatile boolean running;
    private final List<ServerSocket> sockets = new ArrayList<>();
    private int boundHttp = -1;
    private int boundHttps = -1;

    public WebXRServer(WebXRConfig cfg, XRState state, Path keystore, java.util.function.Supplier<String> configJson) {
        this.cfg = cfg;
        this.state = state;
        this.keystore = keystore;
        this.configJson = configJson;
    }

    public int httpPort() { return boundHttp; }
    public int httpsPort() { return boundHttps; }

    public void start() {
        running = true;
        InetAddress bind = null;
        try {
            if (!cfg.bindAddress.isBlank() && !cfg.bindAddress.equals("0.0.0.0")) bind = InetAddress.getByName(cfg.bindAddress);
        } catch (IOException e) {
            LOG.warn("Bad bindAddress '{}', using all interfaces", cfg.bindAddress);
        }
        if (cfg.httpPort > 0) {
            try {
                ServerSocket ss = new ServerSocket();
                ss.setReuseAddress(true);
                ss.bind(new InetSocketAddress(bind, cfg.httpPort));
                boundHttp = ss.getLocalPort();
                sockets.add(ss);
                acceptLoop(ss, "http");
            } catch (IOException e) {
                LOG.error("Could not open HTTP port {}: {}", cfg.httpPort, e.toString());
            }
        }
        if (cfg.httpsPort > 0) {
            try {
                SSLContext ctx = SelfSignedCert.load(keystore, localAddresses());
                ServerSocket ss = ctx.getServerSocketFactory().createServerSocket();
                ss.setReuseAddress(true);
                ss.bind(new InetSocketAddress(bind, cfg.httpsPort));
                boundHttps = ss.getLocalPort();
                sockets.add(ss);
                acceptLoop(ss, "https");
            } catch (Exception e) {
                LOG.error("Could not start HTTPS on port {}: {}", cfg.httpsPort, e.toString());
            }
        }
    }

    public void stop() {
        running = false;
        for (ServerSocket s : sockets) {
            try { s.close(); } catch (IOException ignored) { }
        }
        for (WebSocketConnection c : new ArrayList<>(clientsSnapshot())) c.close();
    }

    private List<WebSocketConnection> clientsSnapshot() { return state.clientList(); }

    /** All non-loopback IPv4 addresses of this machine (LAN addresses first). */
    public static List<InetAddress> localAddresses() {
        List<InetAddress> out = new ArrayList<>();
        try {
            for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!ni.isUp() || ni.isLoopback() || ni.isVirtual()) continue;
                for (InetAddress a : Collections.list(ni.getInetAddresses())) {
                    if (a instanceof Inet4Address && !a.isLoopbackAddress() && !a.isLinkLocalAddress()) out.add(a);
                }
            }
        } catch (IOException ignored) { }
        out.sort((a, b) -> Boolean.compare(!a.isSiteLocalAddress(), !b.isSiteLocalAddress()));
        return out;
    }

    private void acceptLoop(ServerSocket ss, String name) {
        Thread t = new Thread(() -> {
            while (running && !ss.isClosed()) {
                try {
                    Socket s = ss.accept();
                    Thread.ofVirtual().name("webxr-conn").start(() -> handle(s));
                } catch (IOException e) {
                    if (running && !ss.isClosed()) LOG.debug("accept failed: {}", e.toString());
                }
            }
        }, "webxr-" + name + "-accept");
        t.setDaemon(true);
        t.start();
    }

    // ---- request handling ------------------------------------------------------------------

    private void handle(Socket s) {
        try {
            s.setTcpNoDelay(true);
            s.setSoTimeout(15000);
            InputStream in = new BufferedInputStream(s.getInputStream(), 8192);
            OutputStream out = s.getOutputStream();

            String requestLine = readLine(in);
            if (requestLine == null || requestLine.isEmpty()) { s.close(); return; }
            Map<String, String> headers = new HashMap<>();
            String line;
            int count = 0;
            while ((line = readLine(in)) != null && !line.isEmpty() && count++ < 100) {
                int i = line.indexOf(':');
                if (i > 0) headers.put(line.substring(0, i).trim().toLowerCase(Locale.ROOT), line.substring(i + 1).trim());
            }
            String[] parts = requestLine.split(" ");
            if (parts.length < 2) { s.close(); return; }
            String method = parts[0];
            String path = parts[1];
            int q = path.indexOf('?');
            if (q >= 0) path = path.substring(0, q);

            boolean upgrade = "websocket".equalsIgnoreCase(headers.getOrDefault("upgrade", ""));
            if (upgrade && path.equals("/ws")) {
                String key = headers.get("sec-websocket-key");
                if (key == null) { respond(out, 400, "text/plain", "bad request".getBytes(), false); s.close(); return; }
                String accept = Base64.getEncoder().encodeToString(
                    MessageDigest.getInstance("SHA-1").digest((key + WS_GUID).getBytes(StandardCharsets.US_ASCII)));
                String resp = "HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\n"
                    + "Sec-WebSocket-Accept: " + accept + "\r\n\r\n";
                out.write(resp.getBytes(StandardCharsets.US_ASCII));
                out.flush();
                s.setSoTimeout(0);
                WebSocketConnection ws = new WebSocketConnection(s, in, out, state);
                ws.sendText(configJson.get());
                LOG.info("WebXR page connected from {}", s.getRemoteSocketAddress());
                ws.run();
                LOG.info("WebXR page disconnected ({})", s.getRemoteSocketAddress());
                return;
            }

            boolean head = method.equals("HEAD");
            if (!method.equals("GET") && !head) {
                respond(out, 405, "text/plain", "method not allowed".getBytes(), false);
                s.close();
                return;
            }
            if (path.equals("/config.json")) {
                respond(out, 200, "application/json", configJson.get().getBytes(StandardCharsets.UTF_8), head);
            } else {
                serveStatic(out, path, head);
            }
            s.close();
        } catch (Exception e) {
            try { s.close(); } catch (IOException ignored) { }
        }
    }

    private void serveStatic(OutputStream out, String path, boolean head) throws IOException {
        if (path.equals("/") || path.isEmpty()) path = "/index.html";
        if (path.contains("..") || path.contains("\\") || path.contains("//")) {
            respond(out, 400, "text/plain", "bad path".getBytes(), head);
            return;
        }
        byte[] data = null;
        try (InputStream r = WebXRServer.class.getResourceAsStream(RES_ROOT + path.substring(1))) {
            if (r != null) data = r.readAllBytes();
        }
        if (data == null) {
            if (path.equals("/favicon.ico")) { respond(out, 204, "image/x-icon", new byte[0], head); return; }
            respond(out, 404, "text/plain", "not found".getBytes(), head);
            return;
        }
        respond(out, 200, mime(path), data, head);
    }

    private static String mime(String p) {
        if (p.endsWith(".html")) return "text/html; charset=utf-8";
        if (p.endsWith(".js")) return "text/javascript; charset=utf-8";
        if (p.endsWith(".css")) return "text/css; charset=utf-8";
        if (p.endsWith(".json")) return "application/json";
        if (p.endsWith(".svg")) return "image/svg+xml";
        if (p.endsWith(".png")) return "image/png";
        return "application/octet-stream";
    }

    private static void respond(OutputStream out, int code, String type, byte[] body, boolean head) throws IOException {
        String reason = switch (code) {
            case 200 -> "OK"; case 204 -> "No Content"; case 400 -> "Bad Request";
            case 404 -> "Not Found"; case 405 -> "Method Not Allowed"; default -> "Error";
        };
        String h = "HTTP/1.1 " + code + " " + reason + "\r\nContent-Type: " + type + "\r\nContent-Length: " + body.length
            + "\r\nCache-Control: no-cache\r\nConnection: close\r\n\r\n";
        out.write(h.getBytes(StandardCharsets.US_ASCII));
        if (!head) out.write(body);
        out.flush();
    }

    private static String readLine(InputStream in) throws IOException {
        ByteArrayOutputStream b = new ByteArrayOutputStream();
        int c;
        while ((c = in.read()) >= 0) {
            if (c == '\n') break;
            if (c != '\r') b.write(c);
            if (b.size() > 16384) throw new IOException("line too long");
        }
        if (c < 0 && b.size() == 0) return null;
        return b.toString(StandardCharsets.ISO_8859_1);
    }
}
