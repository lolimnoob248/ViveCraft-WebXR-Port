package dev.webxrcraft.net;

import java.io.ByteArrayOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.nio.charset.StandardCharsets;

/** Minimal RFC 6455 server-side WebSocket (no extensions, no fragmentation on send). */
public final class WebSocketConnection {
    private static final int MAX_MESSAGE = 1 << 20; // inbound messages are tiny pose packets

    private final Socket socket;
    private final InputStream in;
    private final OutputStream out;
    private final XRState state;
    private volatile boolean open = true;
    private final Object writeLock = new Object();
    /** Set while a frame write is in progress, so a slow link drops frames instead of piling up. */
    private volatile boolean writingFrame;

    WebSocketConnection(Socket socket, InputStream in, OutputStream out, XRState state) {
        this.socket = socket;
        this.in = in;
        this.out = out;
        this.state = state;
    }

    public boolean isOpen() { return open; }

    /** Blocks, reading messages until the connection closes. */
    void run() {
        state.addClient(this);
        try {
            ByteArrayOutputStream msg = new ByteArrayOutputStream();
            int msgOpcode = 0;
            while (open) {
                int b0 = in.read();
                if (b0 < 0) break;
                int b1 = in.read();
                if (b1 < 0) break;
                boolean fin = (b0 & 0x80) != 0;
                int opcode = b0 & 0x0F;
                boolean masked = (b1 & 0x80) != 0;
                long len = b1 & 0x7F;
                if (len == 126) {
                    len = (readByte() << 8) | readByte();
                } else if (len == 127) {
                    len = 0;
                    for (int i = 0; i < 8; i++) len = (len << 8) | readByte();
                }
                if (len > MAX_MESSAGE) break;
                byte[] mask = null;
                if (masked) {
                    mask = new byte[4];
                    readFully(mask, 4);
                }
                byte[] payload = new byte[(int) len];
                readFully(payload, payload.length);
                if (mask != null) {
                    for (int i = 0; i < payload.length; i++) payload[i] ^= mask[i & 3];
                }
                switch (opcode) {
                    case 0x8 -> { // close
                        writeFrame(0x8, payload, payload.length);
                        open = false;
                    }
                    case 0x9 -> writeFrame(0xA, payload, payload.length); // ping -> pong
                    case 0xA -> { /* pong */ }
                    default -> { // 0 continuation, 1 text, 2 binary
                        if (opcode != 0) {
                            msg.reset();
                            msgOpcode = opcode;
                        }
                        msg.write(payload, 0, payload.length);
                        if (msg.size() > MAX_MESSAGE) { open = false; break; }
                        if (fin) {
                            if (msgOpcode == 0x2) state.onBinary(this, msg.toByteArray());
                            // text messages from the page are informational only
                            msg.reset();
                        }
                    }
                }
            }
        } catch (IOException ignored) {
            // client went away
        } finally {
            close();
            state.removeClient(this);
        }
    }

    private int readByte() throws IOException {
        int v = in.read();
        if (v < 0) throw new EOFException();
        return v;
    }

    private void readFully(byte[] buf, int len) throws IOException {
        int off = 0;
        while (off < len) {
            int n = in.read(buf, off, len - off);
            if (n < 0) throw new EOFException();
            off += n;
        }
    }

    // ---- sending ----------------------------------------------------------------------------

    public void sendText(String s) {
        byte[] d = s.getBytes(StandardCharsets.UTF_8);
        try { writeFrame(0x1, d, d.length); } catch (IOException e) { close(); }
    }

    /** Sends [0x01][jpeg bytes]. Dropped if the previous frame is still being written. */
    void sendFrame(byte[] jpeg, int len) {
        if (!open || writingFrame) return;
        writingFrame = true;
        try {
            byte[] framed = new byte[len + 1];
            framed[0] = 1;
            System.arraycopy(jpeg, 0, framed, 1, len);
            writeFrame(0x2, framed, framed.length);
        } catch (IOException e) {
            close();
        } finally {
            writingFrame = false;
        }
    }

    private void writeFrame(int opcode, byte[] data, int len) throws IOException {
        synchronized (writeLock) {
            if (!open && opcode != 0x8) return;
            int hl;
            byte[] h = new byte[10];
            h[0] = (byte) (0x80 | opcode);
            if (len < 126) {
                h[1] = (byte) len;
                hl = 2;
            } else if (len < 65536) {
                h[1] = 126;
                h[2] = (byte) (len >> 8);
                h[3] = (byte) len;
                hl = 4;
            } else {
                h[1] = 127;
                for (int i = 0; i < 8; i++) h[2 + i] = (byte) ((long) len >> (8 * (7 - i)));
                hl = 10;
            }
            out.write(h, 0, hl);
            out.write(data, 0, len);
            out.flush();
        }
    }

    public void close() {
        open = false;
        try { socket.close(); } catch (IOException ignored) { }
    }
}
