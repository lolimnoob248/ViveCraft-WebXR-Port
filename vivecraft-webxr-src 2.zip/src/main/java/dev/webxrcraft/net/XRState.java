package dev.webxrcraft.net;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * Thread-safe shared state between the network threads (which receive poses from the browser)
 * and the Minecraft render thread (which polls them).
 */
public final class XRState {
    public static final int MSG_POSE = 1;
    public static final int MSG_STATE = 2;

    /** One controller as reported by WebXR (target-ray space, local-floor reference space). */
    public static final class Controller {
        public boolean present;
        public final float[] pos = new float[3];
        public final float[] quat = {0, 0, 0, 1}; // x y z w
        public int buttons;                          // bit i = xr-standard button i pressed
        public final float[] axes = new float[4];    // xr-standard axes 0..3
    }

    /** Snapshot of one pose packet. */
    public static final class Pose {
        public float ipd = 0.063f;
        public final float[] headPos = new float[3];
        public final float[] headQuat = {0, 0, 0, 1};
        public final Controller right = new Controller();
        public final Controller left = new Controller();
    }

    private final List<WebSocketConnection> clients = new CopyOnWriteArrayList<>();
    private volatile Pose latest;
    private volatile long lastPoseNanos;
    private volatile WebSocketConnection active;
    private volatile float refreshRate = 72f;
    private final long timeoutNanos;

    public XRState(float timeoutSeconds) {
        this.timeoutNanos = (long) (timeoutSeconds * 1_000_000_000L);
    }

    // ---- connection bookkeeping ------------------------------------------------------------

    void addClient(WebSocketConnection c) { clients.add(c); }

    void removeClient(WebSocketConnection c) {
        clients.remove(c);
        if (active == c) {
            active = null;
            latest = null;
        }
    }

    public int clientCount() { return clients.size(); }
    List<WebSocketConnection> clientList() { return clients; }

    // ---- inbound messages ------------------------------------------------------------------

    /** Called from the WebSocket reader thread. */
    void onBinary(WebSocketConnection from, byte[] data) {
        if (data.length < 2) return;
        ByteBuffer b = ByteBuffer.wrap(data).order(ByteOrder.LITTLE_ENDIAN);
        int type = b.get() & 0xFF;
        if (type == MSG_STATE) {
            boolean inVr = b.get() != 0;
            if (b.remaining() >= 4) {
                float hz = b.getFloat();
                if (hz >= 30 && hz <= 240) refreshRate = hz;
            }
            if (inVr) {
                if (active == null || active == from || !active.isOpen()) {
                    active = from;
                    lastPoseNanos = System.nanoTime();
                }
            } else if (active == from) {
                active = null;
                latest = null;
            }
        } else if (type == MSG_POSE) {
            if (active != from) return; // only the headset that pressed "Enter VR" drives the game
            Pose p = parsePose(b);
            if (p != null) {
                latest = p;
                lastPoseNanos = System.nanoTime();
            }
        }
    }

    static Pose parsePose(ByteBuffer b) {
        // after the type byte: flags(1) ipd(4) head(28) right(48) left(48)
        if (b.remaining() < 1 + 4 + 28 + 48 + 48) return null;
        Pose p = new Pose();
        int flags = b.get() & 0xFF;
        float ipd = b.getFloat();
        if (ipd > 0.04f && ipd < 0.09f) p.ipd = ipd;
        readPose(b, p.headPos, p.headQuat);
        readController(b, p.right, (flags & 1) != 0);
        readController(b, p.left, (flags & 2) != 0);
        if (!finite(p.headPos) || !finite(p.headQuat)) return null;
        return p;
    }

    private static void readController(ByteBuffer b, Controller c, boolean present) {
        readPose(b, c.pos, c.quat);
        c.buttons = b.getInt();
        for (int i = 0; i < 4; i++) c.axes[i] = b.getFloat();
        c.present = present && finite(c.pos) && finite(c.quat);
    }

    private static void readPose(ByteBuffer b, float[] pos, float[] q) {
        pos[0] = b.getFloat(); pos[1] = b.getFloat(); pos[2] = b.getFloat();
        q[0] = b.getFloat(); q[1] = b.getFloat(); q[2] = b.getFloat(); q[3] = b.getFloat();
    }

    private static boolean finite(float[] a) {
        for (float f : a) if (Float.isNaN(f) || Float.isInfinite(f)) return false;
        return true;
    }

    // ---- queries used by the game thread ---------------------------------------------------

    /** True while a browser has an "Enter VR" session open and is still sending poses. */
    public boolean isVrActive() {
        WebSocketConnection a = active;
        return a != null && a.isOpen() && (System.nanoTime() - lastPoseNanos) < timeoutNanos;
    }

    public Pose latestPose() { return isVrActive() ? latest : null; }
    public float refreshRate() { return refreshRate; }

    // ---- outbound ---------------------------------------------------------------------------

    /** Send a JPEG frame to every connected page (slow clients simply miss frames). */
    public void broadcastFrame(byte[] jpeg, int len) {
        for (WebSocketConnection c : clients) {
            c.sendFrame(jpeg, len);
        }
    }

    public void broadcastText(String json) {
        for (WebSocketConnection c : clients) c.sendText(json);
    }

    public void sendHaptic(int hand, float seconds, float amplitude) {
        WebSocketConnection a = active;
        if (a == null) return;
        int ms = Math.max(1, Math.min(2000, Math.round(seconds * 1000f)));
        float amp = Math.max(0f, Math.min(1f, amplitude));
        a.sendText(String.format(java.util.Locale.ROOT,
            "{\"t\":\"haptic\",\"hand\":%d,\"ms\":%d,\"amp\":%.3f}", hand, ms, amp));
    }
}
