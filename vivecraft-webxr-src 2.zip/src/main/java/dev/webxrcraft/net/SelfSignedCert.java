package dev.webxrcraft.net;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.math.BigInteger;
import java.net.InetAddress;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.KeyStore;
import java.security.SecureRandom;
import java.security.Signature;
import java.security.cert.Certificate;
import java.security.cert.CertificateFactory;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;

/**
 * Creates (and caches on disk) a self-signed TLS certificate using only the JDK, by hand-encoding the
 * X.509 structure in DER. Browsers need HTTPS on a LAN address before they expose WebXR.
 */
public final class SelfSignedCert {
    private static final char[] PASS = "webxr".toCharArray();
    private static final String ALIAS = "webxr";

    private SelfSignedCert() { }

    public static SSLContext load(Path keystoreFile, List<InetAddress> addresses) throws Exception {
        KeyStore ks = KeyStore.getInstance("PKCS12");
        boolean loaded = false;
        if (Files.exists(keystoreFile)) {
            try (var in = Files.newInputStream(keystoreFile)) {
                ks.load(in, PASS);
                loaded = ks.containsAlias(ALIAS);
                if (loaded) {
                    java.security.cert.X509Certificate c = (java.security.cert.X509Certificate) ks.getCertificate(ALIAS);
                    c.checkValidity(); // regenerate when expired
                }
            } catch (Exception e) {
                loaded = false;
            }
        }
        if (!loaded) {
            ks = KeyStore.getInstance("PKCS12");
            ks.load(null, null);
            KeyPairGenerator g = KeyPairGenerator.getInstance("RSA");
            g.initialize(2048, new SecureRandom());
            KeyPair kp = g.generateKeyPair();
            byte[] der = buildCertificate(kp, addresses);
            Certificate cert = CertificateFactory.getInstance("X.509").generateCertificate(new ByteArrayInputStream(der));
            ks.setKeyEntry(ALIAS, kp.getPrivate(), PASS, new Certificate[]{cert});
            try {
                Files.createDirectories(keystoreFile.getParent());
                try (var out = Files.newOutputStream(keystoreFile)) {
                    ks.store(out, PASS);
                }
            } catch (IOException ignored) {
                // still usable in memory
            }
        }
        KeyManagerFactory kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
        kmf.init(ks, PASS);
        SSLContext ctx = SSLContext.getInstance("TLS");
        ctx.init(kmf.getKeyManagers(), null, null);
        return ctx;
    }

    // ---- DER encoding ------------------------------------------------------------------------

    static byte[] buildCertificate(KeyPair kp, List<InetAddress> addresses) throws Exception {
        byte[] sigAlg = seq(oid("1.2.840.113549.1.1.11"), new byte[]{0x05, 0x00}); // sha256WithRSA, NULL
        byte[] name = seq(set(seq(oid("2.5.4.3"), tlv(0x0C, "Vivecraft WebXR".getBytes(StandardCharsets.UTF_8)))));

        ZonedDateTime now = ZonedDateTime.now(ZoneOffset.UTC).minusDays(1);
        ZonedDateTime end = now.plusDays(825);
        DateTimeFormatter f = DateTimeFormatter.ofPattern("yyMMddHHmmss'Z'");
        byte[] validity = seq(tlv(0x17, f.format(now).getBytes(StandardCharsets.US_ASCII)),
                              tlv(0x17, f.format(end).getBytes(StandardCharsets.US_ASCII)));

        // subjectAltName
        ByteArrayOutputStream san = new ByteArrayOutputStream();
        san.write(tlv(0x82, "localhost".getBytes(StandardCharsets.US_ASCII)));          // dNSName
        san.write(tlv(0x87, new byte[]{127, 0, 0, 1}));                                  // iPAddress
        for (InetAddress a : addresses) {
            byte[] raw = a.getAddress();
            if (raw.length == 4 && !a.isLoopbackAddress()) san.write(tlv(0x87, raw));
        }
        byte[] sanExt = seq(oid("2.5.29.17"), tlv(0x04, seq(san.toByteArray())));
        byte[] bc = seq(oid("2.5.29.19"), tlv(0x01, new byte[]{(byte) 0xFF}), tlv(0x04, seq())); // CA:FALSE (critical)
        byte[] eku = seq(oid("2.5.29.37"), tlv(0x04, seq(oid("1.3.6.1.5.5.7.3.1"))));             // serverAuth
        byte[] exts = tlv(0xA3, seq(sanExt, bc, eku));

        byte[] serial = tlv(0x02, new BigInteger(64, new SecureRandom()).abs().add(BigInteger.ONE).toByteArray());
        byte[] tbs = seq(
            tlv(0xA0, tlv(0x02, new byte[]{2})), // version v3
            serial, sigAlg, name, validity, name,
            kp.getPublic().getEncoded(),         // SubjectPublicKeyInfo is already DER
            exts);

        Signature s = Signature.getInstance("SHA256withRSA");
        s.initSign(kp.getPrivate());
        s.update(tbs);
        byte[] sig = s.sign();
        byte[] sigBits = new byte[sig.length + 1];
        System.arraycopy(sig, 0, sigBits, 1, sig.length);
        return seq(tbs, sigAlg, tlv(0x03, sigBits));
    }

    private static byte[] seq(byte[]... parts) { return tlv(0x30, concat(parts)); }
    private static byte[] set(byte[]... parts) { return tlv(0x31, concat(parts)); }

    private static byte[] concat(byte[]... parts) {
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        for (byte[] p : parts) o.write(p, 0, p.length);
        return o.toByteArray();
    }

    private static byte[] tlv(int tag, byte[] content) {
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        o.write(tag);
        int n = content.length;
        if (n < 128) {
            o.write(n);
        } else if (n < 256) {
            o.write(0x81); o.write(n);
        } else if (n < 65536) {
            o.write(0x82); o.write(n >> 8); o.write(n & 0xFF);
        } else {
            o.write(0x83); o.write(n >> 16); o.write((n >> 8) & 0xFF); o.write(n & 0xFF);
        }
        o.write(content, 0, n);
        return o.toByteArray();
    }

    private static byte[] oid(String dotted) {
        String[] p = dotted.split("\\.");
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        o.write(Integer.parseInt(p[0]) * 40 + Integer.parseInt(p[1]));
        for (int i = 2; i < p.length; i++) {
            long v = Long.parseLong(p[i]);
            byte[] tmp = new byte[10];
            int k = 0;
            tmp[k++] = (byte) (v & 0x7F);
            v >>= 7;
            while (v > 0) { tmp[k++] = (byte) (0x80 | (v & 0x7F)); v >>= 7; }
            for (int j = k - 1; j >= 0; j--) o.write(tmp[j]);
        }
        return tlv(0x06, o.toByteArray());
    }
}
