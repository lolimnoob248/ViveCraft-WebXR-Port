package dev.webxrcraft.client;

import dev.webxrcraft.WebXRMod;
import dev.webxrcraft.net.WebXRServer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import org.vivecraft.client_vr.VRState;

import java.net.InetAddress;
import java.util.ArrayList;
import java.util.List;

/**
 * Draws the connection info on the host screen (normal game window) until a headset is in VR.
 * Once VR is running, Vivecraft's own mirror shows the VR frames and this overlay disappears.
 */
public final class HostOverlay {
    private static List<String> cachedUrls;
    private static long cachedAt;

    private HostOverlay() { }

    /** URLs to open in the headset browser; LAN addresses first. */
    public static List<String> urls() {
        long now = System.currentTimeMillis();
        if (cachedUrls != null && now - cachedAt < 5000) return cachedUrls;
        List<String> out = new ArrayList<>();
        WebXRServer s = WebXRMod.server();
        if (s != null) {
            for (InetAddress a : WebXRServer.localAddresses()) {
                if (s.httpsPort() > 0) out.add("https://" + a.getHostAddress() + ":" + s.httpsPort());
            }
            if (s.httpPort() > 0) {
                out.add("http://localhost:" + s.httpPort() + "  (same PC only)");
            }
        }
        cachedUrls = out;
        cachedAt = now;
        return out;
    }

    public static void render(GuiGraphics g) {
        if (!WebXRMod.isEnabled()) return;
        if (VRState.VR_RUNNING || WebXRMod.state().isVrActive()) return; // VR is on: Vivecraft's mirror takes over
        Minecraft mc = Minecraft.getInstance();
        List<String> lines = new ArrayList<>();
        lines.add("Vivecraft WebXR");
        lines.add("Open this address in your headset's browser, then press \"Enter VR\":");
        List<String> urls = urls();
        if (urls.isEmpty()) lines.add("(no network address found)");
        lines.addAll(urls);
        int clients = WebXRMod.state().clientCount();
        lines.add(clients == 0 ? "Waiting for a browser..." : "Browser connected (" + clients + ") - waiting for \"Enter VR\"");

        int pad = 6, lineH = 11, width = 0;
        for (String l : lines) width = Math.max(width, mc.font.width(l));
        int x = 8, y = 8;
        g.fill(x - pad, y - pad, x + width + pad, y + lines.size() * lineH + pad - 2, 0xB0000000);
        for (int i = 0; i < lines.size(); i++) {
            int color = i == 0 ? 0xFF55FFFF : (lines.get(i).startsWith("https://") ? 0xFFFFFF55 : 0xFFFFFFFF);
            g.drawString(mc.font, lines.get(i), x, y + i * lineH, color);
        }
    }
}
