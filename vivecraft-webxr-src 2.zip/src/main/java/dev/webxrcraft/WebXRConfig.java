package dev.webxrcraft;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/** Simple properties-based config, stored in config/vivecraft-webxr.properties. */
public final class WebXRConfig {
    private static final org.slf4j.Logger LOG = org.slf4j.LoggerFactory.getLogger("vivecraft-webxr");

    /** Master switch. If false the mod does nothing and Vivecraft behaves as normal. */
    public boolean enabled = true;
    /** Plain HTTP port. WebXR only works over plain HTTP on "localhost". */
    public int httpPort = 8080;
    /** HTTPS port (self-signed certificate). Needed for headsets on the LAN. 0 disables. */
    public int httpsPort = 8443;
    public String bindAddress = "0.0.0.0";
    /** Resolution of the streamed "virtual monitor" (and of Vivecraft's render target). */
    public int streamWidth = 1280;
    public int streamHeight = 720;
    /** Maximum number of frames per second that are captured and sent. */
    public int streamFps = 60;
    /** JPEG quality 1-100. */
    public int jpegQuality = 80;
    /** Seconds without a pose packet before the headset counts as disconnected. */
    public float poseTimeoutSeconds = 2.0f;
    /** Switch Vivecraft on automatically at game start (WebXR device is then used for hot-switching). */
    public boolean autoEnableVR = true;
    /** Show the address overlay on the host while no headset is in VR. */
    public boolean showOverlay = true;

    public static WebXRConfig load(Path file) {
        WebXRConfig c = new WebXRConfig();
        Properties p = new Properties();
        if (Files.exists(file)) {
            try (InputStream in = Files.newInputStream(file)) {
                p.load(in);
            } catch (IOException e) {
                LOG.warn("Could not read {}: {}", file, e.toString());
            }
        }
        c.enabled = bool(p, "enabled", c.enabled);
        c.httpPort = num(p, "httpPort", c.httpPort, 0, 65535);
        c.httpsPort = num(p, "httpsPort", c.httpsPort, 0, 65535);
        c.bindAddress = p.getProperty("bindAddress", c.bindAddress).trim();
        c.streamWidth = num(p, "streamWidth", c.streamWidth, 320, 4096);
        c.streamHeight = num(p, "streamHeight", c.streamHeight, 180, 4096);
        c.streamFps = num(p, "streamFps", c.streamFps, 5, 144);
        c.jpegQuality = num(p, "jpegQuality", c.jpegQuality, 1, 100);
        c.poseTimeoutSeconds = num(p, "poseTimeoutSeconds", Math.round(c.poseTimeoutSeconds), 1, 60);
        c.autoEnableVR = bool(p, "autoEnableVR", c.autoEnableVR);
        c.showOverlay = bool(p, "showOverlay", c.showOverlay);
        c.save(file); // write defaults / normalise
        return c;
    }

    private void save(Path file) {
        Properties p = new Properties();
        p.setProperty("enabled", Boolean.toString(enabled));
        p.setProperty("httpPort", Integer.toString(httpPort));
        p.setProperty("httpsPort", Integer.toString(httpsPort));
        p.setProperty("bindAddress", bindAddress);
        p.setProperty("streamWidth", Integer.toString(streamWidth));
        p.setProperty("streamHeight", Integer.toString(streamHeight));
        p.setProperty("streamFps", Integer.toString(streamFps));
        p.setProperty("jpegQuality", Integer.toString(jpegQuality));
        p.setProperty("poseTimeoutSeconds", Integer.toString(Math.round(poseTimeoutSeconds)));
        p.setProperty("autoEnableVR", Boolean.toString(autoEnableVR));
        p.setProperty("showOverlay", Boolean.toString(showOverlay));
        try {
            Files.createDirectories(file.getParent());
            try (OutputStream out = Files.newOutputStream(file)) {
                p.store(out, "Vivecraft WebXR - restart the game after changing");
            }
        } catch (IOException e) {
            LOG.warn("Could not write {}: {}", file, e.toString());
        }
    }

    private static boolean bool(Properties p, String k, boolean d) {
        String v = p.getProperty(k);
        return v == null ? d : Boolean.parseBoolean(v.trim());
    }

    private static int num(Properties p, String k, int d, int min, int max) {
        try {
            String v = p.getProperty(k);
            int n = v == null ? d : Integer.parseInt(v.trim());
            return Math.max(min, Math.min(max, n));
        } catch (NumberFormatException e) {
            return d;
        }
    }
}
