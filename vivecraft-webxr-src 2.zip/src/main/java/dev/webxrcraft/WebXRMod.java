package dev.webxrcraft;

import dev.webxrcraft.client.HostOverlay;
import dev.webxrcraft.net.WebXRServer;
import dev.webxrcraft.net.XRState;
import dev.webxrcraft.vr.FrameCapture;
import net.fabricmc.api.ClientModInitializer;
import net.minecraft.client.Minecraft;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.loader.api.FabricLoader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.vivecraft.client_vr.ClientDataHolderVR;
import org.vivecraft.client_vr.VRState;
import org.vivecraft.client_vr.settings.VRSettings;

import java.nio.file.Path;
import java.util.Locale;

/** Entry point: starts the web server and makes Vivecraft ready to switch to the WebXR device. */
public class WebXRMod implements ClientModInitializer {
    public static final Logger LOGGER = LoggerFactory.getLogger("vivecraft-webxr");

    private static WebXRConfig config = new WebXRConfig();
    private static XRState state;
    private static WebXRServer server;
    private static FrameCapture capture;
    private static boolean wasActive;
    private static int readyTicks;

    public static WebXRConfig config() { return config; }
    public static XRState state() { return state; }
    public static FrameCapture capture() { return capture; }
    public static WebXRServer server() { return server; }
    public static boolean isEnabled() { return config.enabled && state != null; }

    @Override
    public void onInitializeClient() {
        Path dir = FabricLoader.getInstance().getConfigDir();
        config = WebXRConfig.load(dir.resolve("vivecraft-webxr.properties"));
        if (!config.enabled) {
            LOGGER.info("Vivecraft WebXR is disabled in its config.");
            return;
        }
        state = new XRState(config.poseTimeoutSeconds);
        capture = new FrameCapture(state, config);
        server = new WebXRServer(config, state, dir.resolve("vivecraft-webxr-keystore.p12"), WebXRMod::configJson);
        server.start();
        for (String url : HostOverlay.urls()) LOGGER.info("WebXR page available at {}", url);

        ClientTickEvents.START_CLIENT_TICK.register(client -> tick());
        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> {
            server.stop();
            capture.destroy();
        });
        if (config.showOverlay) {
            HudRenderCallback.EVENT.register((graphics, tickCounter) -> HostOverlay.render(graphics));
            ScreenEvents.AFTER_INIT.register((client, screen, w, h) ->
                ScreenEvents.afterRender(screen).register((s, graphics, mx, my, delta) -> HostOverlay.render(graphics)));
        }
    }

    private static void tick() {
        ClientDataHolderVR dh = ClientDataHolderVR.getInstance();
        if (config.autoEnableVR && dh != null && dh.vrSettings != null && !dh.completelyDisabled && !VRState.VR_INITIALIZED) {
            // Only set Vivecraft's saved flags here. Vivecraft itself turns VR on once the
            // initial resource reload has finished; starting earlier crashes ("atlas is not initialized").
            dh.vrSettings.vrEnabled = true;
            dh.vrSettings.rememberVr = true;
            dh.vrSettings.vrHotswitchingEnabled = true;
            dh.vrSettings.stereoProviderPluginID = VRSettings.VRProvider.NULLVR;
            // Fallback in case Vivecraft already checked the flags: only once loading is completely done.
            if (!VRState.VR_ENABLED && Minecraft.getInstance().getOverlay() == null
                    && Minecraft.getInstance().getResourceManager() != null && ++readyTicks > 40) {
                VRState.VR_ENABLED = true;
            }
        }
        boolean active = state.isVrActive();
        if (active && !wasActive) {
            LOGGER.info("WebXR headset entered VR");
            state.broadcastText(configJson());
        } else if (!active && wasActive) {
            LOGGER.info("WebXR headset left VR");
        }
        wasActive = active;
    }

    static String configJson() {
        float fov = 90f;
        try {
            ClientDataHolderVR dh = ClientDataHolderVR.getInstance();
            if (dh != null && dh.vrSettings != null && dh.vrSettings.nullvrFOV > 1f) fov = dh.vrSettings.nullvrFOV;
        } catch (Throwable ignored) { }
        return String.format(Locale.ROOT, "{\"t\":\"cfg\",\"w\":%d,\"h\":%d,\"fov\":%.1f,\"fps\":%d}",
            config.streamWidth, config.streamHeight, fov, config.streamFps);
    }
}
