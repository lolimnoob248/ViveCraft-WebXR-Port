package dev.webxrcraft.mixin;

import dev.webxrcraft.WebXRMod;
import dev.webxrcraft.vr.WebXRVR;
import net.minecraft.client.Minecraft;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.vivecraft.client_vr.ClientDataHolderVR;
import org.vivecraft.client_vr.VRState;
import org.vivecraft.client_vr.provider.nullvr.NullVR;
import org.vivecraft.client_vr.settings.VRSettings;

/**
 * Makes Vivecraft use the WebXR device. Vivecraft picks MCOpenVR for the OPENVR provider and
 * NullVR for everything else, so we select NULLVR and swap the NullVR instance for a WebXRVR.
 */
@Mixin(value = VRState.class, remap = false)
public abstract class VRStateMixin {

    @Inject(method = "initializeVR", at = @At("HEAD"), remap = false)
    private static void webxr$selectProvider(CallbackInfo ci) {
        if (WebXRMod.isEnabled()) {
            ClientDataHolderVR.getInstance().vrSettings.stereoProviderPluginID = VRSettings.VRProvider.NULLVR;
        }
    }

    @Redirect(method = "initializeVR",
        at = @At(value = "NEW", target = "Lorg/vivecraft/client_vr/provider/nullvr/NullVR;"), remap = false)
    private static NullVR webxr$createDevice(Minecraft mc, ClientDataHolderVR dh) {
        return WebXRMod.isEnabled() ? new WebXRVR(mc, dh) : new NullVR(mc, dh);
    }
}
