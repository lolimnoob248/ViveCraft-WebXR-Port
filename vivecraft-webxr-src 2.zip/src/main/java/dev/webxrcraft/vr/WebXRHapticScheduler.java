package dev.webxrcraft.vr;

import dev.webxrcraft.net.XRState;
import org.vivecraft.client_vr.provider.ControllerType;
import org.vivecraft.client_vr.provider.HapticScheduler;

/** Forwards Vivecraft haptic pulses to the browser, which plays them on the real controllers. */
public final class WebXRHapticScheduler extends HapticScheduler {
    private final XRState state;

    public WebXRHapticScheduler(XRState state) {
        this.state = state;
    }

    @Override
    public void queueHapticPulse(ControllerType hand, float durationSeconds, float frequency, float amplitude, float delaySeconds) {
        // device 0 = right controller, device 1 = left controller (same as in the pose packet)
        state.sendHaptic(hand == ControllerType.RIGHT ? 0 : 1, durationSeconds, amplitude);
    }
}
