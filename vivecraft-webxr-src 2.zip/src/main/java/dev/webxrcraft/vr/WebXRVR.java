package dev.webxrcraft.vr;

import dev.webxrcraft.WebXRMod;
import dev.webxrcraft.net.XRState;
import net.minecraft.client.Minecraft;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.vivecraft.client_vr.ClientDataHolderVR;
import org.vivecraft.client_vr.provider.ControllerTransform;
import org.vivecraft.client_vr.provider.VRRenderer;
import org.vivecraft.client_vr.provider.nullvr.NullVR;

/**
 * The "WebXR" VR device. It reuses Vivecraft's NullVR plumbing (settings, input action tables,
 * tracking matrices) but takes every pose and button from a browser running a WebXR session
 * instead of from the keyboard/mouse.
 *
 * isActive() is true only while a headset is inside "Enter VR". Vivecraft's hot-switching then flips
 * the game between normal flat rendering (host shows the address overlay) and VR rendering.
 */
public class WebXRVR extends NullVR {
    private final XRState xr;
    private final InputMapper inputs;
    private final Quaternionf tmpQ = new Quaternionf();
    private float ipd = 0.063F;

    public WebXRVR(Minecraft mc, ClientDataHolderVR dh) {
        super(mc, dh);
        this.xr = WebXRMod.state();
        this.hapticScheduler = new WebXRHapticScheduler(this.xr);
        this.inputs = new InputMapper(this, mc);
    }

    @Override
    public boolean init() {
        boolean ok = super.init();
        this.dh.vrSettings.vrHotswitchingEnabled = true;
        return ok;
    }

    @Override
    public String getName() {
        return "WebXR";
    }

    @Override
    public String getRuntimeName() {
        return "WebXR (browser)";
    }

    @Override
    public boolean isActive() {
        return this.xr.isVrActive();
    }

    @Override
    public float getIPD() {
        return this.ipd;
    }

    @Override
    public VRRenderer createVRRenderer() {
        return new WebXRStereoRenderer(this);
    }

    @Override
    public void poll(long frameIndex) {
        if (!this.initialized) return;
        XRState.Pose p = this.xr.latestPose();
        if (p != null) {
            this.ipd = p.ipd;

            // head: WebXR local-floor space is y-up, -z forward, metres == Vivecraft room space
            this.tmpQ.set(p.headQuat[0], p.headQuat[1], p.headQuat[2], p.headQuat[3]).normalize();
            this.hmdPose.rotation(this.tmpQ).setTranslation(p.headPos[0], p.headPos[1], p.headPos[2]);
            this.hmdPoseLeftEye.m30(-this.ipd * 0.5F);
            this.hmdPoseRightEye.m30(this.ipd * 0.5F);
            this.headIsTracking = true;

            // controller slots follow the "reverse hands" setting, exactly like NullVR
            boolean reverse = this.dh.vrSettings.reverseHands;
            for (int slot = 0; slot < 2; slot++) {
                int device = reverse ? 1 - slot : slot; // device 0 = right, 1 = left
                XRState.Controller c = device == 0 ? p.right : p.left;
                this.controllerTracking[slot] = c.present;
                if (!c.present) continue;
                Matrix4f tip = slot == 0 ? ControllerTransform.NULL.tipR : ControllerTransform.NULL.tipL;
                this.tmpQ.set(c.quat[0], c.quat[1], c.quat[2], c.quat[3]).normalize();
                this.controllerPose[slot] = new Matrix4f(tip).invert()
                    .rotate(this.tmpQ)
                    .setTranslation(c.pos[0], c.pos[1], c.pos[2]);
            }
        }

        this.updateAim();
        this.processInputs();
        this.hmdSampling();
        this.polled = true;
    }

    @Override
    public void processInputs() {
        this.ignorePressesNextFrame = false;
        XRState.Pose p = this.xr.latestPose();
        if (p == null) {
            this.inputs.releaseAll();
        } else {
            this.inputs.update(p);
        }
    }

    @Override
    public void destroy() {
        this.inputs.releaseAll();
        super.destroy();
    }
}
