package dev.webxrcraft.vr;

import dev.webxrcraft.net.XRState;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.Options;
import org.vivecraft.client.VivecraftVRMod;
import org.vivecraft.client_vr.gameplay.screenhandlers.GuiHandler;
import org.vivecraft.client_vr.provider.MCVR;
import org.vivecraft.client_vr.provider.openvr_lwjgl.VRInputAction;

import java.util.HashSet;
import java.util.Set;

/**
 * Translates WebXR "xr-standard" gamepad data into Vivecraft input actions.
 *
 * Button indices: 0 trigger, 1 grip, 2 touchpad, 3 thumbstick click, 4 A/X, 5 B/Y.
 *
 *  Right: trigger = attack/destroy, grip = use/place, A = jump, B = swap hands,
 *         stick X = turn, stick up/down = hotbar, stick click = inventory
 *  Left : trigger = use/place, grip = sprint, X = sneak, Y = Vivecraft menu,
 *         stick = move, stick click = drop item
 *  While a GUI is open: triggers = left click, grips = right click, stick Y = scroll.
 */
final class InputMapper {
    private static final float DEADZONE = 0.12F;
    private static final float HOTBAR_THRESHOLD = 0.8F;

    private final MCVR vr;
    private final Minecraft mc;
    private final Set<VRInputAction> held = new HashSet<>();

    InputMapper(MCVR vr, Minecraft mc) {
        this.vr = vr;
        this.mc = mc;
    }

    private static boolean btn(XRState.Controller c, int i) {
        return c.present && (c.buttons & (1 << i)) != 0;
    }

    private static float dz(float v) {
        return Math.abs(v) < DEADZONE ? 0F : v;
    }

    void update(XRState.Pose p) {
        XRState.Controller r = p.right, l = p.left;
        Options o = this.mc.options;
        VivecraftVRMod v = VivecraftVRMod.INSTANCE;
        boolean gui = this.mc.screen != null;
        Set<VRInputAction> want = new HashSet<>();

        if (gui) {
            add(want, GuiHandler.KEY_LEFT_CLICK, btn(r, 0) || btn(l, 0));
            add(want, GuiHandler.KEY_RIGHT_CLICK, btn(r, 1) || btn(l, 1));
            add(want, v.keyMenuButton, btn(l, 5));
        } else {
            add(want, o.keyAttack, btn(r, 0));
            add(want, o.keyUse, btn(r, 1) || btn(l, 0));
            add(want, o.keyJump, btn(r, 4));
            add(want, o.keySwapOffhand, btn(r, 5));
            add(want, o.keyInventory, btn(r, 3));
            add(want, o.keySprint, btn(l, 1));
            add(want, o.keyShift, btn(l, 4));
            add(want, v.keyMenuButton, btn(l, 5));
            add(want, o.keyDrop, btn(l, 3));
            float ry = r.present ? -r.axes[3] : 0F; // WebXR: up is negative
            add(want, v.keyHotbarPrev, ry > HOTBAR_THRESHOLD);
            add(want, v.keyHotbarNext, ry < -HOTBAR_THRESHOLD);
        }

        // release what is no longer wanted, press what is new
        for (VRInputAction a : new HashSet<>(this.held)) {
            if (!want.contains(a)) {
                a.digitalData[0].state = false;
                a.digitalData[0].isChanged = true;
                a.unpressBinding();
                this.held.remove(a);
            }
        }
        for (VRInputAction a : want) {
            if (this.held.add(a)) {
                a.digitalData[0].state = true;
                a.digitalData[0].isChanged = true;
                a.digitalData[0].isActive = true;
                a.pressBinding();
            }
        }

        // analog sticks
        setAnalog(this.vr.getInputAction(v.keyFreeMoveStrafe),
            l.present ? dz(l.axes[2]) : 0F, l.present ? dz(-l.axes[3]) : 0F);
        setAnalog(this.vr.getInputAction(v.keyRotateAxis),
            r.present ? dz(r.axes[2]) : 0F, 0F);
        setAnalog(this.vr.getInputAction(GuiHandler.KEY_SCROLL_AXIS),
            0F, r.present ? dz(-r.axes[3]) : 0F);
    }

    private void add(Set<VRInputAction> want, KeyMapping key, boolean down) {
        if (!down || key == null) return;
        VRInputAction a = this.vr.getInputAction(key);
        if (a != null && a.isEnabled()) want.add(a);
    }

    private static void setAnalog(VRInputAction a, float x, float y) {
        if (a == null) return;
        VRInputAction.AnalogData d = a.analogData[0];
        d.isChanged = d.x != x || d.y != y;
        d.deltaX = x - d.x;
        d.deltaY = y - d.y;
        d.x = x;
        d.y = y;
        d.isActive = true;
    }

    void releaseAll() {
        for (VRInputAction a : new HashSet<>(this.held)) {
            a.digitalData[0].state = false;
            a.unpressBinding();
        }
        this.held.clear();
        VivecraftVRMod v = VivecraftVRMod.INSTANCE;
        setAnalog(this.vr.getInputAction(v.keyFreeMoveStrafe), 0F, 0F);
        setAnalog(this.vr.getInputAction(v.keyRotateAxis), 0F, 0F);
    }
}
