'use strict';
/* Vivecraft WebXR client.
 *  - receives JPEG frames of the VR view from Minecraft over a WebSocket
 *  - shows them on a head-locked virtual screen inside an immersive-vr WebXR session
 *  - sends head + controller poses and button states back to Minecraft every XR frame
 */
(() => {
  const $ = id => document.getElementById(id);
  const dotConn = $('dotConn'), txtConn = $('txtConn'), dotXR = $('dotXR'), txtXR = $('txtXR');
  const btnEnter = $('enter'), hint = $('hint'), fpsEl = $('fps'), resEl = $('res');
  const preview = $('preview'), pctx = preview.getContext('2d');
  const scaleEl = $('scale'), distEl = $('dist');

  // ---- settings (persisted) ----------------------------------------------------------------
  try {
    const s = JSON.parse(localStorage.getItem('webxr-settings') || '{}');
    if (s.scale) scaleEl.value = s.scale;
    if (s.dist) distEl.value = s.dist;
  } catch (e) {}
  const saveSettings = () => { try { localStorage.setItem('webxr-settings', JSON.stringify({ scale: scaleEl.value, dist: distEl.value })); } catch (e) {} };
  scaleEl.oninput = distEl.oninput = saveSettings;

  // ---- host config -------------------------------------------------------------------------
  let cfg = { w: 1280, h: 720, fov: 90, fps: 60 };

  // ---- websocket ---------------------------------------------------------------------------
  let ws = null, wsOpen = false, reconnectTimer = 0;
  let pendingBitmap = null;      // newest decoded frame, waiting to be uploaded / shown
  let framesThisSec = 0, fpsStamp = performance.now();
  let decoding = false, nextBlob = null;
  let inVR = false;

  function connect() {
    clearTimeout(reconnectTimer);
    const url = (location.protocol === 'https:' ? 'wss://' : 'ws://') + location.host + '/ws';
    ws = new WebSocket(url);
    ws.binaryType = 'arraybuffer';
    ws.onopen = () => {
      wsOpen = true;
      dotConn.classList.add('ok'); txtConn.textContent = 'Connected to Minecraft (' + location.host + ')';
      if (inVR) sendState(true);
      updateButton();
    };
    ws.onclose = () => {
      wsOpen = false;
      dotConn.classList.remove('ok'); txtConn.textContent = 'Connection lost – retrying…';
      updateButton();
      reconnectTimer = setTimeout(connect, 1000);
    };
    ws.onerror = () => { try { ws.close(); } catch (e) {} };
    ws.onmessage = ev => {
      if (typeof ev.data === 'string') {
        let m; try { m = JSON.parse(ev.data); } catch (e) { return; }
        if (m.t === 'cfg') { cfg = Object.assign(cfg, m); resEl.textContent = cfg.w + '×' + cfg.h + ' @ ≤' + cfg.fps + ' fps'; }
        else if (m.t === 'haptic') haptic(m.hand, m.ms, m.amp);
        return;
      }
      const u8 = new Uint8Array(ev.data);
      if (u8.length > 1 && u8[0] === 1) {
        // keep only the newest undecoded frame
        nextBlob = new Blob([u8.subarray(1)], { type: 'image/jpeg' });
        pump();
      }
    };
  }

  async function pump() {
    if (decoding || !nextBlob) return;
    decoding = true;
    const blob = nextBlob; nextBlob = null;
    try {
      const bmp = await createImageBitmap(blob);
      if (pendingBitmap) pendingBitmap.close();
      pendingBitmap = bmp;
      framesThisSec++;
    } catch (e) { /* corrupt frame, ignore */ }
    decoding = false;
    if (nextBlob) pump();
  }

  function sendState(vr) {
    if (!wsOpen) return;
    const b = new ArrayBuffer(6), dv = new DataView(b);
    dv.setUint8(0, 2); dv.setUint8(1, vr ? 1 : 0);
    dv.setFloat32(2, (xrSession && xrSession.frameRate) || 72, true);
    ws.send(b);
  }

  // ---- preview canvas (also works without a headset, handy for testing) ----------------------
  let lastShown = null;
  function drawPreview() {
    if (pendingBitmap && !inVR) {
      if (preview.width !== pendingBitmap.width) { preview.width = pendingBitmap.width; preview.height = pendingBitmap.height; }
      pctx.drawImage(pendingBitmap, 0, 0);
    } else if (!pendingBitmap) {
      pctx.fillStyle = '#000'; pctx.fillRect(0, 0, preview.width, preview.height);
      pctx.fillStyle = '#667'; pctx.font = '28px system-ui'; pctx.textAlign = 'center';
      pctx.fillText('Waiting for the game to start streaming…', preview.width / 2, preview.height / 2);
      pctx.fillText('(frames appear once you press Enter VR)', preview.width / 2, preview.height / 2 + 40);
    }
    const now = performance.now();
    if (now - fpsStamp > 1000) {
      fpsEl.textContent = framesThisSec ? framesThisSec + ' frames/s' : '';
      framesThisSec = 0; fpsStamp = now;
    }
    if (!inVR) requestAnimationFrame(drawPreview);
  }

  // ---- WebXR -------------------------------------------------------------------------------
  let xrSupported = false, xrSession = null, refSpace = null, gl = null, glLayer = null, prog = null;
  let tex = null, texW = 0, texH = 0, vbo = null, haveFrame = false;
  const posBuf = new ArrayBuffer(130), posView = new DataView(posBuf);

  async function checkXR() {
    if (!window.isSecureContext) {
      txtXR.textContent = 'WebXR unavailable – this page is not a secure context';
      const httpsPort = '8443';
      hint.innerHTML = '<span class="warn">Browsers only allow WebXR on <code>https://</code> (or localhost).</span> ' +
        'Open <code>https://' + location.hostname + ':' + httpsPort + '</code> instead and accept the certificate warning once.';
      return;
    }
    if (!navigator.xr) { txtXR.textContent = 'This browser has no WebXR support'; return; }
    try { xrSupported = await navigator.xr.isSessionSupported('immersive-vr'); } catch (e) { xrSupported = false; }
    dotXR.classList.toggle('ok', xrSupported);
    txtXR.textContent = xrSupported ? 'WebXR immersive-vr is available' : 'Immersive VR is not supported on this device/browser';
    if (xrSupported) hint.textContent = 'Press “Enter VR”. Minecraft switches to VR mode as soon as the session starts.';
    updateButton();
  }

  function updateButton() { btnEnter.disabled = !(xrSupported && wsOpen) && !xrSession; btnEnter.textContent = xrSession ? 'Exit VR' : 'Enter VR'; }

  btnEnter.onclick = async () => {
    if (xrSession) { xrSession.end(); return; }
    try {
      const session = await navigator.xr.requestSession('immersive-vr', { requiredFeatures: ['local-floor'] });
      await startSession(session);
    } catch (e) {
      // some browsers do not accept local-floor as required; fall back to a plain local space
      try {
        const session = await navigator.xr.requestSession('immersive-vr', { optionalFeatures: ['local-floor'] });
        await startSession(session);
      } catch (e2) { hint.innerHTML = '<span class="warn">Could not start VR: ' + (e2.message || e2) + '</span>'; }
    }
  };

  const VS = `attribute vec3 aPos; attribute vec2 aUV; uniform mat4 uMVP; varying vec2 vUV;
              void main(){ vUV = aUV; gl_Position = uMVP * vec4(aPos, 1.0); }`;
  const FS = `precision mediump float; uniform sampler2D uTex; uniform float uHave; varying vec2 vUV;
              void main(){ vec4 c = texture2D(uTex, vUV);
                           gl_FragColor = mix(vec4(0.03,0.03,0.05,1.0), vec4(c.rgb,1.0), uHave); }`;

  function makeProgram(g) {
    const sh = (type, src) => { const s = g.createShader(type); g.shaderSource(s, src); g.compileShader(s);
      if (!g.getShaderParameter(s, g.COMPILE_STATUS)) throw new Error(g.getShaderInfoLog(s)); return s; };
    const p = g.createProgram(); g.attachShader(p, sh(g.VERTEX_SHADER, VS)); g.attachShader(p, sh(g.FRAGMENT_SHADER, FS));
    g.linkProgram(p); if (!g.getProgramParameter(p, g.LINK_STATUS)) throw new Error(g.getProgramInfoLog(p)); return p;
  }

  async function startSession(session) {
    xrSession = session;
    const canvas = document.createElement('canvas');
    gl = canvas.getContext('webgl', { xrCompatible: true, antialias: false, alpha: false });
    if (!gl) throw new Error('WebGL not available');
    prog = makeProgram(gl);
    vbo = gl.createBuffer();
    tex = gl.createTexture();
    gl.bindTexture(gl.TEXTURE_2D, tex);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, 1, 1, 0, gl.RGBA, gl.UNSIGNED_BYTE, new Uint8Array([0, 0, 0, 255]));
    haveFrame = false; texW = texH = 0;

    glLayer = new XRWebGLLayer(session, gl, { antialias: false, alpha: false });
    await session.updateRenderState({ baseLayer: glLayer });
    refSpace = await session.requestReferenceSpace('local-floor').catch(() => session.requestReferenceSpace('local'));

    inVR = true;
    dotXR.classList.add('ok'); txtXR.textContent = 'In VR';
    updateButton();
    session.addEventListener('end', onSessionEnd);
    sendState(true);
    session.requestAnimationFrame(onXRFrame);
  }

  function onSessionEnd() {
    inVR = false; xrSession = null; refSpace = null; glLayer = null; gl = null;
    sendState(false);
    txtXR.textContent = 'WebXR immersive-vr is available';
    updateButton();
    requestAnimationFrame(drawPreview);
  }

  // ---- tiny mat4 helpers (column-major, like WebGL/WebXR) -----------------------------------
  function mul(a, b) { // a * b
    const o = new Float32Array(16);
    for (let c = 0; c < 4; c++) for (let r = 0; r < 4; r++) {
      let s = 0; for (let k = 0; k < 4; k++) s += a[k * 4 + r] * b[c * 4 + k];
      o[c * 4 + r] = s;
    }
    return o;
  }

  // The virtual screen is placed in head space: centred 'dist' metres in front of the eyes.
  function screenVertices() {
    const dist = parseFloat(distEl.value), scale = parseFloat(scaleEl.value);
    const aspect = cfg.w / cfg.h;
    const halfH = Math.tan((cfg.fov * Math.PI / 180) / 2) * dist * scale;
    const halfW = halfH * aspect;
    const z = -dist;
    // x, y, z, u, v   (image row 0 is the top of the picture)
    return new Float32Array([
      -halfW, -halfH, z, 0, 1,
       halfW, -halfH, z, 1, 1,
      -halfW,  halfH, z, 0, 0,
       halfW,  halfH, z, 1, 0 ]);
  }

  let lastScreenKey = '';
  function onXRFrame(t, frame) {
    const session = frame.session;
    if (!xrSession) return;
    session.requestAnimationFrame(onXRFrame);

    const viewerPose = frame.getViewerPose(refSpace);
    if (viewerPose) {
      sendPose(frame, viewerPose);

      // upload newest decoded frame to the texture
      if (pendingBitmap) {
        gl.bindTexture(gl.TEXTURE_2D, tex);
        gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, false);
        gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, pendingBitmap);
        texW = pendingBitmap.width; texH = pendingBitmap.height;
        pendingBitmap.close(); pendingBitmap = null; haveFrame = true;
      }

      gl.bindFramebuffer(gl.FRAMEBUFFER, glLayer.framebuffer);
      gl.clearColor(0, 0, 0, 1);
      gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
      gl.disable(gl.DEPTH_TEST); gl.disable(gl.CULL_FACE);

      const key = distEl.value + '|' + scaleEl.value + '|' + cfg.w + 'x' + cfg.h + '|' + cfg.fov;
      gl.bindBuffer(gl.ARRAY_BUFFER, vbo);
      if (key !== lastScreenKey) { gl.bufferData(gl.ARRAY_BUFFER, screenVertices(), gl.STATIC_DRAW); lastScreenKey = key; }
      gl.useProgram(prog);
      const aPos = gl.getAttribLocation(prog, 'aPos'), aUV = gl.getAttribLocation(prog, 'aUV');
      gl.enableVertexAttribArray(aPos); gl.vertexAttribPointer(aPos, 3, gl.FLOAT, false, 20, 0);
      gl.enableVertexAttribArray(aUV);  gl.vertexAttribPointer(aUV, 2, gl.FLOAT, false, 20, 12);
      gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, tex);
      gl.uniform1i(gl.getUniformLocation(prog, 'uTex'), 0);
      gl.uniform1f(gl.getUniformLocation(prog, 'uHave'), haveFrame ? 1 : 0);
      const uMVP = gl.getUniformLocation(prog, 'uMVP');

      const head = viewerPose.transform.matrix;
      for (const view of viewerPose.views) {
        const vp = glLayer.getViewport(view);
        gl.viewport(vp.x, vp.y, vp.width, vp.height);
        // head-space -> eye-space -> clip. Rotation of the head is cancelled, so the screen never moves.
        const toEye = mul(view.transform.inverse.matrix, head);
        gl.uniformMatrix4fv(uMVP, false, mul(view.projectionMatrix, toEye));
        gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
      }
    }
    // fps counter
    const now = performance.now();
    if (now - fpsStamp > 1000) { fpsEl.textContent = framesThisSec + ' stream fps'; framesThisSec = 0; fpsStamp = now; }
  }

  // ---- pose + input packet -----------------------------------------------------------------
  function writePose(off, transform) {
    const p = transform.position, o = transform.orientation;
    posView.setFloat32(off, p.x, true);      posView.setFloat32(off + 4, p.y, true);  posView.setFloat32(off + 8, p.z, true);
    posView.setFloat32(off + 12, o.x, true); posView.setFloat32(off + 16, o.y, true);
    posView.setFloat32(off + 20, o.z, true); posView.setFloat32(off + 24, o.w, true);
  }

  // controller block = pose(7 floats) + buttons(u32) + axes(4 floats) = 48 bytes
  function writeController(off, src, frame) {
    for (let i = off; i < off + 48; i += 4) posView.setFloat32(i, 0, true);
    posView.setFloat32(off + 24, 1, true); // identity quaternion w
    if (!src || !src.targetRaySpace) return false;
    const pose = frame.getPose(src.targetRaySpace, refSpace);
    if (!pose) return false;
    writePose(off, pose.transform);
    let mask = 0;
    const gp = src.gamepad;
    if (gp) {
      for (let i = 0; i < Math.min(8, gp.buttons.length); i++) {
        const bt = gp.buttons[i];
        if (bt.pressed || bt.value > 0.6) mask |= (1 << i);
      }
      // xr-standard: axes[0..1] = touchpad, axes[2..3] = thumbstick.
      // Devices without a touchpad report the thumbstick in axes[0..1].
      const a = gp.axes;
      if (a.length >= 4) { for (let i = 0; i < 4; i++) posView.setFloat32(off + 32 + i * 4, a[i] || 0, true); }
      else { posView.setFloat32(off + 40, a[0] || 0, true); posView.setFloat32(off + 44, a[1] || 0, true); }
    }
    posView.setUint32(off + 28, mask >>> 0, true);
    return true;
  }

  function sendPose(frame, viewerPose) {
    if (!wsOpen || ws.bufferedAmount > 65536) return; // don't queue stale poses behind a slow link
    let right = null, left = null;
    for (const s of frame.session.inputSources) {
      if (s.handedness === 'right') right = s; else if (s.handedness === 'left') left = s;
    }
    posView.setUint8(0, 1);
    let ipd = 0.063;
    if (viewerPose.views.length >= 2) {
      const a = viewerPose.views[0].transform.position, b = viewerPose.views[1].transform.position;
      ipd = Math.hypot(a.x - b.x, a.y - b.y, a.z - b.z);
    }
    posView.setFloat32(2, ipd, true);
    writePose(6, viewerPose.transform);
    let flags = 0;
    if (writeController(34, right, frame)) flags |= 1;
    if (writeController(82, left, frame)) flags |= 2;
    posView.setUint8(1, flags);
    ws.send(posBuf);
  }

  function haptic(hand, ms, amp) {
    if (!xrSession) return;
    const want = hand === 0 ? 'right' : 'left';
    for (const s of xrSession.inputSources) {
      if (s.handedness !== want || !s.gamepad) continue;
      const act = (s.gamepad.hapticActuators && s.gamepad.hapticActuators[0]) || null;
      try {
        if (act && act.pulse) act.pulse(amp, ms);
        else if (s.gamepad.vibrationActuator) s.gamepad.vibrationActuator.playEffect('dual-rumble', { duration: ms, strongMagnitude: amp, weakMagnitude: amp });
      } catch (e) {}
    }
  }

  // ---- go ------------------------------------------------------------------------------------
  connect();
  checkXR();
  requestAnimationFrame(drawPreview);
  document.addEventListener('visibilitychange', () => { if (!document.hidden && !wsOpen) connect(); });
})();
